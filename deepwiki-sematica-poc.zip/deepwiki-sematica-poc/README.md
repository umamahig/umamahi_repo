# deepwiki-sematica-poc

Parse DeepWiki markdown + JSON manifests for 2,000+ applications, build ontology-backed knowledge graphs with
per-fact provenance, and answer questions with **grounded, cited, extractive** responses.

## Quick start
```bash
python -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt

# demo data (or point ingest at your real DeepWiki tree)
python -m deepwiki_poc.cli generate --apps 100 --dest sample_data
python -m deepwiki_poc.cli ingest sample_data

python -m deepwiki_poc.cli search "Is 1CAT a PAA app?"
python -m deepwiki_poc.cli search "What are the business capabilities of 1CAT?"
python -m deepwiki_poc.cli search "Java"                       # technology impact + graph
python -m deepwiki_poc.cli search "kafka" --app 1CAT           # pub/sub lineage + graph
python -m deepwiki_poc.cli search "appid: 1CAT kafka"          # inline scope syntax also works
python -m deepwiki_poc.cli search "how is 1CAT related to 7UGR"
python -m deepwiki_poc.cli search "retry policy" --app 1CAT --component 1CAT/1cat-api
python -m pytest -q tests
```
Programmatic: `from deepwiki_poc.search import Engine; Engine().ask("Java", app=None)` → `Answer(lines, citations, graph_files)`.

## Expected input layout
```
<data_dir>/<APPID>/<APPID>.json          manifest (id via appId/applicationId/id)
<data_dir>/<APPID>/*.md                  application-level DeepWiki (any nesting)
<data_dir>/<APPID>/components/<COMP>/**.md   component-level DeepWiki
```
Manifest keys understood: `appId|id, name, type|appType, technologies, dependencies{direct,indirect}, components,
environments, messaging{produces,consumes}` (strings or objects). Adjust `extract.extract_app` for your real schema.

## ⚠ Assumptions you must review
1. **The 22 `applicationbundle` sections** were not in the spec text I had, so `config/sections.json` holds a
   *placeholder* list of 22. Replace titles/aliases with the real ones; nothing else changes. Unmatched headings stay
   inside the preceding section; missing sections are recorded per app in `output/reports/ingestion_report.json`.
2. Section-level extraction rules (bullets/tables in Technology Stack, Dependencies, Messaging, Capabilities,
   Classification) are heuristics tuned to the sample format. Run on a handful of real apps and tune `extract.py`.
3. Ontology adds two relations beyond the five required: `HAS_CAPABILITY` and `HAS_ATTRIBUTE` (app type, name, environments).

## Architecture
| Stage | Module | Notes |
|---|---|---|
| Ingest | `parser.py` | asyncio + bounded thread pool, batches of 200; Semantica `JSONParser` tried first, stdlib fallback; line-preserving markdown parser |
| Facts | `extract.py` | every fact carries `Prov(file, section/JSON path, line range)` |
| Ontology | `ontology.py` | Application, Component, Technology, Topic, BusinessCapability; facts violating domain/range are rejected; exported to `output/graph/ontology.ttl` |
| Graph | `graph.py` | networkx MultiDiGraph → `kg.json`, `kg.ttl`; provenance in `output/provenance/facts.jsonl` and mirrored to Semantica `ProvenanceManager` (SQLite) |
| Search | `search.py` | TF-IDF (sparse) + dense vectors (LSA by default; `DEEPWIKI_EMBEDDER=st` for sentence-transformers) fused by RRF, plus rule-based intent routing to graph queries |
| Viz | `viz.py` | PNGs in `output/graphs/` (tech map, pub/sub layered, relationship, dependencies) |

**Intents:** attribute check ("Is X a PAA app?"), business capabilities, dependencies, technology impact, messaging/Kafka
lineage (producer → topic → consumer, event triggers), relationship between two apps/components (explicit edge, shared
tech/topic, dependency chain), and hybrid retrieval fallback.

## Anti-hallucination design
* No generative model: answers are assembled from graph edges or verbatim snippets only.
* No citation ⇒ no answer: `Answer.render()` returns `Information not found in DeepWiki source data`.
* Unknown app/component IDs, unmatched queries, and weak matches (no lexical overlap and dense score < 0.6) return that same message.
* Yes/No attribute questions are answered only from an explicit attribute fact; a passing mention is reported as a mention, never as a classification.
* "Implicit" relationships (shared tech/topic, dependency chains) are labelled as such and cited edge by edge.

## Semantica usage (verified against semantica 0.7.0)
Used: `semantica.parse.JSONParser` (manifests), `semantica.provenance.ProvenanceManager.track_relationship` (audit mirror).
Available but not wired: `semantica.kg`, `semantica.vector_store.HybridSearch`, `semantica.visualization`.
All Semantica calls are wrapped so failures fall back to the custom implementation (`semantica_adapter.py`).

## Measured (synthetic data, 2,000 apps, single machine)
Ingest + graph + index ≈ 80 s (27k chunks, 40k edges); query latency < 0.1 s; `output/` ≈ 140 MB (mostly the Semantica SQLite mirror, capped at 5,000 records).

## Known limitations
* Extraction is heuristic; unusual markdown shapes may be missed (they still land in the search index).
* Natural-language intent routing is rule-based, not an LLM classifier; very free-form questions fall back to hybrid retrieval.
* Graph images cap at 80 nodes (top by degree); a node that both produces and consumes appears in one column.
* Index is rebuilt in full on each `ingest` (no incremental update yet).
