---
appId: 8JXT
---
# 8JXT DeepWiki

## 1. Overview
8JXT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Redis
- Python 3.11
- Kubernetes
- Spring Boot 3.2

## 8. Dependencies
- Direct: 8MPM
- Direct: 6DGU
- Direct: 4LUE
- Indirect (transitive): 9BNG
- Indirect (transitive): 6XWP
