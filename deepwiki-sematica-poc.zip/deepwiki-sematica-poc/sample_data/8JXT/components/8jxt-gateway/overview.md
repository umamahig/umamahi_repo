# 8jxt-gateway
## Overview
Component 8jxt-gateway of 8JXT.
## Technology Stack
- Kubernetes
- Spring Boot 3.2