---
appId: 3MKC
---
# 3MKC DeepWiki

## 1. Overview
3MKC is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows
- Notifications: supports notifications flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Python 3.11
- React
- Java 17
- Spring Boot 3.2

## 8. Dependencies
- Direct: 4BKC
- Direct: 5NLP
- Direct: 1KAV
- Indirect (transitive): 5ZVL
- Indirect (transitive): 1KAV
