# 3mkc-batch
## Overview
Component 3mkc-batch of 3MKC.
## Technology Stack
- Java 17
- Spring Boot 3.2