# 3mkc-gateway
## Overview
Component 3mkc-gateway of 3MKC.
## Technology Stack
- Spring Boot 3.2
- Python 3.11