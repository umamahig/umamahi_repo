---
appId: 1TTV
---
# 1TTV DeepWiki

## 1. Overview
1TTV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Angular
- Kubernetes
- Oracle
- Node.js 20
- React

## 8. Dependencies
- Direct: 4JDV
- Direct: 7MRZ
- Direct: 7FDQ
- Indirect (transitive): 8JXT
- Indirect (transitive): 2ZBC
