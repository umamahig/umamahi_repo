# 1ttv-batch
## Overview
Component 1ttv-batch of 1TTV.
## Technology Stack
- Node.js 20
- Kubernetes