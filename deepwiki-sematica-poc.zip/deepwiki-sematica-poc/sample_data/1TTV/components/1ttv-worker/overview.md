# 1ttv-worker
## Overview
Component 1ttv-worker of 1TTV.
## Technology Stack
- Node.js 20
- React