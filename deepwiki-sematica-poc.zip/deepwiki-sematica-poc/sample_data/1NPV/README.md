---
appId: 1NPV
---
# 1NPV DeepWiki

## 1. Overview
1NPV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Python 3.11
- Angular
- Java 17

## 8. Dependencies
- Direct: 8JXT
- Direct: 4JLV
- Direct: 9MUM
- Indirect (transitive): 1CAT
- Indirect (transitive): 9HQR
