# 1npv-api
## Overview
Component 1npv-api of 1NPV.
## Technology Stack
- Java 17
- Python 3.11