# 1npv-gateway
## Overview
Component 1npv-gateway of 1NPV.
## Technology Stack
- Python 3.11
- Java 17