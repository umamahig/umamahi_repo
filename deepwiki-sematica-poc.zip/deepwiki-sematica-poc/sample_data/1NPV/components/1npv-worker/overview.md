# 1npv-worker
## Overview
Component 1npv-worker of 1NPV.
## Technology Stack
- Angular
- Java 17