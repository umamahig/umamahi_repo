---
appId: 2LBP
---
# 2LBP DeepWiki

## 1. Overview
2LBP is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows
- Customer Onboarding: supports customer onboarding flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Oracle
- Redis
- Kafka
- Go
- Kubernetes

## 8. Dependencies
- Direct: 6DKH
- Direct: 1XCC
- Direct: 7PXF
- Indirect (transitive): 9GVP
- Indirect (transitive): 6DKH

## 11. Messaging & Events
### Produces
- `customers.created.v1` (event: item updated)
- `orders.failed.v2` (event: account locked)
### Consumes
- `orders.created.v1`
- `catalog.failed.v2`
