# 2lbp-batch
## Overview
Component 2lbp-batch of 2LBP.
## Technology Stack
- Kubernetes
- Go
## Messaging
- Produces to `customers.created.v1` (event: account locked)