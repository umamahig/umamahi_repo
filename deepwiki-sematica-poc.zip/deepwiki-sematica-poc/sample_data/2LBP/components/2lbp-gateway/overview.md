# 2lbp-gateway
## Overview
Component 2lbp-gateway of 2LBP.
## Technology Stack
- Kafka
- Redis