# 2lbp-ui
## Overview
Component 2lbp-ui of 2LBP.
## Technology Stack
- Kafka
- Oracle