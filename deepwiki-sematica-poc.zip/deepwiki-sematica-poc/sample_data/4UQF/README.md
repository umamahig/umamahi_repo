---
appId: 4UQF
---
# 4UQF DeepWiki

## 1. Overview
4UQF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- PostgreSQL
- Redis

## 8. Dependencies
- Direct: 7GDR
- Direct: 8YSX
- Direct: 4UDL
- Indirect (transitive): 9GVP
- Indirect (transitive): 6DGU
