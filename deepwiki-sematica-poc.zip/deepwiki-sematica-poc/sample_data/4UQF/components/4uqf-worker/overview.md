# 4uqf-worker
## Overview
Component 4uqf-worker of 4UQF.
## Technology Stack
- PostgreSQL
- Redis