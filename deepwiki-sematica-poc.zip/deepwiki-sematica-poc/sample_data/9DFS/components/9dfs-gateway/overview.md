# 9dfs-gateway
## Overview
Component 9dfs-gateway of 9DFS.
## Technology Stack
- Go
- Node.js 20