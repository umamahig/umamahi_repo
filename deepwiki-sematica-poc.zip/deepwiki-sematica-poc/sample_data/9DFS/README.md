---
appId: 9DFS
---
# 9DFS DeepWiki

## 1. Overview
9DFS is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows
- Fraud Detection: supports fraud detection flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Python 3.11
- Go
- Node.js 20

## 8. Dependencies
- Direct: 7FDQ
- Direct: 8DJG
- Direct: 3CTJ
- Indirect (transitive): 1CPD
- Indirect (transitive): 9JML

## 11. Messaging & Events
### Produces
- `payments.updated.v1` (event: item updated)
- `customers.settled.v2` (event: order placed)
### Consumes
- `orders.failed.v2`
- `catalog.created.v2`
