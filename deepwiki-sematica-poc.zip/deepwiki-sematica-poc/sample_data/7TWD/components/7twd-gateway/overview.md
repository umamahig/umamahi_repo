# 7twd-gateway
## Overview
Component 7twd-gateway of 7TWD.
## Technology Stack
- React
- Node.js 20