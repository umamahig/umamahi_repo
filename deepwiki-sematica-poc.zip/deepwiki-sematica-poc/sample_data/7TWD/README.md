---
appId: 7TWD
---
# 7TWD DeepWiki

## 1. Overview
7TWD is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Angular
- Node.js 20
- Oracle
- React

## 8. Dependencies
- Direct: 7KAF
- Direct: 3MKC
- Direct: 7GDR
- Indirect (transitive): 2ZLZ
- Indirect (transitive): 9GSP
