---
appId: 1CAT
---
# 1CAT DeepWiki

## 1. Overview
1CAT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Reporting: supports reporting flows
- Notifications: supports notifications flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Java 17
- Kafka
- Spring Boot 3.2
- PostgreSQL

## 8. Dependencies
- Direct: 9RTH
- Direct: 2PNT
- Direct: 1QAJ
- Indirect (transitive): 9THN
- Indirect (transitive): 4UCJ

## 11. Messaging & Events
### Produces
- `orders.created.v1` (event: account locked)
### Consumes
- `payments.settled.v1`
