# 1cat-gateway
## Overview
Component 1cat-gateway of 1CAT.
## Technology Stack
- PostgreSQL
- Java 17