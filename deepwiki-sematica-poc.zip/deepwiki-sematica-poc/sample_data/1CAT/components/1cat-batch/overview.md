# 1cat-batch
## Overview
Component 1cat-batch of 1CAT.
## Technology Stack
- PostgreSQL
- Kafka
## Messaging
- Produces to `orders.created.v1` (event: payment settled)