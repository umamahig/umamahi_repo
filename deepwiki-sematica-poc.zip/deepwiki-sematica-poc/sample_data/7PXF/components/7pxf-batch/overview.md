# 7pxf-batch
## Overview
Component 7pxf-batch of 7PXF.
## Technology Stack
- Node.js 20
- React