# 7pxf-gateway
## Overview
Component 7pxf-gateway of 7PXF.
## Technology Stack
- Angular
- Docker