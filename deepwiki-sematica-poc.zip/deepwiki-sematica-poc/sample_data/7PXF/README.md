---
appId: 7PXF
---
# 7PXF DeepWiki

## 1. Overview
7PXF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Angular
- Node.js 20
- Docker
- React
- Kafka

## 8. Dependencies
- Direct: 9PSX
- Direct: 2LBP
- Direct: 7KAF
- Indirect (transitive): 7GDR
- Indirect (transitive): 1HAN
