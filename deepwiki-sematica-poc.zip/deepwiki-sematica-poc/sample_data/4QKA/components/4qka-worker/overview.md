# 4qka-worker
## Overview
Component 4qka-worker of 4QKA.
## Technology Stack
- Java 17
- React