---
appId: 4QKA
---
# 4QKA DeepWiki

## 1. Overview
4QKA is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- React
- Java 17

## 8. Dependencies
- Direct: 9MUM
- Direct: 7WFF
- Direct: 4BKC
- Indirect (transitive): 3XJW
- Indirect (transitive): 1XCC
