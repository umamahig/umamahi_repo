---
appId: 6PGJ
---
# 6PGJ DeepWiki

## 1. Overview
6PGJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Reporting: supports reporting flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Oracle
- Angular
- React

## 8. Dependencies
- Direct: 8MPM
- Direct: 1NZS
- Direct: 3WZK
- Indirect (transitive): 7GDR
- Indirect (transitive): 6BAA

## 11. Messaging & Events
### Produces
- `customers.created.v1` (event: customer created)
- `orders.failed.v1` (event: item updated)
### Consumes
- `orders.failed.v2`
- `orders.created.v1`
