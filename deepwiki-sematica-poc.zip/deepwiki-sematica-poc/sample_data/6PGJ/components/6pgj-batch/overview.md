# 6pgj-batch
## Overview
Component 6pgj-batch of 6PGJ.
## Technology Stack
- Oracle
- React
## Messaging
- Produces to `customers.created.v1` (event: order placed)