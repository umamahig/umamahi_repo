# 4wft-gateway
## Overview
Component 4wft-gateway of 4WFT.
## Technology Stack
- Redis
- Java 17