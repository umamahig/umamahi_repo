# 4wft-api
## Overview
Component 4wft-api of 4WFT.
## Technology Stack
- Angular
- Java 17