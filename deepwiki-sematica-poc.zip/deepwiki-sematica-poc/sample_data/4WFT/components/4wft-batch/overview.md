# 4wft-batch
## Overview
Component 4wft-batch of 4WFT.
## Technology Stack
- Redis
- Angular