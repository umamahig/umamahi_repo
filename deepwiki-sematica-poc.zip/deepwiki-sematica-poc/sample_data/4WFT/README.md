---
appId: 4WFT
---
# 4WFT DeepWiki

## 1. Overview
4WFT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Angular
- Node.js 20
- Redis
- Oracle
- Java 17

## 8. Dependencies
- Direct: 8JXT
- Direct: 2NEE
- Direct: 1CPD
- Indirect (transitive): 1TTV
- Indirect (transitive): 9MUM
