---
appId: 7UGR
---
# 7UGR DeepWiki

## 1. Overview
7UGR is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Python 3.11
- Oracle
- Docker
- Node.js 20

## 8. Dependencies
- Direct: 9BNG
- Direct: 6PGJ
- Direct: 2RQR
- Indirect (transitive): 4JDJ
- Indirect (transitive): 2KKZ
