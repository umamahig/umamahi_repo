# 7ugr-batch
## Overview
Component 7ugr-batch of 7UGR.
## Technology Stack
- Docker
- Python 3.11