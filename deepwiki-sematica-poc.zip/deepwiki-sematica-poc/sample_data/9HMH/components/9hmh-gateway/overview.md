# 9hmh-gateway
## Overview
Component 9hmh-gateway of 9HMH.
## Technology Stack
- Angular
- Java 17