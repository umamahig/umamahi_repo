# 9hmh-worker
## Overview
Component 9hmh-worker of 9HMH.
## Technology Stack
- Java 17
- Angular