# 9hmh-api
## Overview
Component 9hmh-api of 9HMH.
## Technology Stack
- Java 17
- PostgreSQL