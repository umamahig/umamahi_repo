---
appId: 9HMH
---
# 9HMH DeepWiki

## 1. Overview
9HMH is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- Java 17
- Angular
- PostgreSQL

## 8. Dependencies
- Direct: 2QJD
- Direct: 3WZK
- Direct: 5QYL
- Indirect (transitive): 2NTM
- Indirect (transitive): 8YSX
