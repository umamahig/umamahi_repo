---
appId: 9HAG
---
# 9HAG DeepWiki

## 1. Overview
9HAG is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows
- Identity Management: supports identity management flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Python 3.11
- PostgreSQL
- Spring Boot 3.2
- Docker

## 8. Dependencies
- Direct: 3CTJ
- Direct: 3UCJ
- Direct: 3XHF
- Indirect (transitive): 7KAF
- Indirect (transitive): 9PSX

## 11. Messaging & Events
### Produces
- `orders.failed.v2` (event: item updated)
- `payments.settled.v1` (event: item updated)
### Consumes
- `catalog.failed.v2`
- `payments.updated.v1`
