# 9hag-gateway
## Overview
Component 9hag-gateway of 9HAG.
## Technology Stack
- Spring Boot 3.2
- PostgreSQL
## Messaging
- Produces to `orders.failed.v2` (event: order placed)