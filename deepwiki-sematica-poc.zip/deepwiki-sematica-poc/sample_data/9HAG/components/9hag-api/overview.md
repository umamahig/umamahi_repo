# 9hag-api
## Overview
Component 9hag-api of 9HAG.
## Technology Stack
- Spring Boot 3.2
- Python 3.11