# 1aaw-api
## Overview
Component 1aaw-api of 1AAW.
## Technology Stack
- Go
- Python 3.11