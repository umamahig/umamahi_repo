# 1aaw-gateway
## Overview
Component 1aaw-gateway of 1AAW.
## Technology Stack
- Kubernetes
- Go