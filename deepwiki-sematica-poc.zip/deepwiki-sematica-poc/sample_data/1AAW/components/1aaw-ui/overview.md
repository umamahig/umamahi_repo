# 1aaw-ui
## Overview
Component 1aaw-ui of 1AAW.
## Technology Stack
- Kubernetes
- Go