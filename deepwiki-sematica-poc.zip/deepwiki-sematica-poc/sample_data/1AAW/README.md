---
appId: 1AAW
---
# 1AAW DeepWiki

## 1. Overview
1AAW is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Python 3.11
- Go
- Kubernetes

## 8. Dependencies
- Direct: 1NZS
- Direct: 3BZF
- Direct: 9PSX
- Indirect (transitive): 9RTH
- Indirect (transitive): 3STG
