# 9jml-ui
## Overview
Component 9jml-ui of 9JML.
## Technology Stack
- Angular
- Kafka
## Messaging
- Produces to `customers.created.v1` (event: item updated)