---
appId: 9JML
---
# 9JML DeepWiki

## 1. Overview
9JML is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Angular
- Go
- Kafka

## 8. Dependencies
- Direct: 2PNT
- Direct: 1XCC
- Direct: 8LDG
- Indirect (transitive): 3FJS
- Indirect (transitive): 1HAN

## 11. Messaging & Events
### Produces
- `customers.created.v1` (event: payment settled)
- `orders.failed.v2` (event: payment settled)
### Consumes
- `orders.created.v1`
- `orders.failed.v1`
