---
appId: 2XNK
---
# 2XNK DeepWiki

## 1. Overview
2XNK is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Reporting: supports reporting flows
- Order Fulfilment: supports order fulfilment flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Docker
- Node.js 20
- Kubernetes

## 8. Dependencies
- Direct: 3FFT
- Direct: 6BAA
- Direct: 8NLN
- Indirect (transitive): 4JDV
- Indirect (transitive): 4KKU

## 11. Messaging & Events
### Produces
- `orders.failed.v2` (event: item updated)
- `orders.failed.v1` (event: order placed)
### Consumes
- `customers.created.v1`
- `audit.updated.v2`
