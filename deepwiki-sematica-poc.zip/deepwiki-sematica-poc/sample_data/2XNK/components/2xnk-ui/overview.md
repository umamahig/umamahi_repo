# 2xnk-ui
## Overview
Component 2xnk-ui of 2XNK.
## Technology Stack
- Node.js 20
- Docker
## Messaging
- Produces to `orders.failed.v2` (event: payment settled)