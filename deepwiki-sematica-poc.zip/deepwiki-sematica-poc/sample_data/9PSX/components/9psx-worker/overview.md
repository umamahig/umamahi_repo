# 9psx-worker
## Overview
Component 9psx-worker of 9PSX.
## Technology Stack
- PostgreSQL
- Node.js 20