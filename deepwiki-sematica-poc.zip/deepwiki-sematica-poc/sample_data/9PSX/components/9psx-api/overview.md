# 9psx-api
## Overview
Component 9psx-api of 9PSX.
## Technology Stack
- Spring Boot 3.2
- PostgreSQL