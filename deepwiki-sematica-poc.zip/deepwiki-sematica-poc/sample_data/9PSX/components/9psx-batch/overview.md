# 9psx-batch
## Overview
Component 9psx-batch of 9PSX.
## Technology Stack
- Node.js 20
- PostgreSQL