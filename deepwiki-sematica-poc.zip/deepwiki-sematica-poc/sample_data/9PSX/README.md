---
appId: 9PSX
---
# 9PSX DeepWiki

## 1. Overview
9PSX is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Reporting: supports reporting flows
- Identity Management: supports identity management flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Node.js 20
- Spring Boot 3.2
- PostgreSQL

## 8. Dependencies
- Direct: 1RHZ
- Direct: 7GDR
- Direct: 1YQJ
- Indirect (transitive): 3STG
- Indirect (transitive): 3PUJ
