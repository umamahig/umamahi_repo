---
appId: 9THN
---
# 9THN DeepWiki

## 1. Overview
9THN is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Catalog Management: supports catalog management flows
- Fraud Detection: supports fraud detection flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Python 3.11
- Go
- Node.js 20
- Java 17
- Kafka

## 8. Dependencies
- Direct: 9RTH
- Direct: 3CTJ
- Direct: 9HQR
- Indirect (transitive): 3STG
- Indirect (transitive): 2ZLZ

## 11. Messaging & Events
### Produces
- `orders.failed.v1` (event: order placed)
- `audit.settled.v1` (event: payment settled)
### Consumes
- `audit.settled.v1`
- `payments.settled.v1`
