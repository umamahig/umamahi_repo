# 9thn-worker
## Overview
Component 9thn-worker of 9THN.
## Technology Stack
- Go
- Kafka
## Messaging
- Produces to `orders.failed.v1` (event: order placed)