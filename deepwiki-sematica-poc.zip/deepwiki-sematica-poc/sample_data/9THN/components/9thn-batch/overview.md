# 9thn-batch
## Overview
Component 9thn-batch of 9THN.
## Technology Stack
- Go
- Node.js 20