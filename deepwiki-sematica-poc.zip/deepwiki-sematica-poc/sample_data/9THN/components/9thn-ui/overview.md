# 9thn-ui
## Overview
Component 9thn-ui of 9THN.
## Technology Stack
- Go
- Python 3.11
## Messaging
- Produces to `orders.failed.v1` (event: account locked)