---
appId: 6BAA
---
# 6BAA DeepWiki

## 1. Overview
6BAA is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- Redis
- Java 17

## 8. Dependencies
- Direct: 8YSX
- Direct: 6PGJ
- Direct: 2XNK
- Indirect (transitive): 4KKU
- Indirect (transitive): 4JDJ
