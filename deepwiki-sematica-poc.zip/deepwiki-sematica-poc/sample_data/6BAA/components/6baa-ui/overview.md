# 6baa-ui
## Overview
Component 6baa-ui of 6BAA.
## Technology Stack
- Kubernetes
- Redis