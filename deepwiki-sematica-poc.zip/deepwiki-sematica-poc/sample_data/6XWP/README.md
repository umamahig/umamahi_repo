---
appId: 6XWP
---
# 6XWP DeepWiki

## 1. Overview
6XWP is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Redis
- Go
- Oracle
- Java 17
- Kubernetes

## 8. Dependencies
- Direct: 2ZBC
- Direct: 4UCJ
- Direct: 7MRZ
- Indirect (transitive): 1QAJ
- Indirect (transitive): 6DKH
