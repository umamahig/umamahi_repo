# 6xwp-worker
## Overview
Component 6xwp-worker of 6XWP.
## Technology Stack
- Kubernetes
- Go