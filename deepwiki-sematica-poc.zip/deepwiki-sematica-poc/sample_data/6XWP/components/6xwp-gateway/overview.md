# 6xwp-gateway
## Overview
Component 6xwp-gateway of 6XWP.
## Technology Stack
- Oracle
- Redis