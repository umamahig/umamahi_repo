# 4bkc-batch
## Overview
Component 4bkc-batch of 4BKC.
## Technology Stack
- Go
- Docker
## Messaging
- Produces to `catalog.failed.v2` (event: payment settled)