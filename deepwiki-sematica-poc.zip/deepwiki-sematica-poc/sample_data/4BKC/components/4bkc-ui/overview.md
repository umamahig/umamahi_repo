# 4bkc-ui
## Overview
Component 4bkc-ui of 4BKC.
## Technology Stack
- Kafka
- Docker
## Messaging
- Produces to `catalog.failed.v2` (event: payment settled)