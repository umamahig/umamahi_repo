# 4bkc-worker
## Overview
Component 4bkc-worker of 4BKC.
## Technology Stack
- Node.js 20
- Kafka