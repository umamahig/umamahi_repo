---
appId: 4BKC
---
# 4BKC DeepWiki

## 1. Overview
4BKC is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Identity Management: supports identity management flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Docker
- Node.js 20
- Go
- Kafka

## 8. Dependencies
- Direct: 3FFT
- Direct: 6KUT
- Direct: 8SNU
- Indirect (transitive): 3FJS
- Indirect (transitive): 3CTJ

## 11. Messaging & Events
### Produces
- `catalog.failed.v2` (event: item updated)
- `orders.created.v2` (event: account locked)
### Consumes
- `payments.settled.v1`
- `orders.failed.v2`
