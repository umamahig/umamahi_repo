# 7wff-batch
## Overview
Component 7wff-batch of 7WFF.
## Technology Stack
- Spring Boot 3.2
- Python 3.11