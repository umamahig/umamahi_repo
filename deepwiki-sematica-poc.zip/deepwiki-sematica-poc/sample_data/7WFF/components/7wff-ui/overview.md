# 7wff-ui
## Overview
Component 7wff-ui of 7WFF.
## Technology Stack
- Python 3.11
- Spring Boot 3.2
## Messaging
- Produces to `catalog.created.v2` (event: item updated)