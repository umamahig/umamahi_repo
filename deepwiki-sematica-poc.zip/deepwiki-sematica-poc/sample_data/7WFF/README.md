---
appId: 7WFF
---
# 7WFF DeepWiki

## 1. Overview
7WFF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Catalog Management: supports catalog management flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Python 3.11
- Spring Boot 3.2

## 8. Dependencies
- Direct: 1GHU
- Direct: 3STG
- Direct: 1XCC
- Indirect (transitive): 6KUT
- Indirect (transitive): 3FFT

## 11. Messaging & Events
### Produces
- `catalog.created.v2` (event: order placed)
- `audit.updated.v2` (event: payment settled)
### Consumes
- `orders.failed.v2`
- `orders.failed.v1`
