---
appId: 4UCJ
---
# 4UCJ DeepWiki

## 1. Overview
4UCJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Oracle
- Docker
- Spring Boot 3.2
- Kafka

## 8. Dependencies
- Direct: 6BAA
- Direct: 3FFT
- Direct: 8JXT
- Indirect (transitive): 1NZS
- Indirect (transitive): 4UDL

## 11. Messaging & Events
### Produces
- `orders.updated.v2` (event: account locked)
- `payments.updated.v1` (event: payment settled)
### Consumes
- `orders.created.v1`
- `catalog.created.v2`
