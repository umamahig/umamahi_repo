# 4ucj-ui
## Overview
Component 4ucj-ui of 4UCJ.
## Technology Stack
- Spring Boot 3.2
- Docker
## Messaging
- Produces to `orders.updated.v2` (event: order placed)