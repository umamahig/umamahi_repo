# 4ucj-worker
## Overview
Component 4ucj-worker of 4UCJ.
## Technology Stack
- Kafka
- Docker