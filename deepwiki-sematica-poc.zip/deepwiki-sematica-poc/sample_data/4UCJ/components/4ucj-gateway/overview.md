# 4ucj-gateway
## Overview
Component 4ucj-gateway of 4UCJ.
## Technology Stack
- Kafka
- Spring Boot 3.2