---
appId: 8NLN
---
# 8NLN DeepWiki

## 1. Overview
8NLN is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- React
- PostgreSQL
- Oracle

## 8. Dependencies
- Direct: 1TTV
- Direct: 5NLP
- Direct: 4BKC
- Indirect (transitive): 9RAL
- Indirect (transitive): 7CUT

## 11. Messaging & Events
### Produces
- `customers.settled.v2` (event: customer created)
- `customers.created.v1` (event: payment settled)
### Consumes
- `orders.created.v1`
- `audit.settled.v1`
