# 8nln-ui
## Overview
Component 8nln-ui of 8NLN.
## Technology Stack
- PostgreSQL
- Oracle
## Messaging
- Produces to `customers.settled.v2` (event: account locked)