# 8nln-gateway
## Overview
Component 8nln-gateway of 8NLN.
## Technology Stack
- React
- Oracle
## Messaging
- Produces to `customers.settled.v2` (event: account locked)