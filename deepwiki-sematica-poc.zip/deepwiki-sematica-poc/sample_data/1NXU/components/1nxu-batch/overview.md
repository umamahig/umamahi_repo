# 1nxu-batch
## Overview
Component 1nxu-batch of 1NXU.
## Technology Stack
- Node.js 20
- Python 3.11
## Messaging
- Produces to `catalog.settled.v1` (event: order placed)