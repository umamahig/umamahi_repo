# 1nxu-gateway
## Overview
Component 1nxu-gateway of 1NXU.
## Technology Stack
- Node.js 20
- Kubernetes
## Messaging
- Produces to `catalog.settled.v1` (event: order placed)