# 1nxu-ui
## Overview
Component 1nxu-ui of 1NXU.
## Technology Stack
- Node.js 20
- Python 3.11
## Messaging
- Produces to `catalog.settled.v1` (event: order placed)