---
appId: 1NXU
---
# 1NXU DeepWiki

## 1. Overview
1NXU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Kubernetes
- Node.js 20
- Python 3.11

## 8. Dependencies
- Direct: 8DJG
- Direct: 2NEE
- Direct: 9BNG
- Indirect (transitive): 2KKZ
- Indirect (transitive): 8NLN

## 11. Messaging & Events
### Produces
- `catalog.settled.v1` (event: item updated)
- `customers.created.v1` (event: customer created)
### Consumes
- `customers.created.v1`
- `customers.settled.v1`
