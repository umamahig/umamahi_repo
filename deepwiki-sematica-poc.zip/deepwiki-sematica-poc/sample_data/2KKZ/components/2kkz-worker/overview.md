# 2kkz-worker
## Overview
Component 2kkz-worker of 2KKZ.
## Technology Stack
- Spring Boot 3.2
- Python 3.11