# 2kkz-gateway
## Overview
Component 2kkz-gateway of 2KKZ.
## Technology Stack
- Spring Boot 3.2
- Python 3.11