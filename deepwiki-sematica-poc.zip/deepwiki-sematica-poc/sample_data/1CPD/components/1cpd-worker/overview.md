# 1cpd-worker
## Overview
Component 1cpd-worker of 1CPD.
## Technology Stack
- Spring Boot 3.2
- Redis