# 1cpd-ui
## Overview
Component 1cpd-ui of 1CPD.
## Technology Stack
- Redis
- React