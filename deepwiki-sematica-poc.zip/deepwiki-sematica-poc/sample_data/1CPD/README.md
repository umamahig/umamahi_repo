---
appId: 1CPD
---
# 1CPD DeepWiki

## 1. Overview
1CPD is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- React
- PostgreSQL
- Redis
- Spring Boot 3.2

## 8. Dependencies
- Direct: 4WFT
- Direct: 2ZBC
- Direct: 5TJY
- Indirect (transitive): 9RTH
- Indirect (transitive): 3UCJ
