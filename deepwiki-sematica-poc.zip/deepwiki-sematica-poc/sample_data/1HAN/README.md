---
appId: 1HAN
---
# 1HAN DeepWiki

## 1. Overview
1HAN is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Customer Onboarding: supports customer onboarding flows
- Payment Processing: supports payment processing flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Oracle
- Angular
- Python 3.11
- Spring Boot 3.2

## 8. Dependencies
- Direct: 9QHS
- Direct: 2NTM
- Direct: 8DJG
- Indirect (transitive): 2LBP
- Indirect (transitive): 8EUT
