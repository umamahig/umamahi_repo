# 1han-gateway
## Overview
Component 1han-gateway of 1HAN.
## Technology Stack
- Python 3.11
- Angular