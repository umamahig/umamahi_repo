# 1han-api
## Overview
Component 1han-api of 1HAN.
## Technology Stack
- Python 3.11
- Oracle