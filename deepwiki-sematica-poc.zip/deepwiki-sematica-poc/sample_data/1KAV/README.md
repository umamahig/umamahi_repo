---
appId: 1KAV
---
# 1KAV DeepWiki

## 1. Overview
1KAV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Docker
- Angular

## 8. Dependencies
- Direct: 2NTM
- Direct: 2QJD
- Direct: 8NLN
- Indirect (transitive): 7MRZ
- Indirect (transitive): 6CQX
