# 1kav-batch
## Overview
Component 1kav-batch of 1KAV.
## Technology Stack
- Docker
- Angular