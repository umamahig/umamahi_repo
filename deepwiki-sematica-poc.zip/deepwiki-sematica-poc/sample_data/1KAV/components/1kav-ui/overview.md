# 1kav-ui
## Overview
Component 1kav-ui of 1KAV.
## Technology Stack
- Angular
- Docker