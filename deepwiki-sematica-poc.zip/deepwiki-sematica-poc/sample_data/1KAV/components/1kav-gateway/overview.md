# 1kav-gateway
## Overview
Component 1kav-gateway of 1KAV.
## Technology Stack
- Docker
- Angular