---
appId: 3STG
---
# 3STG DeepWiki

## 1. Overview
3STG is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Redis
- Angular

## 8. Dependencies
- Direct: 4JDV
- Direct: 2QJD
- Direct: 7TWD
- Indirect (transitive): 7PXF
- Indirect (transitive): 3MKC
