# 3stg-batch
## Overview
Component 3stg-batch of 3STG.
## Technology Stack
- Angular
- Redis