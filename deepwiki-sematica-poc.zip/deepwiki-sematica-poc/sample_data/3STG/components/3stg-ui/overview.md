# 3stg-ui
## Overview
Component 3stg-ui of 3STG.
## Technology Stack
- Angular
- Redis