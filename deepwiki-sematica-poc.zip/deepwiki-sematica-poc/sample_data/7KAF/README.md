---
appId: 7KAF
---
# 7KAF DeepWiki

## 1. Overview
7KAF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Customer Onboarding: supports customer onboarding flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Redis
- Docker
- Kubernetes

## 8. Dependencies
- Direct: 7UGR
- Direct: 9GSP
- Direct: 9HQR
- Indirect (transitive): 8LDG
- Indirect (transitive): 7THW

## 11. Messaging & Events
### Produces
- `customers.settled.v1` (event: item updated)
- `audit.updated.v2` (event: account locked)
### Consumes
- `orders.failed.v2`
- `payments.settled.v1`
