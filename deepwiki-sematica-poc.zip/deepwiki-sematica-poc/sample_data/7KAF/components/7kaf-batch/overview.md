# 7kaf-batch
## Overview
Component 7kaf-batch of 7KAF.
## Technology Stack
- Kubernetes
- Docker
## Messaging
- Produces to `customers.settled.v1` (event: item updated)