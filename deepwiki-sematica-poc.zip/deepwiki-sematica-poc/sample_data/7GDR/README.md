---
appId: 7GDR
---
# 7GDR DeepWiki

## 1. Overview
7GDR is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Order Fulfilment: supports order fulfilment flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Spring Boot 3.2
- Oracle
- Go

## 8. Dependencies
- Direct: 9THN
- Direct: 4LUE
- Direct: 8NLN
- Indirect (transitive): 8LDG
- Indirect (transitive): 1GHU
