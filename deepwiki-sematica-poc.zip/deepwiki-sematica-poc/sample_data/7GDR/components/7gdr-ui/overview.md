# 7gdr-ui
## Overview
Component 7gdr-ui of 7GDR.
## Technology Stack
- Oracle
- Spring Boot 3.2