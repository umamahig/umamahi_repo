---
appId: 2ZLZ
---
# 2ZLZ DeepWiki

## 1. Overview
2ZLZ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Identity Management: supports identity management flows
- Reporting: supports reporting flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Oracle
- Java 17
- Spring Boot 3.2
- Node.js 20
- PostgreSQL

## 8. Dependencies
- Direct: 3FFT
- Direct: 6DKH
- Direct: 4UCJ
- Indirect (transitive): 4JDV
- Indirect (transitive): 2KKZ
