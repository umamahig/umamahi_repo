# 2zlz-batch
## Overview
Component 2zlz-batch of 2ZLZ.
## Technology Stack
- Oracle
- Spring Boot 3.2