# 2zlz-worker
## Overview
Component 2zlz-worker of 2ZLZ.
## Technology Stack
- PostgreSQL
- Spring Boot 3.2