---
appId: 9HQR
---
# 9HQR DeepWiki

## 1. Overview
9HQR is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Spring Boot 3.2
- Java 17
- Python 3.11
- React
- Kubernetes

## 8. Dependencies
- Direct: 3MKC
- Direct: 8DJG
- Direct: 4KKU
- Indirect (transitive): 6DVU
- Indirect (transitive): 9GSP

## 11. Messaging & Events
### Produces
- `orders.failed.v2` (event: order placed)
- `catalog.failed.v2` (event: customer created)
### Consumes
- `catalog.created.v2`
- `orders.failed.v2`
