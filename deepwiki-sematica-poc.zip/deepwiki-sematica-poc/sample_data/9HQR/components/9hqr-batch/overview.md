# 9hqr-batch
## Overview
Component 9hqr-batch of 9HQR.
## Technology Stack
- Kubernetes
- Java 17
## Messaging
- Produces to `orders.failed.v2` (event: order placed)