# 1yqj-api
## Overview
Component 1yqj-api of 1YQJ.
## Technology Stack
- Redis
- React
## Messaging
- Produces to `orders.failed.v1` (event: order placed)