# 1yqj-gateway
## Overview
Component 1yqj-gateway of 1YQJ.
## Technology Stack
- Kubernetes
- PostgreSQL
## Messaging
- Produces to `orders.failed.v1` (event: account locked)