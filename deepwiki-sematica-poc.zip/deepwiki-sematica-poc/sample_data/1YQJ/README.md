---
appId: 1YQJ
---
# 1YQJ DeepWiki

## 1. Overview
1YQJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- PostgreSQL
- Redis
- React
- Kubernetes
- Python 3.11

## 8. Dependencies
- Direct: 1NXU
- Direct: 5QYL
- Direct: 9QHS
- Indirect (transitive): 8YSX
- Indirect (transitive): 2KKZ

## 11. Messaging & Events
### Produces
- `orders.failed.v1` (event: payment settled)
- `audit.updated.v2` (event: item updated)
### Consumes
- `orders.failed.v1`
- `orders.created.v1`
