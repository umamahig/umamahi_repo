# 3ctj-batch
## Overview
Component 3ctj-batch of 3CTJ.
## Technology Stack
- Kafka
- React