---
appId: 3CTJ
---
# 3CTJ DeepWiki

## 1. Overview
3CTJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows
- Catalog Management: supports catalog management flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kafka
- PostgreSQL
- Oracle
- React
- Kubernetes

## 8. Dependencies
- Direct: 9HQR
- Direct: 8EUT
- Direct: 4JDJ
- Indirect (transitive): 2LBP
- Indirect (transitive): 1CPD

## 11. Messaging & Events
### Produces
- `catalog.settled.v1` (event: account locked)
- `payments.updated.v1` (event: payment settled)
### Consumes
- `orders.updated.v2`
- `audit.settled.v1`
