# 7cut-gateway
## Overview
Component 7cut-gateway of 7CUT.
## Technology Stack
- PostgreSQL
- Redis
## Messaging
- Produces to `audit.updated.v1` (event: payment settled)