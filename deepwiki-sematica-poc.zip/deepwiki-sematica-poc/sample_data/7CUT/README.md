---
appId: 7CUT
---
# 7CUT DeepWiki

## 1. Overview
7CUT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Kubernetes
- Spring Boot 3.2
- PostgreSQL
- Redis

## 8. Dependencies
- Direct: 3FJS
- Direct: 6PGJ
- Direct: 5TJY
- Indirect (transitive): 8MPM
- Indirect (transitive): 1TTV

## 11. Messaging & Events
### Produces
- `audit.updated.v1` (event: customer created)
- `orders.failed.v2` (event: item updated)
### Consumes
- `orders.failed.v1`
- `customers.settled.v2`
