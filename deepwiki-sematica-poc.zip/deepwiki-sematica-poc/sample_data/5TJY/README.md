---
appId: 5TJY
---
# 5TJY DeepWiki

## 1. Overview
5TJY is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Payment Processing: supports payment processing flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Kafka
- Spring Boot 3.2
- PostgreSQL
- Python 3.11

## 8. Dependencies
- Direct: 4UCJ
- Direct: 8YSX
- Direct: 6DKH
- Indirect (transitive): 8DJG
- Indirect (transitive): 2RQR

## 11. Messaging & Events
### Produces
- `orders.created.v2` (event: item updated)
- `orders.created.v1` (event: payment settled)
### Consumes
- `customers.settled.v1`
- `payments.updated.v1`
