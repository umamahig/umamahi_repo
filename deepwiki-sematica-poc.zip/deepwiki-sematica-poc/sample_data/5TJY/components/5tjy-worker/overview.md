# 5tjy-worker
## Overview
Component 5tjy-worker of 5TJY.
## Technology Stack
- Spring Boot 3.2
- Kafka
## Messaging
- Produces to `orders.created.v2` (event: customer created)