# 6dgu-api
## Overview
Component 6dgu-api of 6DGU.
## Technology Stack
- React
- PostgreSQL