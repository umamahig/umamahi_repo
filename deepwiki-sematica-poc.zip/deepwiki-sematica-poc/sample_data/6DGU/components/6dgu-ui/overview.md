# 6dgu-ui
## Overview
Component 6dgu-ui of 6DGU.
## Technology Stack
- React
- PostgreSQL