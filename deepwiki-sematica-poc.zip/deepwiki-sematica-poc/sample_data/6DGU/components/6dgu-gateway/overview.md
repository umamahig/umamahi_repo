# 6dgu-gateway
## Overview
Component 6dgu-gateway of 6DGU.
## Technology Stack
- React
- PostgreSQL