---
appId: 6DGU
---
# 6DGU DeepWiki

## 1. Overview
6DGU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Reporting: supports reporting flows
- Payment Processing: supports payment processing flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- PostgreSQL
- React

## 8. Dependencies
- Direct: 2LBP
- Direct: 1ZKE
- Direct: 9ANX
- Indirect (transitive): 3WZK
- Indirect (transitive): 4UQF
