# 7fdq-worker
## Overview
Component 7fdq-worker of 7FDQ.
## Technology Stack
- Python 3.11
- PostgreSQL