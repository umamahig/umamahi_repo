# 7fdq-batch
## Overview
Component 7fdq-batch of 7FDQ.
## Technology Stack
- Oracle
- Redis