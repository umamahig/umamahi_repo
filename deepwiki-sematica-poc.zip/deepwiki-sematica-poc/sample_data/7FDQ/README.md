---
appId: 7FDQ
---
# 7FDQ DeepWiki

## 1. Overview
7FDQ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Oracle
- Redis
- Python 3.11
- PostgreSQL

## 8. Dependencies
- Direct: 3ATB
- Direct: 9HMH
- Direct: 6DGU
- Indirect (transitive): 6XWP
- Indirect (transitive): 1AAW
