# 1nzs-api
## Overview
Component 1nzs-api of 1NZS.
## Technology Stack
- Python 3.11
- PostgreSQL