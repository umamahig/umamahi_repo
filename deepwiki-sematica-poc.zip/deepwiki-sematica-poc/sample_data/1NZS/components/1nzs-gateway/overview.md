# 1nzs-gateway
## Overview
Component 1nzs-gateway of 1NZS.
## Technology Stack
- PostgreSQL
- Python 3.11