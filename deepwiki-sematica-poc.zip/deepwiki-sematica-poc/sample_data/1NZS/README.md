---
appId: 1NZS
---
# 1NZS DeepWiki

## 1. Overview
1NZS is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Python 3.11
- PostgreSQL

## 8. Dependencies
- Direct: 2ZBC
- Direct: 4JLV
- Direct: 2RQR
- Indirect (transitive): 2CLV
- Indirect (transitive): 1KAV
