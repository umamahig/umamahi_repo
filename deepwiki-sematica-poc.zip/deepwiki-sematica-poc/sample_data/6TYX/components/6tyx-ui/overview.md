# 6tyx-ui
## Overview
Component 6tyx-ui of 6TYX.
## Technology Stack
- React
- Kubernetes
## Messaging
- Produces to `orders.updated.v2` (event: order placed)