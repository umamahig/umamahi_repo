---
appId: 6TYX
---
# 6TYX DeepWiki

## 1. Overview
6TYX is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Identity Management: supports identity management flows
- Notifications: supports notifications flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- React
- Spring Boot 3.2
- Docker

## 8. Dependencies
- Direct: 9HQR
- Direct: 3PUJ
- Direct: 2RQR
- Indirect (transitive): 5ZVL
- Indirect (transitive): 4LUE

## 11. Messaging & Events
### Produces
- `orders.updated.v2` (event: account locked)
- `customers.created.v1` (event: payment settled)
### Consumes
- `orders.created.v2`
- `orders.updated.v1`
