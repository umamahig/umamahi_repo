---
appId: 8RDA
---
# 8RDA DeepWiki

## 1. Overview
8RDA is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows
- Payment Processing: supports payment processing flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- Go
- Java 17

## 8. Dependencies
- Direct: 8SNU
- Direct: 9PSX
- Direct: 4LUE
- Indirect (transitive): 3STG
- Indirect (transitive): 6CQX

## 11. Messaging & Events
### Produces
- `payments.updated.v1` (event: item updated)
- `orders.created.v2` (event: account locked)
### Consumes
- `customers.settled.v2`
- `orders.updated.v2`
