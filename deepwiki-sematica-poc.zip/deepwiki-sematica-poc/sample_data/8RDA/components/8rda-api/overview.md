# 8rda-api
## Overview
Component 8rda-api of 8RDA.
## Technology Stack
- Kubernetes
- Java 17
## Messaging
- Produces to `payments.updated.v1` (event: customer created)