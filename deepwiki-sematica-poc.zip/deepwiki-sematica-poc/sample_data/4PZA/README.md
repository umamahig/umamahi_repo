---
appId: 4PZA
---
# 4PZA DeepWiki

## 1. Overview
4PZA is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Notifications: supports notifications flows
- Identity Management: supports identity management flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Go
- Node.js 20
- Oracle
- Java 17

## 8. Dependencies
- Direct: 6PGJ
- Direct: 3CTJ
- Direct: 6KUT
- Indirect (transitive): 3WZK
- Indirect (transitive): 8SNU
