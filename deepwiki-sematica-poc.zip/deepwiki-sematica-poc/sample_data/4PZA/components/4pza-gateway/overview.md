# 4pza-gateway
## Overview
Component 4pza-gateway of 4PZA.
## Technology Stack
- Oracle
- Go