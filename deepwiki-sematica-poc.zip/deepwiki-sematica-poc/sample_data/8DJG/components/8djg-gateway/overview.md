# 8djg-gateway
## Overview
Component 8djg-gateway of 8DJG.
## Technology Stack
- Node.js 20
- PostgreSQL