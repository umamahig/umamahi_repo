---
appId: 8DJG
---
# 8DJG DeepWiki

## 1. Overview
8DJG is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Reporting: supports reporting flows
- Order Fulfilment: supports order fulfilment flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Node.js 20
- PostgreSQL
- Python 3.11

## 8. Dependencies
- Direct: 3UCJ
- Direct: 9HAG
- Direct: 9BNG
- Indirect (transitive): 1ZKE
- Indirect (transitive): 8RDA
