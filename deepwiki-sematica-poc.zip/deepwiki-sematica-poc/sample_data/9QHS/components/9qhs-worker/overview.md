# 9qhs-worker
## Overview
Component 9qhs-worker of 9QHS.
## Technology Stack
- React
- Go
## Messaging
- Produces to `orders.created.v1` (event: payment settled)