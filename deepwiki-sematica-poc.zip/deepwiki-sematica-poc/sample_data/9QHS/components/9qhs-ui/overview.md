# 9qhs-ui
## Overview
Component 9qhs-ui of 9QHS.
## Technology Stack
- Go
- Spring Boot 3.2