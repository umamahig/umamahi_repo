# 9qhs-api
## Overview
Component 9qhs-api of 9QHS.
## Technology Stack
- React
- Node.js 20
## Messaging
- Produces to `orders.created.v1` (event: payment settled)