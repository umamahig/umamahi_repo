---
appId: 9QHS
---
# 9QHS DeepWiki

## 1. Overview
9QHS is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Go
- React
- Node.js 20
- Docker
- Spring Boot 3.2

## 8. Dependencies
- Direct: 2RQR
- Direct: 1QAJ
- Direct: 6TYX
- Indirect (transitive): 2LBP
- Indirect (transitive): 4BKC

## 11. Messaging & Events
### Produces
- `orders.created.v1` (event: customer created)
- `orders.updated.v2` (event: payment settled)
### Consumes
- `catalog.created.v2`
- `catalog.settled.v1`
