---
appId: 8EUT
---
# 8EUT DeepWiki

## 1. Overview
8EUT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Angular
- Java 17
- React
- Docker
- Oracle

## 8. Dependencies
- Direct: 4LUE
- Direct: 1TTV
- Direct: 4PZA
- Indirect (transitive): 4JDJ
- Indirect (transitive): 9BNG

## 11. Messaging & Events
### Produces
- `customers.settled.v1` (event: account locked)
- `audit.updated.v1` (event: customer created)
### Consumes
- `customers.settled.v1`
- `orders.created.v1`
