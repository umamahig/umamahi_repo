# 8eut-ui
## Overview
Component 8eut-ui of 8EUT.
## Technology Stack
- Docker
- Angular
## Messaging
- Produces to `customers.settled.v1` (event: payment settled)