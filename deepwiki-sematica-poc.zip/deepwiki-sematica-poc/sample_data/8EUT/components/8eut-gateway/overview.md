# 8eut-gateway
## Overview
Component 8eut-gateway of 8EUT.
## Technology Stack
- Java 17
- Oracle