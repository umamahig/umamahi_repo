# 4lue-worker
## Overview
Component 4lue-worker of 4LUE.
## Technology Stack
- Go
- Angular
## Messaging
- Produces to `orders.created.v2` (event: order placed)