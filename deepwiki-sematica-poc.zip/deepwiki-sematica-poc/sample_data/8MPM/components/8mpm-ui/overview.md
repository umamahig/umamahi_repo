# 8mpm-ui
## Overview
Component 8mpm-ui of 8MPM.
## Technology Stack
- Go
- Oracle