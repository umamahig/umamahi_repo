# 8mpm-api
## Overview
Component 8mpm-api of 8MPM.
## Technology Stack
- Kafka
- Oracle