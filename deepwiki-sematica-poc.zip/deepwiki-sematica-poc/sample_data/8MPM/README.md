---
appId: 8MPM
---
# 8MPM DeepWiki

## 1. Overview
8MPM is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Identity Management: supports identity management flows
- Notifications: supports notifications flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Go
- Oracle
- Kafka

## 8. Dependencies
- Direct: 1TTV
- Direct: 8DJG
- Direct: 7THW
- Indirect (transitive): 3FJS
- Indirect (transitive): 6DGU
