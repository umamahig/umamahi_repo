---
appId: 6KUT
---
# 6KUT DeepWiki

## 1. Overview
6KUT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Oracle
- Docker
- Java 17

## 8. Dependencies
- Direct: 6CQX
- Direct: 8YSX
- Direct: 1NPV
- Indirect (transitive): 9GVP
- Indirect (transitive): 4UQF
