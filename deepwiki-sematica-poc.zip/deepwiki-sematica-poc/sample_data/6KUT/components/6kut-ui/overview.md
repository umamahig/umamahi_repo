# 6kut-ui
## Overview
Component 6kut-ui of 6KUT.
## Technology Stack
- Java 17
- Oracle