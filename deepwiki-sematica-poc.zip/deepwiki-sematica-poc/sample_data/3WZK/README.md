---
appId: 3WZK
---
# 3WZK DeepWiki

## 1. Overview
3WZK is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Reporting: supports reporting flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Go
- Oracle
- Python 3.11
- React
- PostgreSQL

## 8. Dependencies
- Direct: 3XHF
- Direct: 1NXU
- Direct: 1CAT
- Indirect (transitive): 2XNK
- Indirect (transitive): 7KAF

## 11. Messaging & Events
### Produces
- `orders.created.v2` (event: item updated)
- `audit.updated.v1` (event: customer created)
### Consumes
- `orders.failed.v1`
- `customers.settled.v1`
