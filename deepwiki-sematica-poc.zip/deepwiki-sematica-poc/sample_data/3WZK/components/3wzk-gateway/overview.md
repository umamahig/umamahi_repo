# 3wzk-gateway
## Overview
Component 3wzk-gateway of 3WZK.
## Technology Stack
- React
- Oracle