# 3wzk-worker
## Overview
Component 3wzk-worker of 3WZK.
## Technology Stack
- React
- Python 3.11