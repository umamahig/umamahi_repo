# 4udl-ui
## Overview
Component 4udl-ui of 4UDL.
## Technology Stack
- React
- Redis
## Messaging
- Produces to `payments.settled.v1` (event: account locked)