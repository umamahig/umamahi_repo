# 4udl-batch
## Overview
Component 4udl-batch of 4UDL.
## Technology Stack
- Redis
- React
## Messaging
- Produces to `payments.settled.v1` (event: account locked)