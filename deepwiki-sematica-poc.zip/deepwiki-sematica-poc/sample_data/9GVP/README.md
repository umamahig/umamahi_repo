---
appId: 9GVP
---
# 9GVP DeepWiki

## 1. Overview
9GVP is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Catalog Management: supports catalog management flows
- Customer Onboarding: supports customer onboarding flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Go
- Oracle

## 8. Dependencies
- Direct: 2QJD
- Direct: 2ZLZ
- Direct: 8YSX
- Indirect (transitive): 3XJW
- Indirect (transitive): 2QJD
