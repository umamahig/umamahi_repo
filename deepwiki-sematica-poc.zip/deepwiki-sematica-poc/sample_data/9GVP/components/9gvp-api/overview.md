# 9gvp-api
## Overview
Component 9gvp-api of 9GVP.
## Technology Stack
- Go
- Oracle