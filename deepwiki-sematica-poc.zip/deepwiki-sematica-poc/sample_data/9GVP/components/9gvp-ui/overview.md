# 9gvp-ui
## Overview
Component 9gvp-ui of 9GVP.
## Technology Stack
- Oracle
- Go