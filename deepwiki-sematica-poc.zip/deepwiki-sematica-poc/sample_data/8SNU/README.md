---
appId: 8SNU
---
# 8SNU DeepWiki

## 1. Overview
8SNU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Node.js 20
- PostgreSQL
- Spring Boot 3.2
- Redis
- Python 3.11

## 8. Dependencies
- Direct: 1NZS
- Direct: 8MPM
- Direct: 3MKC
- Indirect (transitive): 1QAJ
- Indirect (transitive): 4LUE
