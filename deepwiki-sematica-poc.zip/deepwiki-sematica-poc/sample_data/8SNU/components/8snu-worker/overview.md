# 8snu-worker
## Overview
Component 8snu-worker of 8SNU.
## Technology Stack
- PostgreSQL
- Python 3.11