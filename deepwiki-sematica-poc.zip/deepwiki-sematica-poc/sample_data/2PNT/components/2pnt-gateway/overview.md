# 2pnt-gateway
## Overview
Component 2pnt-gateway of 2PNT.
## Technology Stack
- Kafka
- Oracle