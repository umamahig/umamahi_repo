# 2pnt-worker
## Overview
Component 2pnt-worker of 2PNT.
## Technology Stack
- Kafka
- Oracle