# 2pnt-api
## Overview
Component 2pnt-api of 2PNT.
## Technology Stack
- Node.js 20
- Kafka