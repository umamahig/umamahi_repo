---
appId: 2PNT
---
# 2PNT DeepWiki

## 1. Overview
2PNT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Python 3.11
- Node.js 20
- Docker
- Oracle
- Kafka

## 8. Dependencies
- Direct: 3FJS
- Direct: 2ZLZ
- Direct: 6CQX
- Indirect (transitive): 9RAL
- Indirect (transitive): 9GVP
