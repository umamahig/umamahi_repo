# 2rqr-ui
## Overview
Component 2rqr-ui of 2RQR.
## Technology Stack
- Docker
- Kubernetes
## Messaging
- Produces to `customers.settled.v2` (event: account locked)