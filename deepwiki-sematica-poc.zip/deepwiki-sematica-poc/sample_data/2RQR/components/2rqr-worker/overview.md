# 2rqr-worker
## Overview
Component 2rqr-worker of 2RQR.
## Technology Stack
- Docker
- Kubernetes