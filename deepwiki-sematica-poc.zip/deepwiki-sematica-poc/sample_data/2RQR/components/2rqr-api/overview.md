# 2rqr-api
## Overview
Component 2rqr-api of 2RQR.
## Technology Stack
- Docker
- Kubernetes
## Messaging
- Produces to `customers.settled.v2` (event: item updated)