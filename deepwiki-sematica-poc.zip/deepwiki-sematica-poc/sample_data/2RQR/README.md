---
appId: 2RQR
---
# 2RQR DeepWiki

## 1. Overview
2RQR is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Fraud Detection: supports fraud detection flows
- Catalog Management: supports catalog management flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Docker
- Kubernetes

## 8. Dependencies
- Direct: 6DGU
- Direct: 2CLV
- Direct: 9DFS
- Indirect (transitive): 6DGU
- Indirect (transitive): 3WZK

## 11. Messaging & Events
### Produces
- `customers.settled.v2` (event: customer created)
- `orders.updated.v1` (event: customer created)
### Consumes
- `audit.updated.v2`
- `orders.failed.v2`
