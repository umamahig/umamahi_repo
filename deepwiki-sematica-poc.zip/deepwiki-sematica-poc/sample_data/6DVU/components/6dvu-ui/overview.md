# 6dvu-ui
## Overview
Component 6dvu-ui of 6DVU.
## Technology Stack
- Node.js 20
- Angular