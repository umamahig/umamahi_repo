# 6dvu-gateway
## Overview
Component 6dvu-gateway of 6DVU.
## Technology Stack
- Oracle
- Angular