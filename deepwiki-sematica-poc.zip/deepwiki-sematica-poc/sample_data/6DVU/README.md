---
appId: 6DVU
---
# 6DVU DeepWiki

## 1. Overview
6DVU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Notifications: supports notifications flows
- Order Fulfilment: supports order fulfilment flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Oracle
- Angular
- Node.js 20

## 8. Dependencies
- Direct: 5NLP
- Direct: 1XCC
- Direct: 6CQX
- Indirect (transitive): 1ZKE
- Indirect (transitive): 9RAL
