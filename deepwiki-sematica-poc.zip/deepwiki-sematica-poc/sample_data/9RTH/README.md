---
appId: 9RTH
---
# 9RTH DeepWiki

## 1. Overview
9RTH is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Angular
- Oracle

## 8. Dependencies
- Direct: 4BKC
- Direct: 4LUE
- Direct: 9PSX
- Indirect (transitive): 8EUT
- Indirect (transitive): 9HMH
