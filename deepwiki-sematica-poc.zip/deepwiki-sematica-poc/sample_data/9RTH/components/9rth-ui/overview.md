# 9rth-ui
## Overview
Component 9rth-ui of 9RTH.
## Technology Stack
- Oracle
- Angular