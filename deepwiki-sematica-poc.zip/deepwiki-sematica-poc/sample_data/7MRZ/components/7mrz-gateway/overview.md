# 7mrz-gateway
## Overview
Component 7mrz-gateway of 7MRZ.
## Technology Stack
- Kafka
- Oracle