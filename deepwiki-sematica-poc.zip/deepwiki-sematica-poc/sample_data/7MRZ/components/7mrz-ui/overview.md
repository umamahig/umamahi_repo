# 7mrz-ui
## Overview
Component 7mrz-ui of 7MRZ.
## Technology Stack
- React
- Kafka