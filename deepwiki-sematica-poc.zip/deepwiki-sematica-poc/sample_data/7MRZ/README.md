---
appId: 7MRZ
---
# 7MRZ DeepWiki

## 1. Overview
7MRZ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Identity Management: supports identity management flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- React
- Kafka
- Oracle

## 8. Dependencies
- Direct: 8MPM
- Direct: 8EUT
- Direct: 7KAF
- Indirect (transitive): 3ATB
- Indirect (transitive): 2KKZ
