---
appId: 1RHZ
---
# 1RHZ DeepWiki

## 1. Overview
1RHZ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Notifications: supports notifications flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- React
- Angular
- Oracle
- Redis
- Kubernetes

## 8. Dependencies
- Direct: 7THW
- Direct: 9GVP
- Direct: 8DJG
- Indirect (transitive): 3FFT
- Indirect (transitive): 7FDQ

## 11. Messaging & Events
### Produces
- `orders.failed.v1` (event: account locked)
- `orders.created.v1` (event: payment settled)
### Consumes
- `orders.created.v2`
- `customers.settled.v2`
