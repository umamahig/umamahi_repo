# 1rhz-gateway
## Overview
Component 1rhz-gateway of 1RHZ.
## Technology Stack
- Redis
- Angular
## Messaging
- Produces to `orders.failed.v1` (event: item updated)