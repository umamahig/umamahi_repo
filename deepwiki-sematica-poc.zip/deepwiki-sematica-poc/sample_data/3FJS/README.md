---
appId: 3FJS
---
# 3FJS DeepWiki

## 1. Overview
3FJS is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Node.js 20
- Redis

## 8. Dependencies
- Direct: 4WFT
- Direct: 4UCJ
- Direct: 8YSX
- Indirect (transitive): 3WZK
- Indirect (transitive): 4KKU
