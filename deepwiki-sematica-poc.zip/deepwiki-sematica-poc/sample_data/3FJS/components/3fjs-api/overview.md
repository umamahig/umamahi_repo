# 3fjs-api
## Overview
Component 3fjs-api of 3FJS.
## Technology Stack
- Node.js 20
- Redis