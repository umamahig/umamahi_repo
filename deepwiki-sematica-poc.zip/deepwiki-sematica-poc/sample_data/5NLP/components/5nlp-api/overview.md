# 5nlp-api
## Overview
Component 5nlp-api of 5NLP.
## Technology Stack
- Oracle
- Redis