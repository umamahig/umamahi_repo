# 5nlp-batch
## Overview
Component 5nlp-batch of 5NLP.
## Technology Stack
- Redis
- Oracle
## Messaging
- Produces to `payments.updated.v1` (event: account locked)