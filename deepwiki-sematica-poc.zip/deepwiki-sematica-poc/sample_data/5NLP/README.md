---
appId: 5NLP
---
# 5NLP DeepWiki

## 1. Overview
5NLP is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows
- Reporting: supports reporting flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Redis
- Oracle

## 8. Dependencies
- Direct: 8EUT
- Direct: 1YQJ
- Direct: 8LDG
- Indirect (transitive): 6KUT
- Indirect (transitive): 2XNK

## 11. Messaging & Events
### Produces
- `payments.updated.v1` (event: customer created)
- `orders.created.v1` (event: account locked)
### Consumes
- `orders.failed.v1`
- `catalog.created.v2`
