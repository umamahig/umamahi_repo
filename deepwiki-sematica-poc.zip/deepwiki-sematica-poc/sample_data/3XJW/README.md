---
appId: 3XJW
---
# 3XJW DeepWiki

## 1. Overview
3XJW is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Angular
- Node.js 20
- Oracle
- React
- Kafka

## 8. Dependencies
- Direct: 4UCJ
- Direct: 4QKA
- Direct: 4UQF
- Indirect (transitive): 8EUT
- Indirect (transitive): 8YSX
