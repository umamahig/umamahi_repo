# 3xjw-api
## Overview
Component 3xjw-api of 3XJW.
## Technology Stack
- Node.js 20
- Oracle