# 3xjw-ui
## Overview
Component 3xjw-ui of 3XJW.
## Technology Stack
- Angular
- Oracle