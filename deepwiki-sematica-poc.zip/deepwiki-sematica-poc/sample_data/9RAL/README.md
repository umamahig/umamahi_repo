---
appId: 9RAL
---
# 9RAL DeepWiki

## 1. Overview
9RAL is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Identity Management: supports identity management flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Spring Boot 3.2
- Oracle
- React
- Docker

## 8. Dependencies
- Direct: 1NPV
- Direct: 8NLN
- Direct: 7CUT
- Indirect (transitive): 7MRZ
- Indirect (transitive): 1TTV
