---
appId: 7BRM
---
# 7BRM DeepWiki

## 1. Overview
7BRM is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- React

## 8. Dependencies
- Direct: 1CAT
- Direct: 6KUT
- Direct: 4LUE
- Indirect (transitive): 2KKZ
- Indirect (transitive): 8YSX
