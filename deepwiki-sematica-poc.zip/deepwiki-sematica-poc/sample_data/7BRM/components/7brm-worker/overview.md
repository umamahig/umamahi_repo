# 7brm-worker
## Overview
Component 7brm-worker of 7BRM.
## Technology Stack
- Kubernetes
- React