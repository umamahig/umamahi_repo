# 1xcc-gateway
## Overview
Component 1xcc-gateway of 1XCC.
## Technology Stack
- Redis
- React