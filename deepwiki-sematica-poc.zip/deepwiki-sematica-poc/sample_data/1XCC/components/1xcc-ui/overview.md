# 1xcc-ui
## Overview
Component 1xcc-ui of 1XCC.
## Technology Stack
- Node.js 20
- Spring Boot 3.2