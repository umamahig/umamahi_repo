---
appId: 1XCC
---
# 1XCC DeepWiki

## 1. Overview
1XCC is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Reporting: supports reporting flows
- Catalog Management: supports catalog management flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Node.js 20
- React
- Spring Boot 3.2
- Redis

## 8. Dependencies
- Direct: 1RBK
- Direct: 9GVP
- Direct: 3ATB
- Indirect (transitive): 7TWD
- Indirect (transitive): 8JXT
