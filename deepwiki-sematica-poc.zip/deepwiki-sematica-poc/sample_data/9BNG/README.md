---
appId: 9BNG
---
# 9BNG DeepWiki

## 1. Overview
9BNG is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Identity Management: supports identity management flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Java 17
- Spring Boot 3.2
- Redis

## 8. Dependencies
- Direct: 4KKU
- Direct: 2CLV
- Direct: 3XHF
- Indirect (transitive): 2KKZ
- Indirect (transitive): 6XWP
