# 9bng-gateway
## Overview
Component 9bng-gateway of 9BNG.
## Technology Stack
- Java 17
- Spring Boot 3.2