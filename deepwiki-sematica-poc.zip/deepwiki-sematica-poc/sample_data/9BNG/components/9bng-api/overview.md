# 9bng-api
## Overview
Component 9bng-api of 9BNG.
## Technology Stack
- Redis
- Spring Boot 3.2