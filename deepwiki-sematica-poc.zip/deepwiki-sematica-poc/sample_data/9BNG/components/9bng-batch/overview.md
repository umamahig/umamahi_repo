# 9bng-batch
## Overview
Component 9bng-batch of 9BNG.
## Technology Stack
- Java 17
- Spring Boot 3.2