# 4jdj-worker
## Overview
Component 4jdj-worker of 4JDJ.
## Technology Stack
- Go
- Redis