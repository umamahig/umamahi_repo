# 4jdj-batch
## Overview
Component 4jdj-batch of 4JDJ.
## Technology Stack
- React
- Redis
## Messaging
- Produces to `orders.updated.v2` (event: order placed)