# 4jdj-gateway
## Overview
Component 4jdj-gateway of 4JDJ.
## Technology Stack
- Redis
- Oracle
## Messaging
- Produces to `orders.updated.v2` (event: customer created)