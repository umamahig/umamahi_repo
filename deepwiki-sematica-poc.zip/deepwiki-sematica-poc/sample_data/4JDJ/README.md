---
appId: 4JDJ
---
# 4JDJ DeepWiki

## 1. Overview
4JDJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Reporting: supports reporting flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Redis
- Oracle
- Go
- React

## 8. Dependencies
- Direct: 7FDQ
- Direct: 3WZK
- Direct: 4UCJ
- Indirect (transitive): 4UCJ
- Indirect (transitive): 8DJG

## 11. Messaging & Events
### Produces
- `orders.updated.v2` (event: customer created)
- `catalog.created.v2` (event: customer created)
### Consumes
- `orders.failed.v1`
- `audit.settled.v1`
