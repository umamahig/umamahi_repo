# 2ntm-gateway
## Overview
Component 2ntm-gateway of 2NTM.
## Technology Stack
- Redis
- Docker