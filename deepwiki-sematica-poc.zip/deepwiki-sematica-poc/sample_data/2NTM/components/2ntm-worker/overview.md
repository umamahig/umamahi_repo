# 2ntm-worker
## Overview
Component 2ntm-worker of 2NTM.
## Technology Stack
- Docker
- Python 3.11