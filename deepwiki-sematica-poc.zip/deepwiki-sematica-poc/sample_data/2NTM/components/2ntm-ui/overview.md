# 2ntm-ui
## Overview
Component 2ntm-ui of 2NTM.
## Technology Stack
- Docker
- Python 3.11