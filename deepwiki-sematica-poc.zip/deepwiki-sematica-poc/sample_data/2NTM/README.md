---
appId: 2NTM
---
# 2NTM DeepWiki

## 1. Overview
2NTM is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Docker
- Redis
- Python 3.11

## 8. Dependencies
- Direct: 1XCC
- Direct: 2QJD
- Direct: 3FJS
- Indirect (transitive): 3XHF
- Indirect (transitive): 9ANX
