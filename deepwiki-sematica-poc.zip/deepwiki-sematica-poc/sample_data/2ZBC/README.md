---
appId: 2ZBC
---
# 2ZBC DeepWiki

## 1. Overview
2ZBC is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Identity Management: supports identity management flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Node.js 20
- Python 3.11
- Redis
- Kubernetes

## 8. Dependencies
- Direct: 3FJS
- Direct: 9PSX
- Direct: 4LUE
- Indirect (transitive): 6DVU
- Indirect (transitive): 4JLV
