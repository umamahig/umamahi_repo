# 2zbc-worker
## Overview
Component 2zbc-worker of 2ZBC.
## Technology Stack
- Python 3.11
- Kubernetes