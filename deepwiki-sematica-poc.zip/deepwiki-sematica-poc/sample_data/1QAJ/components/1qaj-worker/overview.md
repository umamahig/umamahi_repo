# 1qaj-worker
## Overview
Component 1qaj-worker of 1QAJ.
## Technology Stack
- Docker
- Go