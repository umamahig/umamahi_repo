# 1qaj-api
## Overview
Component 1qaj-api of 1QAJ.
## Technology Stack
- PostgreSQL
- Spring Boot 3.2