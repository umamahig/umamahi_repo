# 1qaj-ui
## Overview
Component 1qaj-ui of 1QAJ.
## Technology Stack
- Go
- Docker