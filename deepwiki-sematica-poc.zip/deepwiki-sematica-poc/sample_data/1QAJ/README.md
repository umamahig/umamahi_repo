---
appId: 1QAJ
---
# 1QAJ DeepWiki

## 1. Overview
1QAJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Catalog Management: supports catalog management flows
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Spring Boot 3.2
- PostgreSQL
- Go
- Angular
- Docker

## 8. Dependencies
- Direct: 2LBP
- Direct: 3STG
- Direct: 1KAV
- Indirect (transitive): 8NLN
- Indirect (transitive): 5TJY
