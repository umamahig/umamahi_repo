---
appId: 9MUM
---
# 9MUM DeepWiki

## 1. Overview
9MUM is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Java 17
- PostgreSQL
- Spring Boot 3.2
- Node.js 20

## 8. Dependencies
- Direct: 4BKC
- Direct: 4PZA
- Direct: 1CPD
- Indirect (transitive): 8JXT
- Indirect (transitive): 9GSP
