# 9mum-batch
## Overview
Component 9mum-batch of 9MUM.
## Technology Stack
- Java 17
- Node.js 20