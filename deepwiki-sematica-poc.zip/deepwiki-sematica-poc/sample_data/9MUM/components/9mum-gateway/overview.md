# 9mum-gateway
## Overview
Component 9mum-gateway of 9MUM.
## Technology Stack
- PostgreSQL
- Node.js 20