# 9mum-worker
## Overview
Component 9mum-worker of 9MUM.
## Technology Stack
- PostgreSQL
- Java 17