# 3bzf-ui
## Overview
Component 3bzf-ui of 3BZF.
## Technology Stack
- Kubernetes
- Python 3.11