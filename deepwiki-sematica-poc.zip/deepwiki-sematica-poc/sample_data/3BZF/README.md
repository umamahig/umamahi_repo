---
appId: 3BZF
---
# 3BZF DeepWiki

## 1. Overview
3BZF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Identity Management: supports identity management flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Python 3.11
- Kafka
- Node.js 20
- Java 17
- Kubernetes

## 8. Dependencies
- Direct: 9HAG
- Direct: 5NLP
- Direct: 7THW
- Indirect (transitive): 4BKC
- Indirect (transitive): 3MKC
