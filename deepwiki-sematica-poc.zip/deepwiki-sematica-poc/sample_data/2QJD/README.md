---
appId: 2QJD
---
# 2QJD DeepWiki

## 1. Overview
2QJD is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Reporting: supports reporting flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Redis
- Node.js 20
- Oracle
- Docker

## 8. Dependencies
- Direct: 4KKU
- Direct: 9BNG
- Direct: 4BKC
- Indirect (transitive): 9GSP
- Indirect (transitive): 7MRZ
