# 3fft-gateway
## Overview
Component 3fft-gateway of 3FFT.
## Technology Stack
- PostgreSQL
- Docker