# 3fft-ui
## Overview
Component 3fft-ui of 3FFT.
## Technology Stack
- PostgreSQL
- Angular