# 3fft-api
## Overview
Component 3fft-api of 3FFT.
## Technology Stack
- Angular
- PostgreSQL
## Messaging
- Produces to `customers.created.v1` (event: account locked)