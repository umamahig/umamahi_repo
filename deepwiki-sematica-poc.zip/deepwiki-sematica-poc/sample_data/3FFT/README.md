---
appId: 3FFT
---
# 3FFT DeepWiki

## 1. Overview
3FFT is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Angular
- Docker
- PostgreSQL

## 8. Dependencies
- Direct: 7UGR
- Direct: 1TTV
- Direct: 9HQR
- Indirect (transitive): 3STG
- Indirect (transitive): 1RBK

## 11. Messaging & Events
### Produces
- `customers.created.v1` (event: payment settled)
- `payments.settled.v1` (event: account locked)
### Consumes
- `customers.settled.v1`
- `orders.failed.v2`
