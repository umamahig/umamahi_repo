# 2nee-worker
## Overview
Component 2nee-worker of 2NEE.
## Technology Stack
- Java 17
- Node.js 20