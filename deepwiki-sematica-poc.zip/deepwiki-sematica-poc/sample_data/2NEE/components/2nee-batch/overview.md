# 2nee-batch
## Overview
Component 2nee-batch of 2NEE.
## Technology Stack
- Java 17
- PostgreSQL