---
appId: 2NEE
---
# 2NEE DeepWiki

## 1. Overview
2NEE is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Node.js 20
- PostgreSQL
- Java 17

## 8. Dependencies
- Direct: 7FDQ
- Direct: 3WZK
- Direct: 7MRZ
- Indirect (transitive): 2RQR
- Indirect (transitive): 1NXU
