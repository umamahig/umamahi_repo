---
appId: 3ATB
---
# 3ATB DeepWiki

## 1. Overview
3ATB is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Spring Boot 3.2
- Java 17
- Node.js 20

## 8. Dependencies
- Direct: 8RDA
- Direct: 6PGJ
- Direct: 7TWD
- Indirect (transitive): 2PNT
- Indirect (transitive): 2XNK
