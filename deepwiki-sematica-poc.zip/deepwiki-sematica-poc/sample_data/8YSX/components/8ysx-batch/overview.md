# 8ysx-batch
## Overview
Component 8ysx-batch of 8YSX.
## Technology Stack
- Go
- Kafka