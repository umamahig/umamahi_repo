# 8ysx-gateway
## Overview
Component 8ysx-gateway of 8YSX.
## Technology Stack
- Go
- Java 17