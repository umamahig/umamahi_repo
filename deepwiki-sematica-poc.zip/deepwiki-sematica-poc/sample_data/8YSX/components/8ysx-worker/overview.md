# 8ysx-worker
## Overview
Component 8ysx-worker of 8YSX.
## Technology Stack
- Java 17
- Go