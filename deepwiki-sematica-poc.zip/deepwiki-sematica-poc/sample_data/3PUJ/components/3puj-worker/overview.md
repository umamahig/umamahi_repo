# 3puj-worker
## Overview
Component 3puj-worker of 3PUJ.
## Technology Stack
- Spring Boot 3.2
- Go