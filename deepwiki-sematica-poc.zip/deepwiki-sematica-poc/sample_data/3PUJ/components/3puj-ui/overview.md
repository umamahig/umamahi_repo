# 3puj-ui
## Overview
Component 3puj-ui of 3PUJ.
## Technology Stack
- Redis
- Spring Boot 3.2