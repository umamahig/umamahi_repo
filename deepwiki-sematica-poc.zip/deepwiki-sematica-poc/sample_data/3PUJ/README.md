---
appId: 3PUJ
---
# 3PUJ DeepWiki

## 1. Overview
3PUJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Order Fulfilment: supports order fulfilment flows
- Catalog Management: supports catalog management flows
- Identity Management: supports identity management flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Redis
- Go
- Spring Boot 3.2

## 8. Dependencies
- Direct: 6XWP
- Direct: 9MUM
- Direct: 7KAF
- Indirect (transitive): 8JXT
- Indirect (transitive): 3CTJ
