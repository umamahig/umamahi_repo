---
appId: 7THW
---
# 7THW DeepWiki

## 1. Overview
7THW is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Payment Processing: supports payment processing flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- React
- Go
- Java 17

## 8. Dependencies
- Direct: 4WFT
- Direct: 9HAG
- Direct: 8DJG
- Indirect (transitive): 4KKU
- Indirect (transitive): 2CLV

## 11. Messaging & Events
### Produces
- `orders.created.v1` (event: account locked)
- `orders.created.v2` (event: account locked)
### Consumes
- `orders.created.v1`
- `audit.updated.v2`
