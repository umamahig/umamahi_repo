# 7thw-ui
## Overview
Component 7thw-ui of 7THW.
## Technology Stack
- Java 17
- Go
## Messaging
- Produces to `orders.created.v1` (event: order placed)