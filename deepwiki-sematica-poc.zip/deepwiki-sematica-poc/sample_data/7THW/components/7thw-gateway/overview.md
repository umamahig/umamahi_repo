# 7thw-gateway
## Overview
Component 7thw-gateway of 7THW.
## Technology Stack
- Go
- React
## Messaging
- Produces to `orders.created.v1` (event: order placed)