---
appId: 5QYL
---
# 5QYL DeepWiki

## 1. Overview
5QYL is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Payment Processing: supports payment processing flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Java 17
- React
- Spring Boot 3.2
- PostgreSQL

## 8. Dependencies
- Direct: 4BKC
- Direct: 9HMH
- Direct: 6KUT
- Indirect (transitive): 9HAG
- Indirect (transitive): 7CUT
