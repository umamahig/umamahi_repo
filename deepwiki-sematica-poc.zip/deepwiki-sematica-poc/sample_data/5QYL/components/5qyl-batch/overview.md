# 5qyl-batch
## Overview
Component 5qyl-batch of 5QYL.
## Technology Stack
- React
- Java 17