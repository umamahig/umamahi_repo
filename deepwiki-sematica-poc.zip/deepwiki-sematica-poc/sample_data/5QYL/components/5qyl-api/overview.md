# 5qyl-api
## Overview
Component 5qyl-api of 5QYL.
## Technology Stack
- React
- Spring Boot 3.2