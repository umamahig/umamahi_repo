# 5qyl-gateway
## Overview
Component 5qyl-gateway of 5QYL.
## Technology Stack
- React
- Java 17