---
appId: 8LDG
---
# 8LDG DeepWiki

## 1. Overview
8LDG is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- Go
- Kubernetes
- Node.js 20
- Angular

## 8. Dependencies
- Direct: 8SNU
- Direct: 4UCJ
- Direct: 7UGR
- Indirect (transitive): 9THN
- Indirect (transitive): 3BZF

## 11. Messaging & Events
### Produces
- `orders.failed.v2` (event: account locked)
- `catalog.settled.v1` (event: customer created)
### Consumes
- `audit.updated.v2`
- `audit.updated.v2`
