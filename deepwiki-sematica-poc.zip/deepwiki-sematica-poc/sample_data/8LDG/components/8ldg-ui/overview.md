# 8ldg-ui
## Overview
Component 8ldg-ui of 8LDG.
## Technology Stack
- Angular
- Kubernetes
## Messaging
- Produces to `orders.failed.v2` (event: item updated)