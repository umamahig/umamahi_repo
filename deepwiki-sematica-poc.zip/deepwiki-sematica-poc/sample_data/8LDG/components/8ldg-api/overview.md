# 8ldg-api
## Overview
Component 8ldg-api of 8LDG.
## Technology Stack
- Kubernetes
- Node.js 20
## Messaging
- Produces to `orders.failed.v2` (event: payment settled)