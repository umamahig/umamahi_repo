---
appId: 1ZKE
---
# 1ZKE DeepWiki

## 1. Overview
1ZKE is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Identity Management: supports identity management flows
- Reporting: supports reporting flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Docker
- Redis
- Kubernetes

## 8. Dependencies
- Direct: 8EUT
- Direct: 7PXF
- Direct: 5QYL
- Indirect (transitive): 8RDA
- Indirect (transitive): 1TTV
