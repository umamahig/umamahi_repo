# 1zke-batch
## Overview
Component 1zke-batch of 1ZKE.
## Technology Stack
- Docker
- Redis