# 1zke-ui
## Overview
Component 1zke-ui of 1ZKE.
## Technology Stack
- Docker
- Redis