---
appId: 2CLV
---
# 2CLV DeepWiki

## 1. Overview
2CLV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Reporting: supports reporting flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Spring Boot 3.2
- Kafka
- PostgreSQL
- Angular
- Node.js 20

## 8. Dependencies
- Direct: 1NZS
- Direct: 4UQF
- Direct: 4LUE
- Indirect (transitive): 7CUT
- Indirect (transitive): 1KAV

## 11. Messaging & Events
### Produces
- `audit.updated.v2` (event: account locked)
- `customers.created.v1` (event: item updated)
### Consumes
- `audit.updated.v2`
- `orders.created.v1`
