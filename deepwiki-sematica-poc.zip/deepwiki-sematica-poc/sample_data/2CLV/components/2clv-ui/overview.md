# 2clv-ui
## Overview
Component 2clv-ui of 2CLV.
## Technology Stack
- Kafka
- Spring Boot 3.2