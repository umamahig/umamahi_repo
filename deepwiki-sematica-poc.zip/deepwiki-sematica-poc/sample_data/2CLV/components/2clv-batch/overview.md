# 2clv-batch
## Overview
Component 2clv-batch of 2CLV.
## Technology Stack
- Spring Boot 3.2
- Node.js 20