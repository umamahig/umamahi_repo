---
appId: 9GSP
---
# 9GSP DeepWiki

## 1. Overview
9GSP is a synthetic application used for the PoC.

## 3. Business Capabilities
- Notifications: supports notifications flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Spring Boot 3.2
- Redis
- Docker

## 8. Dependencies
- Direct: 2NEE
- Direct: 6DKH
- Direct: 8JXT
- Indirect (transitive): 3XHF
- Indirect (transitive): 7PXF

## 11. Messaging & Events
### Produces
- `orders.failed.v2` (event: customer created)
- `catalog.created.v2` (event: account locked)
### Consumes
- `orders.created.v2`
- `orders.updated.v2`
