# 9gsp-gateway
## Overview
Component 9gsp-gateway of 9GSP.
## Technology Stack
- Docker
- Redis
## Messaging
- Produces to `orders.failed.v2` (event: item updated)