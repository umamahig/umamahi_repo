# 9gsp-api
## Overview
Component 9gsp-api of 9GSP.
## Technology Stack
- Redis
- Spring Boot 3.2
## Messaging
- Produces to `orders.failed.v2` (event: payment settled)