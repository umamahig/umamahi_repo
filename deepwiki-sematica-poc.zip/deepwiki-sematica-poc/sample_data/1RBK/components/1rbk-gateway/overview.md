# 1rbk-gateway
## Overview
Component 1rbk-gateway of 1RBK.
## Technology Stack
- Kubernetes
- Kafka