# 1rbk-ui
## Overview
Component 1rbk-ui of 1RBK.
## Technology Stack
- Kubernetes
- Kafka