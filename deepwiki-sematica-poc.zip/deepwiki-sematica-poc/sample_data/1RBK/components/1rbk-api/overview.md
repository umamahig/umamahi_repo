# 1rbk-api
## Overview
Component 1rbk-api of 1RBK.
## Technology Stack
- Kafka
- Java 17