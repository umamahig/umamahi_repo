---
appId: 1RBK
---
# 1RBK DeepWiki

## 1. Overview
1RBK is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Notifications: supports notifications flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Angular
- Java 17
- Redis
- Kubernetes
- Kafka

## 8. Dependencies
- Direct: 5QYL
- Direct: 9GSP
- Direct: 3FJS
- Indirect (transitive): 1TTV
- Indirect (transitive): 9JML
