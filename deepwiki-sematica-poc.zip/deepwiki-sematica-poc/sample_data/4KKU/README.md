---
appId: 4KKU
---
# 4KKU DeepWiki

## 1. Overview
4KKU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Notifications: supports notifications flows
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- PostgreSQL
- Kafka
- Oracle
- Redis
- Java 17

## 8. Dependencies
- Direct: 2ZLZ
- Direct: 4BKC
- Direct: 8SNU
- Indirect (transitive): 2KKZ
- Indirect (transitive): 2QJD
