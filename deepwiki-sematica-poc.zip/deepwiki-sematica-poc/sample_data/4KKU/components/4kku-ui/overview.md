# 4kku-ui
## Overview
Component 4kku-ui of 4KKU.
## Technology Stack
- Redis
- Oracle