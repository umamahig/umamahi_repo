# 4kku-worker
## Overview
Component 4kku-worker of 4KKU.
## Technology Stack
- Kafka
- Oracle