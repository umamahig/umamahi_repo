# 4kku-gateway
## Overview
Component 4kku-gateway of 4KKU.
## Technology Stack
- Kafka
- Redis