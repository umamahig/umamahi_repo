# 1ghu-gateway
## Overview
Component 1ghu-gateway of 1GHU.
## Technology Stack
- Node.js 20
- Docker