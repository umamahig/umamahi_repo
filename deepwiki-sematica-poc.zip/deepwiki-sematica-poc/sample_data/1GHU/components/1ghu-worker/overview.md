# 1ghu-worker
## Overview
Component 1ghu-worker of 1GHU.
## Technology Stack
- Python 3.11
- Node.js 20