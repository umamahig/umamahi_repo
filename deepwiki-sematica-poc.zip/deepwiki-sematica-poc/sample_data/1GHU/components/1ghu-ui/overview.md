# 1ghu-ui
## Overview
Component 1ghu-ui of 1GHU.
## Technology Stack
- Docker
- Spring Boot 3.2