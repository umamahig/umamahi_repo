---
appId: 1GHU
---
# 1GHU DeepWiki

## 1. Overview
1GHU is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Identity Management: supports identity management flows
- Payment Processing: supports payment processing flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Docker
- Python 3.11
- Node.js 20
- Spring Boot 3.2

## 8. Dependencies
- Direct: 9THN
- Direct: 4KKU
- Direct: 3PUJ
- Indirect (transitive): 1RHZ
- Indirect (transitive): 1ZKE

## 11. Messaging & Events
### Produces
- `catalog.failed.v2` (event: item updated)
- `orders.failed.v2` (event: account locked)
### Consumes
- `orders.created.v1`
- `orders.updated.v1`
