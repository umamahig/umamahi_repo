# 5zvl-gateway
## Overview
Component 5zvl-gateway of 5ZVL.
## Technology Stack
- Oracle
- Docker