---
appId: 4JLV
---
# 4JLV DeepWiki

## 1. Overview
4JLV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Identity Management: supports identity management flows
- Catalog Management: supports catalog management flows
- Order Fulfilment: supports order fulfilment flows
- Customer Onboarding: supports customer onboarding flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Kubernetes
- Go
- React

## 8. Dependencies
- Direct: 7GDR
- Direct: 4UQF
- Direct: 2NEE
- Indirect (transitive): 7KAF
- Indirect (transitive): 6QVA
