---
appId: 3XHF
---
# 3XHF DeepWiki

## 1. Overview
3XHF is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: COTS

## 7. Technology Stack
- Docker
- PostgreSQL

## 8. Dependencies
- Direct: 1YQJ
- Direct: 7THW
- Direct: 3FJS
- Indirect (transitive): 1GHU
- Indirect (transitive): 9ANX
