# 3xhf-worker
## Overview
Component 3xhf-worker of 3XHF.
## Technology Stack
- PostgreSQL
- Docker