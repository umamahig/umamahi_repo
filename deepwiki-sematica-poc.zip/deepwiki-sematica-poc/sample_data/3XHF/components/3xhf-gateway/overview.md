# 3xhf-gateway
## Overview
Component 3xhf-gateway of 3XHF.
## Technology Stack
- PostgreSQL
- Docker