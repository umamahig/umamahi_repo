# 3xhf-api
## Overview
Component 3xhf-api of 3XHF.
## Technology Stack
- Docker
- PostgreSQL