---
appId: 4JDV
---
# 4JDV DeepWiki

## 1. Overview
4JDV is a synthetic application used for the PoC.

## 3. Business Capabilities
- Reporting: supports reporting flows
- Identity Management: supports identity management flows
- Customer Onboarding: supports customer onboarding flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- PostgreSQL
- Kafka
- Oracle

## 8. Dependencies
- Direct: 8RDA
- Direct: 9RAL
- Direct: 6DGU
- Indirect (transitive): 9GSP
- Indirect (transitive): 6TYX
