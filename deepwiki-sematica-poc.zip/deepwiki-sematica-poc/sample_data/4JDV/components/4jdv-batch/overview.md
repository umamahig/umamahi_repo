# 4jdv-batch
## Overview
Component 4jdv-batch of 4JDV.
## Technology Stack
- PostgreSQL
- Oracle