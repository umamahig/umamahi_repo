# 4jdv-ui
## Overview
Component 4jdv-ui of 4JDV.
## Technology Stack
- PostgreSQL
- Kafka