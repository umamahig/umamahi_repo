# 6qva-api
## Overview
Component 6qva-api of 6QVA.
## Technology Stack
- Oracle
- Kafka