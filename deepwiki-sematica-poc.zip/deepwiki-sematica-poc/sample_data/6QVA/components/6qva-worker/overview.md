# 6qva-worker
## Overview
Component 6qva-worker of 6QVA.
## Technology Stack
- Oracle
- Kafka