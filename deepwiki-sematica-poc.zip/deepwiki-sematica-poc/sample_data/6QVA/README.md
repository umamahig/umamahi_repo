---
appId: 6QVA
---
# 6QVA DeepWiki

## 1. Overview
6QVA is a synthetic application used for the PoC.

## 3. Business Capabilities
- Catalog Management: supports catalog management flows
- Customer Onboarding: supports customer onboarding flows
- Order Fulfilment: supports order fulfilment flows

## 4. Application Classification
- Application Type: Custom

## 7. Technology Stack
- Kafka
- Oracle

## 8. Dependencies
- Direct: 3MKC
- Direct: 4QKA
- Direct: 6XWP
- Indirect (transitive): 4QKA
- Indirect (transitive): 9RAL
