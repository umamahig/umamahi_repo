---
appId: 9ANX
---
# 9ANX DeepWiki

## 1. Overview
9ANX is a synthetic application used for the PoC.

## 3. Business Capabilities
- Fraud Detection: supports fraud detection flows
- Payment Processing: supports payment processing flows

## 4. Application Classification
- Application Type: SaaS

## 7. Technology Stack
- React
- Kafka
- Node.js 20
- Spring Boot 3.2

## 8. Dependencies
- Direct: 8NLN
- Direct: 9HQR
- Direct: 3UCJ
- Indirect (transitive): 4BKC
- Indirect (transitive): 2LBP
