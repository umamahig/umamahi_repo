# 9anx-gateway
## Overview
Component 9anx-gateway of 9ANX.
## Technology Stack
- Kafka
- Spring Boot 3.2