---
appId: 6DKH
---
# 6DKH DeepWiki

## 1. Overview
6DKH is a synthetic application used for the PoC.

## 3. Business Capabilities
- Order Fulfilment: supports order fulfilment flows
- Fraud Detection: supports fraud detection flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- PostgreSQL
- Kafka
- Angular
- Go
- Node.js 20

## 8. Dependencies
- Direct: 7PXF
- Direct: 4UQF
- Direct: 6DGU
- Indirect (transitive): 4BKC
- Indirect (transitive): 4UQF

## 11. Messaging & Events
### Produces
- `orders.created.v2` (event: order placed)
- `orders.failed.v1` (event: customer created)
### Consumes
- `customers.created.v1`
- `audit.settled.v1`
