# 6dkh-api
## Overview
Component 6dkh-api of 6DKH.
## Technology Stack
- PostgreSQL
- Go
## Messaging
- Produces to `orders.created.v2` (event: customer created)