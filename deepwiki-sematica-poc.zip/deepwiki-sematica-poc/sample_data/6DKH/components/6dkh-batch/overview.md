# 6dkh-batch
## Overview
Component 6dkh-batch of 6DKH.
## Technology Stack
- Go
- Node.js 20
## Messaging
- Produces to `orders.created.v2` (event: order placed)