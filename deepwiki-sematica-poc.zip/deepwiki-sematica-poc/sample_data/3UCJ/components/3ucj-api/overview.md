# 3ucj-api
## Overview
Component 3ucj-api of 3UCJ.
## Technology Stack
- Node.js 20
- Kafka