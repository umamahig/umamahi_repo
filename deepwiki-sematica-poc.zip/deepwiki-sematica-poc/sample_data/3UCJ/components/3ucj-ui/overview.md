# 3ucj-ui
## Overview
Component 3ucj-ui of 3UCJ.
## Technology Stack
- Kubernetes
- Kafka