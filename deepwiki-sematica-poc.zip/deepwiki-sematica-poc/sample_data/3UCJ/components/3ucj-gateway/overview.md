# 3ucj-gateway
## Overview
Component 3ucj-gateway of 3UCJ.
## Technology Stack
- Kafka
- Node.js 20