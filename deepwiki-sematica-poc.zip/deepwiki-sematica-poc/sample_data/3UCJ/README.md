---
appId: 3UCJ
---
# 3UCJ DeepWiki

## 1. Overview
3UCJ is a synthetic application used for the PoC.

## 3. Business Capabilities
- Payment Processing: supports payment processing flows
- Reporting: supports reporting flows
- Fraud Detection: supports fraud detection flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: PAA

## 7. Technology Stack
- Node.js 20
- Kafka
- Kubernetes

## 8. Dependencies
- Direct: 4PZA
- Direct: 9GVP
- Direct: 4JDJ
- Indirect (transitive): 9JML
- Indirect (transitive): 2KKZ
