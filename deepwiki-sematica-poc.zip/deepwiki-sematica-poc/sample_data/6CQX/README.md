---
appId: 6CQX
---
# 6CQX DeepWiki

## 1. Overview
6CQX is a synthetic application used for the PoC.

## 3. Business Capabilities
- Customer Onboarding: supports customer onboarding flows
- Catalog Management: supports catalog management flows

## 4. Application Classification
- Application Type: Legacy

## 7. Technology Stack
- Redis
- Docker
- Spring Boot 3.2

## 8. Dependencies
- Direct: 6TYX
- Direct: 6DKH
- Direct: 5ZVL
- Indirect (transitive): 2PNT
- Indirect (transitive): 3WZK
