"""Paths and global constants. All artefacts live under <project>/output/."""
import json, logging, os
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
OUTPUT = Path(os.environ.get("DEEPWIKI_OUTPUT", ROOT / "output"))
NOT_FOUND = "Information not found in DeepWiki source data"

def out(*parts) -> Path:
    p = OUTPUT.joinpath(*parts)
    p.parent.mkdir(parents=True, exist_ok=True)
    return p

def setup_logging(level=logging.INFO):
    log = logging.getLogger("deepwiki")
    if not log.handlers:
        log.setLevel(level)
        fmt = logging.Formatter("%(asctime)s %(levelname)s %(name)s: %(message)s")
        fh = logging.FileHandler(out("logs", "deepwiki.log")); fh.setFormatter(fmt)
        sh = logging.StreamHandler(); sh.setFormatter(fmt); sh.setLevel(logging.WARNING)
        log.addHandler(fh); log.addHandler(sh)
    return log

def load_sections():
    return json.loads((ROOT / "config" / "sections.json").read_text())["sections"]
