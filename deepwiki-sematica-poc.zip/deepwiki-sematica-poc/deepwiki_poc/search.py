"""Hybrid retrieval (sparse TF-IDF + dense vectors, RRF fusion) and intent-aware graph queries.

Answers are EXTRACTIVE: every line is built from a graph edge/attribute or a verbatim
snippet, always with a citation. No generative model is involved => no hallucination.
"""
from __future__ import annotations
import json, os, pickle, re, logging
import numpy as np
import networkx as nx
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.decomposition import TruncatedSVD
from sklearn.preprocessing import normalize
from . import graph as G_, viz
from .config import out, NOT_FOUND
from .models import Answer, Chunk, Prov

log = logging.getLogger("deepwiki.search")

# ------------------------------------------------------------------ index
class HybridIndex:
    def __init__(self, dims=128): self.dims = dims; self.chunks = []
    def _search_text(self, c): return f"{c.app_id} {c.component_id or ''} {c.section_title} {c.text}"

    def fit(self, chunks):
        self.chunks = chunks
        docs = [self._search_text(c) for c in chunks]
        self.tfidf = TfidfVectorizer(sublinear_tf=True, ngram_range=(1, 2), min_df=1, token_pattern=r"(?u)\b[\w+#.]{2,}\b", lowercase=True)
        self.X = self.tfidf.fit_transform(docs)
        self.st = None
        if os.environ.get("DEEPWIKI_EMBEDDER") == "st":       # real dense embeddings
            from sentence_transformers import SentenceTransformer
            self.st = SentenceTransformer("all-MiniLM-L6-v2")
            self.D = self.st.encode(docs, normalize_embeddings=True, batch_size=128).astype("float32")
        else:                                                   # dependency-light dense: LSA
            k = max(2, min(self.dims, self.X.shape[0] - 1, self.X.shape[1] - 1))
            self.svd = TruncatedSVD(k, random_state=0)
            self.D = normalize(self.svd.fit_transform(self.X)).astype("float32")
        self.apps = np.array([c.app_id for c in chunks]); self.comps = np.array([c.component_id or "" for c in chunks])

    def save(self):
        with open(out("index", "chunks.jsonl"), "w") as fh:
            for c in self.chunks: fh.write(json.dumps(c.to_dict()) + "\n")
        st = self.st; self.st = None
        with open(out("index", "hybrid.pkl"), "wb") as fh: pickle.dump({k: v for k, v in self.__dict__.items()}, fh)
        self.st = st

    @classmethod
    def load(cls):
        o = cls(); o.__dict__.update(pickle.load(open(out("index", "hybrid.pkl"), "rb")))
        if os.environ.get("DEEPWIKI_EMBEDDER") == "st" and o.st is None:
            from sentence_transformers import SentenceTransformer; o.st = SentenceTransformer("all-MiniLM-L6-v2")
        return o

    def search(self, q, app=None, comp=None, k=5, pool=50):
        mask = np.ones(len(self.chunks), bool)
        if app: mask &= self.apps == app
        if comp: mask &= self.comps == comp
        idx = np.flatnonzero(mask)
        if not len(idx): return []
        qs = self.tfidf.transform([q])
        sp = (self.X[idx] @ qs.T).toarray().ravel()
        qd = self.st.encode([q], normalize_embeddings=True) if self.st else normalize(self.svd.transform(qs))
        de = self.D[idx] @ qd.ravel()
        rr = {}
        for scores in (sp, de):
            for r, j in enumerate(np.argsort(-scores)[:pool]): rr[j] = rr.get(j, 0) + 1 / (60 + r)
        res = []
        for j in sorted(rr, key=rr.get, reverse=True):
            if sp[j] <= 0 and de[j] < 0.6: continue      # guardrail: needs lexical overlap or strong semantic match
            res.append((self.chunks[idx[j]], rr[j], float(sp[j]), float(de[j])))
            if len(res) == k: break
        return res

# ------------------------------------------------------------------ engine
MSG_WORDS = re.compile(r"kafka|topic|queue|produc|consum|publish|subscrib|pub/?sub|event|messag|lineage", re.I)

class Engine:
    def __init__(self):
        self.G = G_.load_graph(); self.idx = HybridIndex.load()
        self.apps = {d["name"].upper(): n for n, d in self.G.nodes(data=True) if d["type"] == "Application"}
        self.comps = {d["name"].upper(): n for n, d in self.G.nodes(data=True) if d["type"] == "Component"}
        self.tech = {d["name"].lower(): n for n, d in self.G.nodes(data=True) if d["type"] == "Technology"}
        self.tech_norm = {re.sub(r"[^a-z0-9+#.]", "", k): n for k, n in self.tech.items()}
        self.topics = {d["name"].lower(): n for n, d in self.G.nodes(data=True) if d["type"] == "Topic"}

    # ---------- helpers
    def _cite(self, d, n=1): return [p.cite() for p in G_.prov_of(d)[:n]]
    def _label(self, n): return self.G.nodes[n]["name"]
    def _user_nodes(self, n):
        """app node -> itself + its components"""
        return [n] + [v for _, v, d in self.G.out_edges(n, data=True) if d["relation"] == "CONTAINS_COMPONENT"]

    def _scope(self, q, app, comp):
        m = re.search(r"\b(?:appid|app)\s*:\s*([\w-]+)", q, re.I)
        if m: app = app or m.group(1); q = q.replace(m.group(0), " ")
        m = re.search(r"\b(?:comp|component|componentid)\s*:\s*([\w./-]+)", q, re.I)
        if m: comp = comp or m.group(1); q = q.replace(m.group(0), " ")
        if comp and app and "/" not in comp: comp = f"{app.upper()}/{comp}"
        return q.strip(), (app.upper() if app else None), (comp.upper() if comp else None)

    def _entities(self, q):
        """Applications/components literally named in the query."""
        found = []
        for tok in re.findall(r"[A-Za-z0-9][\w./-]*", q):
            u = tok.upper().strip(".")
            n = self.comps.get(u) or self.apps.get(u)
            if n and n not in found: found.append(n)
        return found

    def _tech_in(self, q):
        ql = q.lower(); hits = []
        for tok in re.findall(r"[a-z0-9+#.]+", ql):
            t = re.sub(r"[^a-z0-9+#.]", "", tok.strip("."))
            if t in self.tech_norm and self.tech_norm[t] not in hits and t not in ("is", "a", "an", "of", "to", "the"): hits.append(self.tech_norm[t])
        return hits

    # ---------- public API
    def ask(self, query, app=None, component=None, top_k=5, draw=True) -> Answer:
        q, app, comp = self._scope(query, app, component)
        ents = self._entities(q)
        if app and self.apps.get(app) and self.apps[app] not in ents: ents.insert(0, self.apps[app])
        if comp and self.comps.get(comp) and self.comps[comp] not in ents: ents.insert(0, self.comps[comp])
        if (app and app not in self.apps) or (comp and comp not in self.comps): return Answer("scope", False)
        ql = q.lower()
        tail = re.search(r"\b(?:of|for|about)\s+([A-Z0-9]{3,8})\s*\??$", q)   # "... of XYZ": unknown app id => nothing to answer
        if tail and tail.group(1) not in self.apps and tail.group(1) not in self.comps and not self._tech_in(tail.group(1)):
            return Answer("scope", False)
        m = re.match(r"^\s*is\s+(\S+)\s+(?:an?\s+)?(.+?)(?:\s+(?:app|application))?\s*\??\s*$", q, re.I)
        if m and ents: return self._attr_check(ents[0], m.group(2).strip(" ?."), app, comp)
        unknown = [t for t in re.findall(r"\b[0-9][A-Z0-9]{3}\b", q) if t not in self.apps and t not in self.comps]
        if unknown and re.search(r"between|relat|path|connect|depend|link", ql): return Answer("relationship", False)
        if len(ents) >= 2 and re.search(r"between|relat|path|connect|depend|link|how", ql): return self._relation(ents[0], ents[1], draw)
        if "capabilit" in ql and ents: return self._capabilities(ents[0])
        techs = self._tech_in(q)
        topic = next((n for t, n in self.topics.items() if t in ql), None)
        if MSG_WORDS.search(ql) or topic: return self._messaging(q, ents, topic, techs, draw)
        if techs and (len(q.split()) <= 3 or re.search(r"use|using|built|technolog|stack|which|what|list|impact", ql)):
            return self._tech_impact(techs[0], ents, draw)
        if re.search(r"depend", ql) and ents: return self._deps(ents[0], draw)
        return self._retrieve(q, app, comp, top_k)

    # ---------- intents
    def _attr_check(self, n, term, app, comp):
        a = Answer("attribute_check", False); d = self.G.nodes[n]
        vals = d["attrs"].get("app_type", [])
        for v in vals:
            a.found = True; eq = v["value"].strip().lower() == term.lower() or term.lower() in v["value"].lower()
            a.lines.append(f"{'Yes' if eq else 'No'} — DeepWiki lists {d['name']} type as '{v['value']}'.")
            a.citations.append(Prov(**v["prov"]).cite())
        if not vals:  # explicit mention only; never inferred
            hits = [r for r in self.idx.search(f"{d['name']} {term}", app=d["name"].split("/")[0], comp=None, k=20) if re.search(rf"\b{re.escape(term)}\b", r[0].text, re.I)]
            if hits:
                a.found = True; a.lines.append(f"DeepWiki has no explicit type attribute for {d['name']}, but '{term}' is mentioned (not a definitive classification):")
                for c, *_ in hits[:3]: a.lines.append(f"  “{_snip(c.text, term)}”"); a.citations.append(c.prov.cite())
        return a

    def _capabilities(self, n):
        a = Answer("business_capabilities", False)
        for _, v, d in self.G.out_edges(n, data=True):
            if d["relation"] == "HAS_CAPABILITY": a.lines.append(f"- {self._label(v)}"); a.citations += self._cite(d); a.found = True
        if a.found: a.lines.insert(0, f"Business capabilities of {self._label(n)}:")
        return a

    def _deps(self, n, draw):
        a = Answer("dependencies", False); H = nx.MultiDiGraph(); H.add_node(n, **self.G.nodes[n])
        for u in self._user_nodes(n):
            for _, v, d in self.G.out_edges(u, data=True):
                if d["relation"] == "DEPENDS_ON":
                    a.lines.append(f"- {self._label(u)} → {self._label(v)} ({d.get('dep_type') or 'direct'})"); a.citations += self._cite(d); a.found = True
                    H.add_node(v, **self.G.nodes[v]); H.add_node(u, **self.G.nodes[u]); H.add_edge(u, v, **{"relation": "DEPENDS_ON"})
        if a.found:
            a.lines.insert(0, f"Dependencies of {self._label(n)}:")
            if draw: a.graph_files.append(viz.draw(H, f"deps_{self._label(n)}", f"Dependencies of {self._label(n)}"))
        return a

    def _tech_impact(self, t, ents, draw):
        a = Answer("technology_impact", False); H = nx.MultiDiGraph(); H.add_node(t, **self.G.nodes[t])
        allowed = set(sum((self._user_nodes(e) for e in ents), [])) if ents else None
        apps, comps = {}, []
        for u, _, d in self.G.in_edges(t, data=True):
            if d["relation"] != "USES_TECH" or (allowed is not None and u not in allowed): continue
            H.add_node(u, **self.G.nodes[u]); H.add_edge(u, t, relation="USES_TECH")
            ver = f" v{d['version']}" if d.get("version") else ""
            (comps if self.G.nodes[u]["type"] == "Component" else apps.setdefault("a", [])).append(f"{self._label(u)}{ver}")
            a.citations += self._cite(d); a.found = True
        if a.found:
            a.lines = [f"Technology '{self._label(t)}' is used by {len(apps.get('a', []))} application(s) and {len(comps)} component(s) in scope.",
                       "Applications: " + _cap(apps.get("a", [])), "Components: " + _cap(comps)]
            a.citations = a.citations[:15]
            if draw: a.graph_files.append(viz.draw(H, f"tech_{self._label(t)}", f"Technology map: {self._label(t)}"))
        return a

    def _messaging(self, q, ents, topic, techs, draw):
        a = Answer("messaging_lineage", False); G = self.G
        topics = {topic} if topic else set()
        scope = set(sum((self._user_nodes(e) for e in ents), [])) if ents else None
        kafka_only = "kafka" in q.lower()
        for u, v, d in G.edges(data=True):
            if d["relation"] in ("PRODUCES_TO", "CONSUMES_FROM") and not topic and (scope is None or u in scope):
                if kafka_only:
                    ktech = self.tech_norm.get("kafka")
                    is_kafka = (G.nodes[v]["attrs"].get("broker") or "").lower() == "kafka" or bool(ktech and (G.has_edge(u, ktech) or G.has_edge(owner_node(G, u), ktech)))
                    if not is_kafka: continue
                topics.add(v)
        if scope is not None and not topic and not topics: return a
        H, layers, rows = nx.MultiDiGraph(), {}, []
        for v in topics:
            H.add_node(v, **G.nodes[v]); layers[v] = 1
            for u, _, d in G.in_edges(v, data=True):
                if d["relation"] == "PRODUCES_TO": H.add_node(u, **G.nodes[u]); H.add_edge(u, v, relation="PRODUCES_TO"); layers[u] = 0; rows.append(("P", u, v, d))
        for u, v, d in G.edges(data=True):
            if d["relation"] == "CONSUMES_FROM" and v in topics:
                H.add_node(u, **G.nodes[u]); H.add_edge(v, u, relation="CONSUMED_BY"); layers[u] = 2; rows.append(("C", u, v, d))
        if not rows: return a
        by = {}
        for r, u, v, d in rows: by.setdefault(v, {"P": [], "C": []})[r].append((u, d))
        a.found = True; a.lines.append(f"{len(by)} topic/queue(s) matched (showing up to 15):")
        for v, x in list(by.items())[:15]:
            ev = sorted({e for _, d in x["P"] + x["C"] for e in d.get("events", []) if e})
            a.lines.append(f"- {self._label(v)} [{G.nodes[v]['attrs'].get('broker') or G.nodes[v]['attrs'].get('kind') or 'topic'}]: producers={_cap([self._label(u) for u, _ in x['P']]) or 'none documented'}; consumers={_cap([self._label(u) for u, _ in x['C']]) or 'none documented'}" + (f"; event triggers: {_cap(ev, 3)}" if ev else ""))
            for u, d in (x["P"] + x["C"])[:2]: a.citations += self._cite(d)
        if draw: a.graph_files.append(viz.draw(H, "pubsub_" + (self._label(topic) if topic else (self._label(ents[0]) if ents else "global")), "Messaging lineage: Producer → Topic/Queue → Consumer", layers=layers))
        return a

    def _relation(self, x, y, draw):
        a = Answer("relationship", False); G = self.G
        H = nx.MultiDiGraph(); ux, uy = set(self._user_nodes(x)), set(self._user_nodes(y))
        def add(u, v, d, note):
            H.add_node(u, **G.nodes[u]); H.add_node(v, **G.nodes[v]); H.add_edge(u, v, relation=d["relation"])
            a.citations += self._cite(d); a.found = True
        for u, v, d in G.edges(data=True):  # explicit
            if d["relation"] == "DEPENDS_ON" and ((u in ux and v in uy) or (u in uy and v in ux)):
                a.lines.append(f"Explicit: {self._label(u)} DEPENDS_ON {self._label(v)} ({d.get('dep_type') or 'direct'})"); add(u, v, d, "")
        def linked(s):  # (target -> [(node, edge)]) for tech/topic hops
            r = {}
            for u in s:
                for _, t, d in G.out_edges(u, data=True):
                    if d["relation"] in ("USES_TECH", "PRODUCES_TO", "CONSUMES_FROM"): r.setdefault((t, d["relation"] == "USES_TECH"), []).append((u, d))
            return r
        lx, ly = linked(ux), linked(uy)
        for (t, is_tech) in set(lx) & set(ly):
            for (u, d1), (w, d2) in list(zip(lx[(t, is_tech)], ly[(t, is_tech)]))[:1]:
                what = "technology" if is_tech else "topic/queue"
                a.lines.append(f"Implicit (shared {what}): {self._label(x)} and {self._label(y)} both connect to {what} '{self._label(t)}'"); add(u, t, d1, ""); add(w, t, d2, "")
        # transitive dependency path (implicit)
        D = nx.DiGraph((u, v) for u, v, d in G.edges(data=True) if d["relation"] == "DEPENDS_ON")
        for s, t in ((x, y), (y, x)):
            for ss in ([s] if G.nodes[s]["type"] == "Application" else [G.nodes[s]["app"] and f"app:{G.nodes[s]['app']}" or s]):
                tt = t if G.nodes[t]["type"] == "Application" else f"app:{G.nodes[t].get('app')}"
                if ss in D and tt in D and nx.has_path(D, ss, tt):
                    p = nx.shortest_path(D, ss, tt)
                    if len(p) > 2 or not a.lines:
                        a.lines.append("Dependency chain (directed, from listed dependencies): " + " → ".join(self._label(n) for n in p))
                        for u, v in zip(p, p[1:]): d = next(iter(G.get_edge_data(u, v).values())); add(u, v, d, "")
        if a.found:
            a.lines.insert(0, f"Relationships between {self._label(x)} and {self._label(y)}:")
            if draw: a.graph_files.append(viz.draw(H, f"relation_{self._label(x)}__{self._label(y)}", f"{self._label(x)} ↔ {self._label(y)}"))
        return a

    def _retrieve(self, q, app, comp, k):
        a = Answer("hybrid_search", False)
        for c, rrf, sp, de in self.idx.search(q, app, comp, k):
            a.found = True; loc = c.app_id + (f"/{c.component_id}" if c.component_id else "")
            a.lines.append(f"- [{loc} · {c.section_title}] (sparse={sp:.2f}, dense={de:.2f})  “{_snip(c.text, q.split()[0] if q.split() else '')}”"); a.citations.append(c.prov.cite())
        return a

def owner_node(G, n): return f"app:{G.nodes[n]['app']}" if G.nodes[n].get("type") == "Component" else n
def _cap(xs, n=12): xs = list(dict.fromkeys(xs)); return ", ".join(xs[:n]) + (f" … (+{len(xs) - n} more)" if len(xs) > n else "")
def _snip(text, term, w=260):
    t = " ".join(text.split()); i = max(0, t.lower().find(term.lower())) if term else 0
    s = t[max(0, i - 60): i + w]; return ("…" if i > 60 else "") + s + ("…" if len(t) > i + w else "")
