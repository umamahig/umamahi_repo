"""End-to-end build: ingest -> facts -> graph -> index -> reports."""
import json, time, logging, collections
from . import extract, graph as G_, parser, semantica_adapter
from .config import out, setup_logging
from .search import HybridIndex

log = logging.getLogger("deepwiki.pipeline")

def build(data_dir, mirror_semantica=True, progress=None):
    setup_logging(); t0 = time.time()
    bundles = parser.ingest(data_dir, progress=progress)
    known = {b.app_id for b in bundles}
    facts, chunks = [], []
    for b in bundles:
        f, c = extract.extract_app(b, known); facts += f; chunks += c
    G = G_.build_graph(facts); G_.save_graph(G, facts)
    idx = HybridIndex(); idx.fit(chunks); idx.save()
    cov = {b.app_id: {"missing_sections": b.missing_sections, "errors": b.errors, "has_manifest": b.manifest is not None} for b in bundles}
    out("reports", "ingestion_report.json").write_text(json.dumps(cov, indent=1))
    mirrored = semantica_adapter.record_provenance(facts, limit=5000) if mirror_semantica else 0
    stats = {"apps": len(bundles), "facts": len(facts), "chunks": len(chunks), "nodes": G.number_of_nodes(),
             "edges": G.number_of_edges(), "relations": dict(collections.Counter(d["relation"] for *_, d in G.edges(data=True))),
             "apps_missing_manifest": sum(not b.manifest for b in bundles),
             "apps_with_errors": sum(bool(b.errors) for b in bundles),
             "semantica_version": semantica_adapter.available(), "semantica_provenance_records": mirrored,
             "seconds": round(time.time() - t0, 1)}
    out("reports", "build_stats.json").write_text(json.dumps(stats, indent=1))
    return stats
