"""Turn parsed bundles into provenance-tagged Facts + retrieval Chunks."""
from __future__ import annotations
import re
from .models import Fact, Prov, Chunk

BULLET = re.compile(r"^\s*(?:[-*+]|\d+[.)])\s+(.*\S)\s*$")
APPID = re.compile(r"\b[0-9][A-Z0-9]{2,7}\b")
BROKERS = {"kafka": "Kafka", "rabbitmq": "RabbitMQ", "activemq": "ActiveMQ", "ibm mq": "IBM MQ", "solace": "Solace"}
TECH_COLS = ("technology", "tech", "framework", "tool", "library", "name")

def clean(s: str) -> str:
    s = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", s)
    return re.sub(r"[*`_]{1,3}", "", s).strip()

def iter_items(sec):
    """Yield (lineno, payload, kind, subheading). kind = bullet|row."""
    header, sub = None, ""
    for ln, t in sec.lines:
        s = t.strip()
        if not s: header = None; continue
        if s.startswith("#"): sub = s.lstrip("# ").lower(); continue
        if s.startswith("|"):
            cells = [c.strip() for c in s.strip("|").split("|")]
            if all(re.fullmatch(r":?-{2,}:?", c) for c in cells if c): continue
            if header is None: header = [c.lower() for c in cells]; continue
            yield ln, dict(zip(header, cells)), "row", sub
        else:
            m = BULLET.match(t)
            if m: yield ln, m.group(1), "bullet", sub

def split_tech(s: str):
    s = clean(s)
    if ":" in s and len(s.split(":", 1)[0]) <= 30: s = s.split(":", 1)[1]
    for p in re.split(r"[,;]", s):
        p = p.strip(" .")
        m = re.match(r"^(.*?)(?:\s+v?(\d[\w.\-]*))?$", p)
        name, ver = (m.group(1).strip(), m.group(2)) if m else (p, None)
        if name and len(name) <= 40 and len(name.split()) <= 4: yield name, ver

def as_list(v):
    if v is None: return []
    v = v if isinstance(v, list) else [v]
    out = []
    for x in v:
        if isinstance(x, str): out.append((x, {}))
        elif isinstance(x, dict):
            n = next((x[k] for k in ("id", "appId", "name", "topic", "queue", "technology", "tech") if isinstance(x.get(k), str)), None)
            if n: out.append((n, x))
    return out

def _broker(text: str):
    t = text.lower()
    return next((v for k, v in BROKERS.items() if k in t), None)

def parse_message_item(payload, kind, sub):
    """-> (role, [topic], event, kind_of_channel, component) ; role in PRODUCES_TO/CONSUMES_FROM/None"""
    if kind == "row":
        blob = " ".join(payload.values()).lower()
        rolev = next((payload[k] for k in payload if k in ("role", "direction", "type")), "") + " " + sub
        topicv = next((payload[k] for k in payload if k in ("topic", "queue", "topic/queue", "destination", "name", "channel")), "")
        ev = next((payload[k] for k in payload if k in ("event", "trigger", "description", "event/trigger")), "")
        comp = next((payload[k] for k in payload if k in ("component", "service", "module")), None)
        topics = [t.strip() for t in re.split(r"[,;]", clean(topicv)) if t.strip()]
        text = rolev.lower() + " " + blob
    else:
        text = payload.lower() + " " + sub
        topics = re.findall(r"`([^`]+)`", payload)
        if not topics and ":" in payload:
            topics = [t.strip(" .") for t in re.split(r"[,;]", clean(payload.split(":", 1)[1]))]
        m = re.search(r"(?:event|trigger(?:ed)?(?: by| on)?)\s*[:=\-]?\s*([^;()`]+)", payload, re.I) or re.search(r"\(([^)]+)\)", payload)
        ev, comp = (m.group(1).strip() if m else ""), None
    topics = [t for t in topics if re.fullmatch(r"[A-Za-z0-9_.\-/]{2,120}", t)]
    role = "PRODUCES_TO" if re.search(r"produc|publish", text) else "CONSUMES_FROM" if re.search(r"consum|subscrib", text) else None
    return role, topics, ev, ("queue" if "queue" in text else "topic"), comp, _broker(text)

def extract_app(b, known_ids: set):
    facts, chunks = [], []
    A = b.app_id
    def F(s, st, p, o, ot, prov, **attrs): facts.append(Fact(s, st, p, o, ot, prov, attrs))
    def subj(cid): return (f"{A}/{cid}", "Component") if cid else (A, "Application")

    # ---- manifest ----
    m, mp = b.manifest, b.manifest_path
    if m:
        P = lambda path: Prov(mp, "manifest", path)
        if m.get("name"): F(A, "Application", "HAS_ATTRIBUTE", str(m["name"]), "Literal", P("$.name"), name="name")
        for k in ("type", "appType", "applicationType", "classification"):
            if isinstance(m.get(k), str): F(A, "Application", "HAS_ATTRIBUTE", m[k], "Literal", P(f"$.{k}"), name="app_type")
        env = m.get("environments") or m.get("environment")
        if env: F(A, "Application", "HAS_ATTRIBUTE", ", ".join(env.keys() if isinstance(env, dict) else [n for n, _ in as_list(env)]), "Literal", P("$.environments"), name="environments")
        for k in ("technologies", "techStack", "tech"):
            for i, (n, d) in enumerate(as_list(m.get(k))): F(A, "Application", "USES_TECH", n, "Technology", P(f"$.{k}[{i}]"), version=d.get("version"))
        deps = m.get("dependencies")
        for kind in ("direct", "indirect"):
            src = deps.get(kind) if isinstance(deps, dict) else (deps if kind == "direct" else m.get("indirectDependencies"))
            for i, (n, d) in enumerate(as_list(src)): F(A, "Application", "DEPENDS_ON", n, "Application", P(f"$.dependencies.{kind}[{i}]"), dep_type=kind)
        for i, (n, d) in enumerate(as_list(m.get("components"))):
            F(A, "Application", "CONTAINS_COMPONENT", f"{A}/{n}", "Component", P(f"$.components[{i}]"))
        ms = m.get("messaging") or {}
        for role, key in (("PRODUCES_TO", "produces"), ("CONSUMES_FROM", "consumes")):
            for i, (n, d) in enumerate(as_list(ms.get(key))):
                F(A, "Application", role, n, "Topic", P(f"$.messaging.{key}[{i}]"), event=d.get("event", ""), kind=d.get("type", "topic"), broker=d.get("broker"))
        chunks.append(Chunk(f"{A}|manifest|0", A, None, "manifest", "Manifest", _flat(m), Prov(mp, "manifest", "$")))

    # ---- markdown ----
    docs = [(rp, s, None) for rp, _, ss in b.app_docs for s in ss]
    for cid, cd in b.components.items():
        F(A, "Application", "CONTAINS_COMPONENT", f"{A}/{cid}", "Component", Prov(cd.files[0][0], "markdown", "folder structure"))
        docs += [(rp, s, cid) for rp, _, ss in cd.files for s in ss]
    for rp, sec, cid in docs:
        if not sec.text: continue
        s0, s1 = sec.span
        sp, st = subj(cid)
        for n, part in enumerate(_split(sec.text)):
            chunks.append(Chunk(f"{A}|{cid or ''}|{sec.key}|{rp}|{s0}|{n}", A, cid, sec.key, sec.title, part, Prov(rp, "markdown", sec.title, s0, s1)))
        for ln, pay, kind, sub in iter_items(sec):
            pv = Prov(rp, "markdown", sec.title, ln, ln)
            raw = " ".join(pay.values()) if kind == "row" else pay
            if sec.key == "technology_stack":
                if kind == "row":
                    col = next((c for c in TECH_COLS if c in pay), None)
                    cells = [col and pay[col]] if col else [list(pay.values())[min(1, len(pay) - 1)]]
                    ver = pay.get("version")
                    for n_, v_ in split_tech(cells[0]): F(sp, st, "USES_TECH", n_, "Technology", pv, version=v_ or ver)
                else:
                    for n_, v_ in split_tech(pay): F(sp, st, "USES_TECH", n_, "Technology", pv, version=v_)
            elif sec.key == "business_capabilities" and cid is None:
                c = clean(raw.split(":")[0] if kind == "bullet" and ":" in raw and len(raw.split(":")[0]) < 60 else raw)
                if 2 < len(c) <= 90: F(A, "Application", "HAS_CAPABILITY", c, "BusinessCapability", pv)
            elif sec.key in ("dependencies", "upstream", "downstream"):
                ind = "indirect" if re.search(r"indirect|transitive", raw + sub, re.I) else "direct"
                for t in set(APPID.findall(raw)):
                    if t in known_ids and t != A:
                        F(sp, st, "DEPENDS_ON", t, "Application", pv, dep_type=ind, direction=sec.key)
            elif sec.key == "messaging":
                role, topics, ev, ch, comp, brk = parse_message_item(pay, kind, sub)
                s2, st2 = subj(comp or cid) if (comp or cid) else (A, "Application")
                for t in topics:
                    if role: F(s2, st2, role, t, "Topic", pv, event=ev, kind=ch, broker=brk)
            elif sec.key == "classification":
                mm = re.search(r"(?:application|app)?\s*(?:type|classification)\s*[:\-]\s*(.+)", clean(raw), re.I)
                if mm: F(A, "Application", "HAS_ATTRIBUTE", mm.group(1).strip(" ."), "Literal", pv, name="app_type")
    return facts, chunks

def _split(text, size=1200):
    paras, cur, out = re.split(r"\n\s*\n", text), "", []
    for p in paras:
        if len(cur) + len(p) > size and cur: out.append(cur.strip()); cur = ""
        cur += p + "\n\n"
    if cur.strip(): out.append(cur.strip())
    return out

def _flat(d, pre=""):
    if isinstance(d, dict): return "\n".join(_flat(v, f"{pre}{k}.") for k, v in d.items())
    if isinstance(d, list): return "\n".join(_flat(v, pre) for v in d)
    return f"{pre.rstrip('.')}: {d}"
