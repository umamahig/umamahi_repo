from __future__ import annotations
from dataclasses import dataclass, field, asdict
from typing import Optional

@dataclass
class Prov:
    """Where a fact came from (file/section/line or manifest JSON path)."""
    source_file: str
    kind: str = "markdown"            # markdown | manifest
    section: Optional[str] = None     # section header, or JSON path for manifests
    line_start: Optional[int] = None
    line_end: Optional[int] = None

    def cite(self) -> str:
        loc = ""
        if self.line_start:
            loc = f" L{self.line_start}" + (f"-{self.line_end}" if self.line_end and self.line_end != self.line_start else "")
        sec = f" § {self.section}" if self.section else ""
        return f"{self.source_file}{sec}{loc}"

@dataclass
class Fact:
    subject: str; subject_type: str
    predicate: str
    object: str; object_type: str
    prov: Prov
    attrs: dict = field(default_factory=dict)
    def to_dict(self): return asdict(self)

@dataclass
class Chunk:
    id: str; app_id: str; component_id: Optional[str]
    section_key: str; section_title: str; text: str; prov: Prov
    def to_dict(self): return asdict(self)

@dataclass
class Section:
    key: str; title: str; lines: list  # [(lineno, text)]
    @property
    def text(self): return "\n".join(t for _, t in self.lines).strip()
    @property
    def span(self): return (self.lines[0][0], self.lines[-1][0]) if self.lines else (None, None)

@dataclass
class Answer:
    intent: str
    found: bool
    lines: list = field(default_factory=list)      # answer statements
    citations: list = field(default_factory=list)  # "file § section Lx-y"
    graph_files: list = field(default_factory=list)
    def render(self) -> str:
        from .config import NOT_FOUND
        if not self.found or not self.citations:
            return NOT_FOUND
        o = [f"[intent: {self.intent}]", *self.lines, "", "Sources:"]
        o += [f"  - {c}" for c in dict.fromkeys(self.citations)]
        if self.graph_files:
            o += ["", "Graph files:"] + [f"  - {g}" for g in self.graph_files]
        return "\n".join(o)
