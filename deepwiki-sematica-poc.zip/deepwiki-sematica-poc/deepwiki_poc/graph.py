"""Knowledge-graph construction (networkx MultiDiGraph) + RDF/JSON export + provenance."""
from __future__ import annotations
import json, re, logging
import networkx as nx
from rdflib import Namespace, RDF, Literal, URIRef
from urllib.parse import quote
from . import ontology
from .config import out
from .models import Prov

log = logging.getLogger("deepwiki.graph")

def nid(kind, name):
    if kind == "Application": return f"app:{name}"
    if kind == "Component": return f"comp:{name}"
    if kind == "Technology": return "tech:" + re.sub(r"[^a-z0-9+#.]+", "", name.lower())
    if kind == "Topic": return f"topic:{name}"
    if kind == "BusinessCapability": return "cap:" + " ".join(name.lower().split())
    return f"lit:{name}"

def build_graph(facts):
    G, seen, rejected = nx.MultiDiGraph(), {}, 0
    def node(kind, name):
        i = nid(kind, name)
        if i not in G: G.add_node(i, type=kind, name=name, attrs={}, prov=[])
        return i
    for f in facts:
        if not ontology.valid(f.predicate, f.subject_type, f.object_type): rejected += 1; continue
        s = node(f.subject_type, f.subject)
        if f.subject_type == "Component": G.nodes[s]["app"] = f.subject.split("/")[0]
        if f.predicate == "HAS_ATTRIBUTE":
            G.nodes[s]["attrs"].setdefault(f.attrs.get("name", "attr"), []).append({"value": f.object, "prov": f.prov.__dict__})
            continue
        o = node(f.object_type, f.object)
        if f.object_type == "Topic":
            for k in ("kind", "broker"):
                if f.attrs.get(k): G.nodes[o]["attrs"].setdefault(k, f.attrs[k])
        key = (s, f.predicate, o, f.attrs.get("dep_type"))
        if key in seen:
            G.edges[seen[key]]["prov"].append(f.prov.__dict__)
            if f.attrs.get("event"): G.edges[seen[key]].setdefault("events", []).append(f.attrs["event"])
        else:
            k = G.add_edge(s, o, relation=f.predicate, dep_type=f.attrs.get("dep_type"),
                           events=[f.attrs["event"]] if f.attrs.get("event") else [],
                           version=f.attrs.get("version"), prov=[f.prov.__dict__])
            seen[key] = (s, o, k)
    # Ensure component nodes carry the app link even when declared only via manifest
    log.info("graph: %d nodes, %d edges, %d facts rejected by ontology", G.number_of_nodes(), G.number_of_edges(), rejected)
    return G

def save_graph(G, facts):
    data = nx.node_link_data(G, edges="edges")
    out("graph", "kg.json").write_text(json.dumps(data, default=str))
    with open(out("provenance", "facts.jsonl"), "w") as fh:
        for f in facts: fh.write(json.dumps(f.to_dict(), default=str) + "\n")
    ontology.to_rdf().serialize(out("graph", "ontology.ttl"), format="turtle")
    g = ontology.to_rdf(); DW = ontology.DW; E = Namespace("https://deepwiki.example/e/")
    for n, d in G.nodes(data=True):
        u = E[quote(n)]; g.add((u, RDF.type, DW[d["type"]])); g.add((u, DW.name, Literal(d["name"])))
    for s, o, d in G.edges(data=True): g.add((E[quote(s)], DW[d["relation"]], E[quote(o)]))
    g.serialize(out("graph", "kg.ttl"), format="turtle")

def load_graph():
    return nx.node_link_graph(json.loads(out("graph", "kg.json").read_text()), edges="edges", multigraph=True, directed=True)

# ---- views ----
def edges_of(G, rel):
    return [(u, v, d) for u, v, d in G.edges(data=True) if d["relation"] == rel]

def prov_of(d): return [Prov(**p) for p in d.get("prov", [])]

def owner_app(G, n): return G.nodes[n].get("app") or (G.nodes[n]["name"] if G.nodes[n]["type"] == "Application" else None)
