"""CLI:  python -m deepwiki_poc.cli {generate|ingest|search|stats}"""
import argparse, json, sys
from .config import out, NOT_FOUND, setup_logging

def main(argv=None):
    ap = argparse.ArgumentParser(prog="deepwiki")
    sub = ap.add_subparsers(dest="cmd", required=True)
    g = sub.add_parser("generate", help="create synthetic sample data"); g.add_argument("--apps", type=int, default=50); g.add_argument("--dest", default="sample_data")
    i = sub.add_parser("ingest", help="parse, build graph + index"); i.add_argument("data_dir"); i.add_argument("--no-semantica-prov", action="store_true")
    s = sub.add_parser("search", help="ask a question"); s.add_argument("query"); s.add_argument("--app"); s.add_argument("--component"); s.add_argument("--top-k", type=int, default=5); s.add_argument("--no-graph", action="store_true"); s.add_argument("--json", action="store_true")
    sub.add_parser("stats")
    a = ap.parse_args(argv); setup_logging()
    if a.cmd == "generate":
        import importlib.util, pathlib
        sp = importlib.util.spec_from_file_location("gen", pathlib.Path(__file__).resolve().parent.parent / "scripts" / "generate_sample_data.py")
        m = importlib.util.module_from_spec(sp); sp.loader.exec_module(m); m.main(a.apps, a.dest)
    elif a.cmd == "ingest":
        from .pipeline import build
        st = build(a.data_dir, mirror_semantica=not a.no_semantica_prov, progress=lambda d, t: print(f"\r  parsed {d}/{t}", end="", file=sys.stderr))
        print(); print(json.dumps(st, indent=2))
    elif a.cmd == "search":
        from .search import Engine
        try: eng = Engine()
        except FileNotFoundError: print("No index found. Run: python -m deepwiki_poc.cli ingest <data_dir>"); return 1
        ans = eng.ask(a.query, app=a.app, component=a.component, top_k=a.top_k, draw=not a.no_graph)
        print(json.dumps({"intent": ans.intent, "found": ans.found and bool(ans.citations), "answer": ans.lines, "citations": list(dict.fromkeys(ans.citations)), "graph_files": ans.graph_files}, indent=2) if a.json else ans.render())
    elif a.cmd == "stats":
        print(out("reports", "build_stats.json").read_text())
    return 0

if __name__ == "__main__": sys.exit(main())
