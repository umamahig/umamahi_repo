"""Graph rendering (matplotlib, headless) into output/graphs/."""
import re, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt, networkx as nx
from .config import out, OUTPUT

COLORS = {"Application": "#4C78A8", "Component": "#9ECAE9", "Technology": "#F58518",
          "Topic": "#54A24B", "BusinessCapability": "#B279A2"}

def _label(d): return d["name"] if d["type"] != "Component" else d["name"].split("/", 1)[-1]

def draw(H: nx.MultiDiGraph, name: str, title: str, layers: dict | None = None, max_nodes=80) -> str:
    """H: subgraph with node attrs (type,name). layers: {node: column} for pub/sub layout."""
    if H.number_of_nodes() > max_nodes:
        keep = sorted(H.nodes, key=lambda n: -H.degree(n))[:max_nodes]; H = H.subgraph(keep)
        title += f"  (top {max_nodes} nodes by degree)"
    fn = re.sub(r"[^A-Za-z0-9_.-]+", "_", name) + ".png"
    path = out("graphs", fn)
    fig, ax = plt.subplots(figsize=(14, 9) if H.number_of_nodes() > 12 else (10, 6.5))
    if layers:
        cols = {}
        for n, c in layers.items():
            if n in H: cols.setdefault(c, []).append(n)
        pos = {n: (c, -i + len(v) / 2) for c, v in cols.items() for i, n in enumerate(sorted(v))}
    else:
        pos = nx.spring_layout(nx.Graph(H), seed=7, k=1.2 / max(1, H.number_of_nodes()) ** 0.5)
    nodes = list(H.nodes)
    nx.draw_networkx_nodes(H, pos, nodelist=nodes, node_color=[COLORS.get(H.nodes[n]["type"], "#999") for n in nodes], node_size=900, ax=ax, edgecolors="white")
    nx.draw_networkx_labels(H, pos, {n: _label(H.nodes[n]) for n in nodes}, font_size=7, ax=ax)
    nx.draw_networkx_edges(H, pos, ax=ax, arrows=True, arrowsize=14, edge_color="#666", node_size=900, connectionstyle="arc3,rad=0.08")
    el = {(u, v): d["relation"] for u, v, d in H.edges(data=True)}
    nx.draw_networkx_edge_labels(H, pos, el, font_size=6, ax=ax, rotate=False)
    ax.legend(handles=[plt.Line2D([], [], marker="o", ls="", color=c, label=t) for t, c in COLORS.items()], loc="upper right", fontsize=7)
    ax.set_title(title, fontsize=11); ax.axis("off"); fig.tight_layout(); fig.savefig(path, dpi=130); plt.close(fig)
    return str(path.relative_to(OUTPUT.parent)) if OUTPUT.parent in path.parents else str(path)
