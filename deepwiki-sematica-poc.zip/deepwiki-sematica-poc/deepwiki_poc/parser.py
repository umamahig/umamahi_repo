"""Markdown + manifest ingestion (async, batched) with graceful handling of gaps.

Semantica is tried first for JSON (semantica.parse.JSONParser); on any failure we
fall back to the stdlib parser. Markdown uses a line-number-preserving custom
parser so every fact can be cited to file/section/line.
"""
from __future__ import annotations
import asyncio, json, logging, os, re
from dataclasses import dataclass, field
from pathlib import Path
from .config import load_sections
from .models import Section

log = logging.getLogger("deepwiki.parser")
HEADING = re.compile(r"^(#{1,4})\s+(.*?)\s*#*\s*$")
_SECS = None

def _sections():
    global _SECS
    if _SECS is None:
        _SECS = load_sections()
    return _SECS

def _norm(s: str) -> str:
    s = re.sub(r"^\s*\d+[.)]?\s*", "", s.lower())
    return re.sub(r"[^a-z0-9/& -]", "", s).strip()

def match_section(title: str):
    t = _norm(title)
    best = None
    for s in _sections():
        if t == _norm(s["title"]) : return s
        if any(a in t for a in s["aliases"]) and best is None: best = s
    return best

def parse_markdown_text(text: str):
    """Return (frontmatter dict, [Section]). Unknown headings stay inside the current
    section; text before any known heading goes to 'preamble'."""
    lines = text.splitlines()
    meta, start = {}, 0
    if lines and lines[0].strip() == "---":
        for i in range(1, len(lines)):
            if lines[i].strip() == "---":
                for l in lines[1:i]:
                    if ":" in l:
                        k, v = l.split(":", 1); meta[k.strip()] = v.strip()
                start = i + 1; break
    secs, cur = [], Section("preamble", "Preamble", [])
    for no in range(start, len(lines)):
        l = lines[no]; m = HEADING.match(l)
        if m:
            s = match_section(m.group(2))
            if s and len(m.group(1)) <= 3:
                if cur.lines: secs.append(cur)
                cur = Section(s["key"], s["title"], []); continue
        if l.strip() or cur.lines:
            cur.lines.append((no + 1, l))
    if cur.lines: secs.append(cur)
    return meta, secs

def read_json(path: Path):
    try:  # Semantica first
        from semantica.parse import JSONParser
        r = JSONParser().parse(str(path))
        d = getattr(r, "data", r)
        if isinstance(d, dict) and d: return d
    except Exception:
        pass
    return json.loads(path.read_text(encoding="utf-8"))

@dataclass
class ComponentDoc:
    comp_id: str
    files: list = field(default_factory=list)   # [(rel_path, meta, [Section])]

@dataclass
class AppBundle:
    app_id: str
    root: str
    manifest: dict | None = None
    manifest_path: str | None = None
    app_docs: list = field(default_factory=list)
    components: dict = field(default_factory=dict)
    missing_sections: list = field(default_factory=list)
    errors: list = field(default_factory=list)

APP_ID_KEYS = ("appId", "applicationId", "app_id", "id", "ID")

def manifest_id(d):
    if isinstance(d, dict):
        for k in APP_ID_KEYS:
            if isinstance(d.get(k), str): return d[k]
    return None

def discover_apps(data_dir: Path):
    """Return {app_id: app_dir}. An app dir holds a manifest JSON with an id; top-level
    dirs that only contain markdown are accepted with the folder name as id."""
    apps = {}
    for dp, dns, fns in os.walk(data_dir):
        for fn in fns:
            if fn.lower().endswith(".json"):
                try: aid = manifest_id(read_json(Path(dp) / fn))
                except Exception as e: log.warning("bad manifest %s: %s", fn, e); continue
                if aid: apps[aid] = Path(dp); dns[:] = []; break
    covered = [p for p in apps.values()]
    for d in Path(data_dir).iterdir():
        if d.is_dir() and not any(c == d or d in c.parents or c in d.parents for c in covered):
            if any(d.rglob("*.md")): apps[d.name] = d
    return apps

def component_of(rel: Path):
    parts = rel.parts[:-1]
    if parts and parts[0].lower() in ("components", "component"): parts = parts[1:]
    return parts[0] if parts else None

def parse_app(app_id: str, app_dir: Path, data_dir: Path) -> AppBundle:
    b = AppBundle(app_id, str(app_dir.relative_to(data_dir)) if app_dir != data_dir else ".")
    for p in sorted(app_dir.rglob("*.json")):
        try:
            d = read_json(p)
            if manifest_id(d) == app_id:
                b.manifest, b.manifest_path = d, str(p.relative_to(data_dir)); break
        except Exception as e: b.errors.append(f"{p}: {e}")
    seen = set()
    for p in sorted(app_dir.rglob("*.md")):
        rel = p.relative_to(app_dir); rp = str(p.relative_to(data_dir))
        try:
            meta, secs = parse_markdown_text(p.read_text(encoding="utf-8", errors="replace"))
        except Exception as e:
            b.errors.append(f"{rp}: {e}"); continue
        cid = component_of(rel)
        if cid is None:
            b.app_docs.append((rp, meta, secs)); seen |= {s.key for s in secs}
        else:
            b.components.setdefault(cid, ComponentDoc(cid)).files.append((rp, meta, secs))
    b.missing_sections = [s["key"] for s in _sections() if s["key"] not in seen]
    return b

async def ingest_async(data_dir, concurrency=32, batch_size=200, progress=None):
    """Read all app bundles concurrently in bounded batches (threads do the file I/O)."""
    data_dir = Path(data_dir)
    apps = await asyncio.to_thread(discover_apps, data_dir)
    log.info("discovered %d applications", len(apps))
    sem, out, items = asyncio.Semaphore(concurrency), [], sorted(apps.items())
    async def one(aid, d):
        async with sem:
            try: return await asyncio.to_thread(parse_app, aid, d, data_dir)
            except Exception as e:
                log.exception("failed %s", aid); b = AppBundle(aid, str(d)); b.errors.append(str(e)); return b
    for i in range(0, len(items), batch_size):
        out += await asyncio.gather(*(one(a, d) for a, d in items[i:i + batch_size]))
        if progress: progress(len(out), len(items))
    return out

def ingest(data_dir, **kw):
    return asyncio.run(ingest_async(data_dir, **kw))
