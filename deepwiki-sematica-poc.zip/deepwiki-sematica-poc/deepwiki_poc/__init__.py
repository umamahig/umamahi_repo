"""DeepWiki + Semantica knowledge-graph PoC."""
__version__ = "0.1.0"
