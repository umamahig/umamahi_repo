"""Optional Semantica integrations. Every call is guarded: if Semantica is missing or an
API differs from what was verified (semantica 0.7.0), the core pipeline keeps working."""
import logging
from .config import out
log = logging.getLogger("deepwiki.semantica")

def available():
    try: import semantica; return getattr(semantica, "__version__", "unknown")
    except Exception: return None

def record_provenance(facts, limit=None):
    """Mirror fact provenance into Semantica's ProvenanceManager (SQLite) for audit/lineage."""
    try:
        from semantica.provenance import ProvenanceManager
        pm = ProvenanceManager(storage_path=str(out("provenance", "semantica_prov.db")))
    except Exception as e:
        log.warning("Semantica provenance unavailable: %s", e); return 0
    n = 0
    for f in (facts[:limit] if limit else facts):
        rid = f"{f.subject}|{f.predicate}|{f.object}"
        try:
            pm.track_relationship(rid, f.prov.cite(), {"kind": f.prov.kind, "section": f.prov.section,
                                  "line_start": f.prov.line_start, "line_end": f.prov.line_end})
            n += 1
        except Exception as e:
            log.warning("track_relationship failed (%s); stopping mirror", e); break
    return n
