"""Explicit ontology + RDF/Turtle export (rdflib)."""
from rdflib import Graph, Namespace, RDF, RDFS, OWL, Literal

DW = Namespace("https://deepwiki.example/ontology#")
CLASSES = ["Application", "Component", "Technology", "Topic", "BusinessCapability"]
# predicate -> (allowed subject types, allowed object types, description)
RELATIONS = {
    "DEPENDS_ON": ({"Application", "Component"}, {"Application", "Component"}, "Subject depends on object (dep_type: direct|indirect)"),
    "USES_TECH": ({"Application", "Component"}, {"Technology"}, "Subject is built with / uses technology"),
    "PRODUCES_TO": ({"Application", "Component"}, {"Topic"}, "Subject publishes events/messages to topic or queue"),
    "CONSUMES_FROM": ({"Application", "Component"}, {"Topic"}, "Subject consumes from topic or queue"),
    "CONTAINS_COMPONENT": ({"Application"}, {"Component"}, "Application is composed of component"),
    "HAS_CAPABILITY": ({"Application"}, {"BusinessCapability"}, "Application delivers business capability (extension)"),
    "HAS_ATTRIBUTE": ({"Application", "Component"}, {"Literal"}, "Scalar attribute such as app_type, name, environments (extension)"),
}

def valid(pred, st, ot):
    r = RELATIONS.get(pred)
    return bool(r and st in r[0] and ot in r[1])

def to_rdf() -> Graph:
    g = Graph(); g.bind("dw", DW)
    for c in CLASSES: g.add((DW[c], RDF.type, OWL.Class))
    for p, (dom, rng, desc) in RELATIONS.items():
        g.add((DW[p], RDF.type, OWL.ObjectProperty)); g.add((DW[p], RDFS.comment, Literal(desc)))
        for d in dom: g.add((DW[p], RDFS.domain, DW[d]))
        for r in rng:
            if r != "Literal": g.add((DW[p], RDFS.range, DW[r]))
    return g
