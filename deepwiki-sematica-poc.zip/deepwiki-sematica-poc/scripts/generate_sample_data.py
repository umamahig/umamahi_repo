"""Generate a synthetic DeepWiki tree (apps, components, manifests) for demos/tests.
Deliberately includes gaps (missing sections, missing manifests) to exercise robustness."""
import argparse, json, random
from pathlib import Path

TECH = ["Java 17", "Python 3.11", "Kafka", "PostgreSQL", "Spring Boot 3.2", "Angular", "React", "Redis", "Oracle", "Go", "Node.js 20", "Docker", "Kubernetes"]
CAPS = ["Customer Onboarding", "Payment Processing", "Catalog Management", "Order Fulfilment", "Fraud Detection", "Reporting", "Identity Management", "Notifications"]
TYPES = ["PAA", "SaaS", "COTS", "Custom", "Legacy"]
EVENTS = ["order placed", "payment settled", "customer created", "item updated", "account locked"]

def app_ids(n):
    ids = ["1CAT"]; r = random.Random(1)
    while len(ids) < n:
        x = f"{r.randint(1,9)}{''.join(r.choice('ABCDEFGHJKLMNPQRSTUVWXYZ') for _ in range(3))}"
        if x not in ids: ids.append(x)
    return ids

def main(n, dest, seed=42):
    r = random.Random(seed); dest = Path(dest); ids = app_ids(n)
    topics = [f"{r.choice(['orders','payments','customers','catalog','audit'])}.{r.choice(['created','updated','settled','failed'])}.v{r.randint(1,2)}" for _ in range(max(10, n // 4))]
    for i, a in enumerate(ids):
        d = dest / a; d.mkdir(parents=True, exist_ok=True)
        typ = "PAA" if a == "1CAT" else r.choice(TYPES); techs = r.sample(TECH, r.randint(2, 5)); if_kafka = a == "1CAT" or r.random() < .4
        if a == "1CAT": techs = ["Java 17", "Kafka", "Spring Boot 3.2", "PostgreSQL"]
        deps = r.sample([x for x in ids if x != a], min(3, n - 1)); ind = r.sample([x for x in ids if x != a], min(2, n - 1))
        comps = [f"{a.lower()}-{c}" for c in r.sample(["api", "worker", "ui", "batch", "gateway"], r.randint(1, 3))]
        prod = r.sample(topics, 2) if if_kafka else []; cons = r.sample(topics, 2) if if_kafka else []
        if a == "1CAT": prod, cons = ["orders.created.v1"], ["payments.settled.v1"]
        caps = r.sample(CAPS, r.randint(2, 4))
        if i % 97 != 0:  # a few apps have no manifest
            (d / f"{a}.json").write_text(json.dumps({"appId": a, "name": f"{a} Service", "type": typ, "technologies": [{"name": t.split()[0], "version": (t.split() + [None])[1]} for t in techs],
                "dependencies": {"direct": deps, "indirect": ind}, "components": comps, "environments": {"dev": {}, "uat": {}, "prod": {}},
                "messaging": {"produces": [{"topic": t, "event": r.choice(EVENTS), "broker": "Kafka"} for t in prod], "consumes": [{"topic": t, "broker": "Kafka"} for t in cons]}}, indent=1))
        md = [f"---\nappId: {a}\n---\n# {a} DeepWiki\n", "## 1. Overview", f"{a} is a synthetic application used for the PoC.\n",
              "## 3. Business Capabilities", *[f"- {c}: supports {c.lower()} flows" for c in caps], "",
              "## 4. Application Classification", f"- Application Type: {typ}\n",
              "## 7. Technology Stack", *[f"- {t}" for t in techs], "",
              "## 8. Dependencies", *[f"- Direct: {x}" for x in deps], *[f"- Indirect (transitive): {x}" for x in ind], ""]
        if if_kafka:
            md += ["## 11. Messaging & Events", "### Produces", *[f"- `{t}` (event: {r.choice(EVENTS)})" for t in prod], "### Consumes", *[f"- `{t}`" for t in cons], ""]
        if i % 5 == 0: md = [l for l in md if "Security" not in l]  # partial docs are fine
        (d / "README.md").write_text("\n".join(md))
        for c in comps:
            cd = d / "components" / c; cd.mkdir(parents=True, exist_ok=True)
            ct = r.sample(techs, min(2, len(techs)))
            body = [f"# {c}", "## Overview", f"Component {c} of {a}.", "## Technology Stack", *[f"- {t}" for t in ct]]
            if if_kafka and r.random() < .5 and prod: body += ["## Messaging", f"- Produces to `{prod[0]}` (event: {r.choice(EVENTS)})"]
            (cd / "overview.md").write_text("\n".join(body))
    print(f"generated {n} apps in {dest}")

if __name__ == "__main__":
    ap = argparse.ArgumentParser(); ap.add_argument("--apps", type=int, default=50); ap.add_argument("--dest", default="sample_data"); a = ap.parse_args(); main(a.apps, a.dest)
