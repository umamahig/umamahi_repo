import os, sys, tempfile, importlib.util, pathlib
ROOT = pathlib.Path(__file__).resolve().parent.parent
import pytest

@pytest.fixture(scope="module")
def engine():
    tmp = tempfile.mkdtemp(); os.environ["DEEPWIKI_OUTPUT"] = tmp + "/output"
    for m in [m for m in sys.modules if m.startswith("deepwiki_poc")]: del sys.modules[m]
    sp = importlib.util.spec_from_file_location("gen", ROOT / "scripts" / "generate_sample_data.py")
    g = importlib.util.module_from_spec(sp); sp.loader.exec_module(g); g.main(40, tmp + "/data")
    from deepwiki_poc.pipeline import build
    build(tmp + "/data", mirror_semantica=False)
    from deepwiki_poc.search import Engine
    return Engine()

def test_attribute_yes_no(engine):
    assert "Yes" in engine.ask("Is 1CAT a PAA app?").render()
    assert "No —" in engine.ask("Is 1CAT a SaaS app?").render()

def test_unknown_returns_not_found(engine):
    assert engine.ask("quantum blockchain unicorns").render() == "Information not found in DeepWiki source data"
    assert engine.ask("business capabilities of ZZZZ").render() == "Information not found in DeepWiki source data"

def test_every_answer_has_citations(engine):
    for q in ["Java", "Kafka", "What does 1CAT depend on", "business capabilities of 1CAT", "encryption"]:
        a = engine.ask(q, draw=False)
        assert (not a.found) or a.citations, q

def test_scope_filter(engine):
    a = engine.ask("technology stack", app="1CAT", draw=False)
    assert a.found and all(c.startswith("1CAT/") for c in a.citations)

def test_graph_file_written(engine):
    a = engine.ask("Kafka", app="1CAT")
    assert a.graph_files and pathlib.Path(os.environ["DEEPWIKI_OUTPUT"]).exists()

def test_partial_docs_do_not_break():
    from deepwiki_poc.parser import parse_markdown_text
    meta, secs = parse_markdown_text("random text\n## Technology Stack\n- Java 17\n")
    assert [s.key for s in secs] == ["preamble", "technology_stack"]
