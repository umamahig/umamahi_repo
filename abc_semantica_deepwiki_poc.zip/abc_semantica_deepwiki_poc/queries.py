"""
Enterprise architecture queries over the graph.

These functions operate on the graph produced by Semantica. Keeping the
business queries separate makes it easy to replace the in-memory graph with
Neo4j/FalkorDB later.
"""

from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List


def _nodes(graph):
    return graph.get("entities", [])


def _edges(graph):
    return graph.get("relationships", [])


def _name(x):
    if isinstance(x, dict):
        return x.get("text") or x.get("name") or x.get("id")
    return getattr(x, "text", None) or getattr(x, "name", None) or getattr(x, "id", None)


def _label(x):
    if isinstance(x, dict):
        return x.get("label") or x.get("type")
    return getattr(x, "label", None) or getattr(x, "type", None)


def _predicate(x):
    if isinstance(x, dict):
        return x.get("predicate") or x.get("relation") or x.get("type")
    return (
        getattr(x, "predicate", None)
        or getattr(x, "relation", None)
        or getattr(x, "type", None)
    )


def _subject(x):
    if isinstance(x, dict):
        return x.get("subject") or x.get("source")
    return getattr(x, "subject", None) or getattr(x, "source", None)


def _object(x):
    if isinstance(x, dict):
        return x.get("object") or x.get("target")
    return getattr(x, "object", None) or getattr(x, "target", None)


def _edge_name(x):
    return _name(x) if not isinstance(x, str) else x


def relationships(graph):
    labels = {
        node["id"]: node.get("label") or node.get("name")
        for node in _nodes(graph)
        if isinstance(node, dict) and node.get("id")
    }

    def display_name(endpoint):
        name = _edge_name(endpoint)
        return labels.get(name, name)

    out = []
    for e in _edges(graph):
        out.append({
            "subject": display_name(_subject(e)),
            "predicate": _predicate(e),
            "object": display_name(_object(e)),
            "confidence": (
                e.get("confidence") if isinstance(e, dict)
                else getattr(e, "confidence", None)
            ),
        })
    return out


def direct_dependencies(graph, application: str) -> List[str]:
    app = application.lower()
    return sorted({
        r["object"]
        for r in relationships(graph)
        if r["subject"].lower() == app and r["predicate"] == "depends_on"
    })


def reverse_dependencies(graph, application: str) -> List[str]:
    app = application.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == app and r["predicate"] == "depends_on"
    })


def event_consumers(graph, topic: str) -> List[str]:
    topic = topic.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == topic and r["predicate"] == "consumes_event"
    })


def event_producers(graph, topic: str) -> List[str]:
    topic = topic.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == topic and r["predicate"] == "publishes_event"
    })


def applications_using_technology(graph, technology: str) -> List[str]:
    t = technology.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == t and r["predicate"] == "uses_technology"
    })


def applications_for_capability(graph, capability: str) -> List[str]:
    c = capability.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == c and r["predicate"] == "supports_capability"
    })


def api_consumers(graph, api: str) -> List[str]:
    a = api.lower()
    return sorted({
        r["subject"]
        for r in relationships(graph)
        if r["object"].lower() == a and r["predicate"] == "consumes_api"
    })


def blast_radius(graph, application: str, max_hops: int = 5) -> List[Dict]:
    """
    Traverse reverse dependency edges:
      changed application <- applications depending on it.

    Returns applications with minimum dependency distance.
    """
    start = application.lower()
    reverse = defaultdict(list)

    for r in relationships(graph):
        if r["predicate"] == "depends_on":
            reverse[r["object"].lower()].append(r["subject"])

    q = deque([(start, 0)])
    seen = {start}
    result = []

    while q:
        node, distance = q.popleft()
        if distance >= max_hops:
            continue
        for nxt in reverse.get(node, []):
            key = nxt.lower()
            if key in seen:
                continue
            seen.add(key)
            result.append({"application": nxt, "dependency_hops": distance + 1})
            q.append((key, distance + 1))

    return sorted(result, key=lambda x: (x["dependency_hops"], x["application"].lower()))
