import argparse
import json
from pathlib import Path

from queries import (
    direct_dependencies,
    reverse_dependencies,
    event_consumers,
    event_producers,
    applications_using_technology,
    applications_for_capability,
    blast_radius,
)

p = argparse.ArgumentParser()
p.add_argument("--graph", default="output/abc_graph.json")
p.add_argument("--type", required=True,
               choices=["deps", "reverse-deps", "event-consumers",
                        "event-producers", "technology", "capability", "blast"])
p.add_argument("--value", required=True)
args = p.parse_args()

graph = json.loads(Path(args.graph).read_text(encoding="utf-8"))

fn = {
    "deps": direct_dependencies,
    "reverse-deps": reverse_dependencies,
    "event-consumers": event_consumers,
    "event-producers": event_producers,
    "technology": applications_using_technology,
    "capability": applications_for_capability,
    "blast": blast_radius,
}[args.type]

print(json.dumps(fn(graph, args.value), indent=2))
