from __future__ import annotations

import argparse
import json
from pathlib import Path

from extractor import extract_corpus
from semantica_pipeline import build_semantica_graph, save_graph
from queries import (
    direct_dependencies,
    reverse_dependencies,
    event_consumers,
    event_producers,
    applications_using_technology,
    applications_for_capability,
    blast_radius,
    relationships,
)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--docs", default="deepwiki_docs")
    ap.add_argument("--output", default="output")
    args = ap.parse_args()

    facts = extract_corpus(args.docs)
    print(f"DeepWiki Markdown facts extracted: {len(facts)}")

    graph = build_semantica_graph(facts)
    print(f"Semantica graph nodes: {len(graph.get('entities', []))}")
    print(f"Semantica graph edges: {len(graph.get('relationships', []))}")

    save_graph(graph, args.output)

    results = {
        "payment_service_dependencies": direct_dependencies(graph, "Payment Service"),
        "who_depends_on_customer_service": reverse_dependencies(graph, "Customer Service"),
        "customer_updated_consumers": event_consumers(graph, "customer.updated"),
        "payment_created_producers": event_producers(graph, "payment.created"),
        "java_11_applications": applications_using_technology(graph, "Java 11"),
        "payments_capability_applications": applications_for_capability(graph, "Payments"),
        "customer_service_blast_radius": blast_radius(graph, "Customer Service"),
        "relationship_count": len(relationships(graph)),
    }

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)
    (out / "query_results.json").write_text(
        json.dumps(results, indent=2), encoding="utf-8"
    )

    print("\n=== ABC Enterprise Architecture Queries ===")
    for key, value in results.items():
        print(f"\n{key}:")
        print(json.dumps(value, indent=2))

    print(f"\nArtifacts written to: {out.resolve()}")


if __name__ == "__main__":
    main()
