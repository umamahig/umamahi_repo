"""
Build an ABC Application Landscape Graph with Semantica.

The current Semantica API accepts:
    GraphBuilder().build({
        "entities": [{"id": "...", "type": "..."}],
        "relationships": [{"source": "...", "target": "...", "type": "..."}]
    })

We intentionally keep DeepWiki/ABC extraction deterministic in extractor.py.
This means the POC does not invent architecture relationships with an LLM.
Semantica is responsible for the knowledge-graph representation, entity
merging, visualization and export.
"""

from __future__ import annotations

import json
from pathlib import Path
from typing import Dict, List

from extractor import Fact


TYPE_MAP = {
    "depends_on": "Application",
    "exposes_api": "API",
    "consumes_event": "KafkaTopic",
    "publishes_event": "KafkaTopic",
    "uses_database": "Database",
    "uses_technology": "Technology",
    "supports_capability": "BusinessCapability",
    "owned_by": "Team",
    "deployed_in": "Environment",
}


def node_id(name: str, entity_type: str) -> str:
    safe = "".join(ch.lower() if ch.isalnum() else "_" for ch in name.strip())
    safe = "_".join(part for part in safe.split("_") if part)
    return f"{entity_type.lower()}::{safe}"


def build_semantica_graph(facts: List[Fact]) -> Dict:
    from semantica.kg import GraphBuilder

    entities = {}
    relationships = []

    for f in facts:
        subject_id = node_id(f.subject, "Application")
        entities.setdefault(
            subject_id,
            {
                "id": subject_id,
                "type": "Application",
                "label": f.subject,
                "metadata": {
                    "source_file": f.source_file,
                    "source_section": f.source_section,
                    "extraction": "abc_markdown_rules",
                },
            },
        )

        target_type = TYPE_MAP[f.predicate]
        target_id = node_id(f.object, target_type)
        entities.setdefault(
            target_id,
            {
                "id": target_id,
                "type": target_type,
                "label": f.object,
                "metadata": {
                    "source_file": f.source_file,
                    "source_section": f.source_section,
                    "extraction": "abc_markdown_rules",
                },
            },
        )

        relationships.append(
            {
                "source": subject_id,
                "target": target_id,
                "type": f.predicate,
                "metadata": {
                    "source_file": f.source_file,
                    "source_section": f.source_section,
                    "confidence": f.confidence,
                },
            }
        )

    builder = GraphBuilder(merge_entities=True)
    graph = builder.build(
        {
            "entities": list(entities.values()),
            "relationships": relationships,
        }
    )

    # Keep the original ABC facts alongside the Semantica graph so every
    # enterprise relationship can be traced back to the DeepWiki Markdown.
    graph["_abc_provenance"] = [f.to_dict() for f in facts]
    return graph


def save_graph(graph: Dict, output_dir: str):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    with open(out / "abc_graph.json", "w", encoding="utf-8") as fp:
        json.dump(graph, fp, indent=2, default=str)

    try:
        from semantica.export import RDFExporter
        exporter = RDFExporter()
        exporter.export(graph, file_path=str(out / "abc_graph.ttl"), format="turtle")
        exporter.export(graph, file_path=str(out / "abc_graph.jsonld"), format="json-ld")
    except Exception as exc:
        (out / "rdf_export_note.txt").write_text(
            "RDF export was unavailable: " + repr(exc), encoding="utf-8"
        )

    try:
        from semantica.visualization import KGVisualizer
        KGVisualizer(layout="force").visualize_network(
            graph,
            output="html",
            file_path=str(out / "graph.html"),
            node_color_by="type",
        )
    except Exception as exc:
        (out / "visualization_note.txt").write_text(
            "Visualization was unavailable: " + repr(exc), encoding="utf-8"
        )
