"""
ABC-specific DeepWiki Markdown extractor.

This is intentionally deterministic. It extracts facts from known Markdown
sections instead of asking an LLM to infer arbitrary relationships.

For a production corpus, adapt SECTION_ALIASES and parsing rules to the
actual DeepWiki templates used by ABC.
"""

from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import re
from typing import List, Dict


@dataclass
class Fact:
    subject: str
    predicate: str
    object: str
    source_file: str
    source_section: str
    confidence: float = 1.0

    def to_dict(self):
        return asdict(self)


def clean_item(line: str) -> str:
    line = line.strip()
    line = re.sub(r"^[-*]\s*", "", line)
    return line.strip()


def section_blocks(text: str) -> Dict[str, List[str]]:
    blocks = {}
    current = "ROOT"
    blocks[current] = []

    for raw in text.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", raw)
        if m:
            current = m.group(1).strip()
            blocks.setdefault(current, [])
        else:
            blocks[current].append(raw.rstrip())

    return blocks


def items(block: List[str]) -> List[str]:
    return [clean_item(x) for x in block if clean_item(x)]


def extract_file(path: Path) -> List[Fact]:
    text = path.read_text(encoding="utf-8")
    blocks = section_blocks(text)

    m = re.search(r"^#\s+Application:\s*(.+?)\s*$", text, flags=re.M)
    if not m:
        raise ValueError(f"Missing '# Application:' heading in {path}")

    app = m.group(1).strip()
    facts: List[Fact] = []

    def add(predicate, obj, section, confidence=1.0):
        facts.append(Fact(app, predicate, obj, str(path), section, confidence))

    for x in items(blocks.get("Technology", [])):
        add("uses_technology", x, "Technology")

    for x in items(blocks.get("Dependencies", [])):
        add("depends_on", x, "Dependencies")

    api_lines = items(blocks.get("APIs", []))
    for x in api_lines:
        add("exposes_api", x, "APIs")

    event_lines = blocks.get("Events", [])
    mode = None
    for raw in event_lines:
        line = raw.strip()
        if not line:
            continue
        low = line.lower().rstrip(":")
        if low == "consumes":
            mode = "consumes_event"
            continue
        if low == "publishes":
            mode = "publishes_event"
            continue
        x = clean_item(line)
        if x and mode:
            add(mode, x, "Events")

    for x in items(blocks.get("Database", [])):
        add("uses_database", x, "Database")

    for x in items(blocks.get("Business Capability", [])):
        add("supports_capability", x, "Business Capability")

    for x in items(blocks.get("Owner", [])):
        add("owned_by", x, "Owner")

    for x in items(blocks.get("Environment", [])):
        add("deployed_in", x, "Environment")

    return facts


def extract_corpus(root: str) -> List[Fact]:
    root_path = Path(root)
    facts = []
    for path in sorted(root_path.rglob("*.md")):
        facts.extend(extract_file(path))
    return facts
