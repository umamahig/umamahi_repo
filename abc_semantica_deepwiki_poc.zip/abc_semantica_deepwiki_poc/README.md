# ABC + DeepWiki + Semantica: Application Landscape POC

This project demonstrates the architecture discussed in the conversation:

DeepWiki-generated Markdown -> Semantica -> ABC Application Knowledge Graph -> cross-application queries / impact analysis.

## What this POC does

It uses sample DeepWiki-style Markdown files for four ABC applications:

- customer-service
- payment-service
- fraud-service
- notification-service

The Markdown describes APIs, Kafka topics, databases, technologies, business capabilities, and application dependencies.

The pipeline:

1. Reads the Markdown corpus.
2. Extracts structured ABC architecture facts using deterministic Markdown-aware rules.
3. Builds a Semantica knowledge graph.
4. Adds source-document provenance metadata to entities and relationships.
5. Exports JSON, JSON-LD/Turtle (when supported), and an interactive HTML graph.
6. Runs useful enterprise-architecture queries:
   - direct dependencies
   - reverse dependencies
   - Kafka topic consumers/producers
   - technology adoption
   - business capability applications
   - API impact analysis
   - dependency blast radius

## Why deterministic extraction is used here

This POC deliberately extracts known ABC architecture fields from Markdown instead of relying on an LLM to guess relationships. That makes the sample reproducible and safe to test.

For a production implementation, replace/augment `extractor.py` with Semantica's NERExtractor / RelationExtractor or a controlled LLM extraction pipeline after defining the ABC ontology and validation rules.

Current Semantica documentation shows the supported pipeline:
Ingest -> Parse -> Extract -> Build KG -> Visualize/Export, and pattern-based extraction works without an API key.

## Prerequisites

Python 3.10+ recommended.

Install:

    pip install -r requirements.txt

The project uses the current Semantica package API. The code is designed to fail clearly if an incompatible Semantica version is installed.

## Run

    python run_demo.py

Outputs are written under:

    output/

Important files:

- `output/abc_graph.json` - graph nodes and relationships
- `output/abc_graph.jsonld` - JSON-LD if exporter is available
- `output/abc_graph.ttl` - Turtle if exporter is available
- `output/graph.html` - interactive graph if visualization is available
- `output/query_results.json` - all demo query results

## Replace the sample DeepWiki corpus

Put your real DeepWiki-generated `.md` files under:

    deepwiki_docs/

Then run:

    python run_demo.py --docs deepwiki_docs

The parser expects headings such as:

    # Application: Payment Service

    ## Technology
    - Java 17
    - Spring Boot

    ## Dependencies
    - Customer Service

    ## APIs
    POST /payments

    ## Events
    Consumes:
    - customer.updated

    Publishes:
    - payment.created

    ## Database
    - PaymentDB

    ## Business Capability
    - Payments

You can adapt `extractor.py` to your exact DeepWiki format.

## Production architecture

    Git / source repositories
             |
          DeepWiki
             |
       Markdown corpus
          /        \
         /          \
    DeepWiki RAG   Semantica
                      |
              ABC Application Graph
                      |
             +--------+---------+
             |                  |
       impact analysis     governance
             |
           Agent/LLM
             |
       evidence from Markdown

The key point is that Semantica is NOT replacing DeepWiki. The graph is a structured cross-application representation of selected architecture facts, while the Markdown remains the detailed evidence/source.

## Accuracy guidance

Do not treat automatically extracted relationships as authoritative architecture facts without validation. For a real ABC deployment:

1. Define an explicit ontology.
2. Define allowed relationship types.
3. Attach source file and section to every fact.
4. Preserve extraction confidence.
5. Run graph/ontology validation.
6. Flag conflicts rather than silently choosing one.
7. Make humans approve high-impact dependency relationships.


## Current Semantica API used

The project follows the current documented pattern:

```python
from semantica.kg import GraphBuilder

graph = GraphBuilder(merge_entities=True).build({
    "entities": [
        {"id": "application::payment_service", "type": "Application"},
    ],
    "relationships": [],
})
```

Semantica currently documents `pip install semantica`, document ingestion/parsing,
semantic extraction, GraphBuilder, visualization and RDF/JSON-LD export. Pattern
extraction requires no API key. For higher-accuracy free-form extraction, its
LLM mode supports configured providers. See the official documentation:
https://docs.getsemantica.ai/
