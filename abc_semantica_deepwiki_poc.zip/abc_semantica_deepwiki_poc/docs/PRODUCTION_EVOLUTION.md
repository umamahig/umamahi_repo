# Production evolution

## Phase 1 — POC

DeepWiki Markdown
-> deterministic ABC extractor
-> Semantica graph
-> impact/dependency queries

## Phase 2 — Better extraction

Use Semantica's NERExtractor and RelationExtractor with a controlled LLM provider
for sections that are not consistently structured.

Do not let an LLM invent arbitrary application dependencies. Constrain the
allowed entity and relationship types and require source evidence.

## Phase 3 — Ontology and validation

Define an ABC ontology:

- Application
- Service
- API
- KafkaTopic
- Database
- Technology
- BusinessCapability
- Team
- Owner
- Environment

Define allowed relationships and SHACL constraints.

Examples:

- Production Application must have Owner.
- Production Application must have BusinessCapability.
- Kafka Consumer must identify a KafkaTopic.
- API must identify its owning Application.

Semantica's OntologyEngine supports ontology generation and SHACL validation.

## Phase 4 — Persistent graph

For a large ABC estate, move from the in-memory graph to a persistent graph
backend such as Neo4j or FalkorDB.

## Phase 5 — Agent / GraphRAG

Use Semantica ContextGraph/AgentContext when you want hybrid vector + graph
retrieval and an agent that can traverse the application landscape.

The Markdown remains the detailed evidence source; the graph becomes the
cross-document relationship layer.

## Phase 6 — Change intelligence

Run the pipeline on every documentation refresh and maintain graph versions.
Compare snapshots to identify:

- new dependencies
- removed dependencies
- API changes
- technology changes
- Kafka producer/consumer changes
- ownership changes
