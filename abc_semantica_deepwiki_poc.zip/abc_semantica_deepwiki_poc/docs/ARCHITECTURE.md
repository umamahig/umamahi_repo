# ABC DeepWiki -> Semantica architecture

## What is input?

DeepWiki-generated Markdown for every ABC application.

Example:

    deepwiki_docs/
      payment-service/architecture.md
      fraud-service/architecture.md
      customer-service/architecture.md

## What happens?

1. `extractor.py` reads known ABC Markdown sections.
2. It emits canonical architecture facts:
   `(subject, predicate, object, source_file, source_section)`.
3. `semantica_pipeline.py` converts those facts into Semantica entities and relationships.
4. Semantica `GraphBuilder` creates the application landscape graph.
5. Every relationship keeps `source_file` and `source_section` metadata.
6. `queries.py` performs enterprise architecture analysis.

## Why not just use Semantica NER on everything?

Because architecture documentation contains domain-specific statements such as:

    Payment Service consumes customer.updated

A generic NER model may identify `Payment Service` but not reliably create the exact
ABC relationship you need. For a controlled enterprise POC, deterministic extraction
from known DeepWiki sections is safer.

For free-form text, Semantica also provides NERExtractor and RelationExtractor with
pattern, HuggingFace, and LLM modes. See `optional_semantica_llm_extraction.py`.

## What Semantica adds

The important artifact is:

    ABC Application Landscape Graph

Example edge:

    payment-service
       --consumes_event-->
    customer.updated

with metadata:

    source_file = deepwiki_docs/payment-service/architecture.md
    source_section = Events
    confidence = 1.0

This allows the agent/application to use the graph for:

- dependency discovery
- reverse dependency discovery
- API impact analysis
- Kafka producer/consumer analysis
- technology migration analysis
- business capability mapping
- architecture governance
- documentation conflict detection
- future GraphRAG

The original Markdown remains the detailed evidence.

## Production next step

For a large ABC estate:

    DeepWiki
       |
       v
    Markdown
       |
       +--------------------+
       |                    |
       v                    v
    DeepWiki RAG       Semantica Graph
                            |
                     persistent backend
                     (Neo4j/FalkorDB/etc.)
                            |
                            v
                     Architecture Agent

Do not let an LLM freely invent architecture relationships. Constrain the ontology,
preserve provenance, validate relationships, and send uncertain/conflicting facts
to human review.
