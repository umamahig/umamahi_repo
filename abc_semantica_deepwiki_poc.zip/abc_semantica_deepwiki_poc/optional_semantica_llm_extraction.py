"""
OPTIONAL: higher-accuracy extraction for free-form DeepWiki Markdown.

Do NOT use this as the first production step. First define and validate the
ABC ontology and allowed relationship types.

This example shows the current Semantica extractor API. Set a supported
provider/API key before running. The POC itself does not require an API key.
"""

import os
from semantica.semantic_extract import NERExtractor, RelationExtractor
from semantica.llms import Groq

text = open("deepwiki_docs/payment-service/architecture.md", encoding="utf-8").read()

llm = Groq(
    model=os.environ["GROQ_MODEL"],
    api_key=os.environ["GROQ_API_KEY"],
)

entities = NERExtractor(
    method="llm",
    llm_provider=llm,
).extract(text)

relationships = RelationExtractor(
    method="llm",
    llm_provider=llm,
).extract(text, entities=entities)

print("Entities:")
for e in entities:
    print(e)

print("\nRelationships:")
for r in relationships:
    print(r)
