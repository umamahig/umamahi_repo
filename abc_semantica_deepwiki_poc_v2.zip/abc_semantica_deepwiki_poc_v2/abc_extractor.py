from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import re
from typing import List, Dict


@dataclass
class Fact:
    subject: str
    predicate: str
    object: str
    source_file: str
    source_section: str
    confidence: float = 1.0
    extraction_method: str = "abc_markdown_rules"

    def to_dict(self):
        return asdict(self)


def clean(line: str) -> str:
    return re.sub(r"^[-*]\s*", "", line.strip()).strip()


def sections(text: str) -> Dict[str, List[str]]:
    result = {"ROOT": []}
    current = "ROOT"
    for raw in text.splitlines():
        m = re.match(r"^##\s+(.+?)\s*$", raw)
        if m:
            current = m.group(1).strip()
            result.setdefault(current, [])
        else:
            result[current].append(raw.rstrip())
    return result


def values(lines: List[str]) -> List[str]:
    return [clean(x) for x in lines if clean(x)]


def extract_file(path: Path) -> List[Fact]:
    text = path.read_text(encoding="utf-8")
    sec = sections(text)

    match = re.search(r"^#\s+Application:\s*(.+?)\s*$", text, re.M)
    if not match:
        raise ValueError(f"{path}: missing '# Application:'")

    app = match.group(1).strip()
    facts = []

    def add(predicate, obj, section, confidence=1.0):
        facts.append(
            Fact(
                app, predicate, obj, str(path), section,
                confidence=confidence,
            )
        )

    for x in values(sec.get("Technology", [])):
        add("uses_technology", x, "Technology")

    for x in values(sec.get("Dependencies", [])):
        add("depends_on", x, "Dependencies")

    for x in values(sec.get("APIs", [])):
        add("exposes_api", x, "APIs")

    mode = None
    for raw in sec.get("Events", []):
        line = raw.strip()
        if not line:
            continue
        low = line.lower().rstrip(":")
        if low == "consumes":
            mode = "consumes_event"
            continue
        if low == "publishes":
            mode = "publishes_event"
            continue
        if mode:
            add(mode, clean(line), "Events")

    for x in values(sec.get("Database", [])):
        add("uses_database", x, "Database")

    for x in values(sec.get("Business Capability", [])):
        add("supports_capability", x, "Business Capability")

    for x in values(sec.get("Owner", [])):
        add("owned_by", x, "Owner")

    for x in values(sec.get("Environment", [])):
        add("deployed_in", x, "Environment")

    return facts


def extract_corpus(root: str) -> List[Fact]:
    return [
        fact
        for path in sorted(Path(root).rglob("*.md"))
        for fact in extract_file(path)
    ]
