import argparse
import json
from pathlib import Path
from datetime import datetime, timezone

p = argparse.ArgumentParser()
p.add_argument("--graph", default="output/abc_graph.json")
p.add_argument("--output", default="snapshots/baseline.json")
args = p.parse_args()

graph = json.loads(Path(args.graph).read_text(encoding="utf-8"))
Path(args.output).parent.mkdir(parents=True, exist_ok=True)

payload = {
    "created_at": datetime.now(timezone.utc).isoformat(),
    "graph": graph,
}

Path(args.output).write_text(
    json.dumps(payload, indent=2, default=str),
    encoding="utf-8",
)

print("Snapshot:", args.output)
