from __future__ import annotations

import argparse
import json
from pathlib import Path

from abc_extractor import extract_corpus
from semantica_graph import (
    build_with_semantica,
    attach_provenance,
    export_graph,
    persistent_store_demo,
)
from enterprise_queries import (
    direct_dependencies,
    reverse_dependencies,
    event_consumers,
    event_producers,
    technology_users,
    capability_apps,
    blast_radius,
    enterprise_summary,
    connected_business_impact,
)
from governance import run_governance


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--docs", default="deepwiki_docs")
    parser.add_argument("--output", default="output")
    parser.add_argument("--neo4j-uri", default=None)
    parser.add_argument("--neo4j-user", default=None)
    parser.add_argument("--neo4j-password", default=None)
    args = parser.parse_args()

    out = Path(args.output)
    out.mkdir(parents=True, exist_ok=True)

    print("1. Reading DeepWiki Markdown...")
    facts = extract_corpus(args.docs)
    (out / "abc_facts.json").write_text(
        json.dumps([f.to_dict() for f in facts], indent=2),
        encoding="utf-8",
    )
    print(f"   Extracted facts: {len(facts)}")

    print("2. Building Semantica Application Landscape Graph...")
    graph, graph_data = build_with_semantica(facts)
    print(f"   Nodes: {len(graph.get('entities', []))}")
    print(f"   Relationships: {len(graph.get('relationships', []))}")

    print("3. Recording provenance...")
    prov = attach_provenance(facts, str(out / "provenance"))

    print("4. Exporting graph...")
    export_graph(graph, str(out))

    print("5. Running enterprise queries...")
    queries = {
        "enterprise_summary": enterprise_summary(graph),
        "payment_service_dependencies": direct_dependencies(graph, "Payment Service"),
        "who_depends_on_customer_service": reverse_dependencies(graph, "Customer Service"),
        "customer_updated_consumers": event_consumers(graph, "customer.updated"),
        "payment_created_producers": event_producers(graph, "payment.created"),
        "java_11_applications": technology_users(graph, "Java 11"),
        "payments_applications": capability_apps(graph, "Payments"),
        "customer_service_blast_radius": blast_radius(graph, "Customer Service"),
        "customer_service_business_impact": connected_business_impact(
            graph, "Customer Service"
        ),
    }

    (out / "enterprise_queries.json").write_text(
        json.dumps(queries, indent=2, default=str),
        encoding="utf-8",
    )

    print("6. Running architecture governance...")
    governance = run_governance(graph, str(out))

    if args.neo4j_uri:
        print("7. Persisting graph to Neo4j...")
        try:
            persistent_store_demo(
                graph_data,
                uri=args.neo4j_uri,
                user=args.neo4j_user,
                password=args.neo4j_password,
            )
            print("   Neo4j persistence attempted.")
        except Exception as exc:
            print("   Neo4j persistence failed:", repr(exc))
    else:
        print("7. Persistent graph: skipped (no --neo4j-uri).")

    (out / "README_OUTPUT.md").write_text(
        """# Generated Output

This directory contains:

- `abc_graph.json`: Semantica application landscape graph
- `abc_facts.json`: extracted facts with source evidence
- `enterprise_queries.json`: cross-application query results
- `governance_report.json`: ABC governance + Semantica ontology results
- `change_report.json`: generated when snapshot comparison is run
- `provenance/`: provenance ledger and Semantica provenance output
- `ontology/`: ontology/SHACL artifacts when supported
- `graph.html`: interactive visualization when supported

The graph is derived from DeepWiki Markdown. The Markdown remains the
evidence source.
""",
        encoding="utf-8",
    )

    print("\nDONE.")
    print("Open output/enterprise_queries.json and output/governance_report.json")


if __name__ == "__main__":
    main()
