from __future__ import annotations

import json
from pathlib import Path


def key_node(n):
    if isinstance(n, dict):
        return (n.get("type"), n.get("label") or n.get("name") or n.get("id"))
    return str(n)


def key_edge(e):
    if isinstance(e, dict):
        s = e.get("source") or e.get("subject")
        t = e.get("target") or e.get("object")
        p = e.get("type") or e.get("predicate")
        if isinstance(s, dict):
            s = s.get("label") or s.get("id")
        if isinstance(t, dict):
            t = t.get("label") or t.get("id")
        return (s, p, t)
    return str(e)


def compare(old_graph, new_graph):
    old_nodes = {key_node(n) for n in old_graph.get("entities", [])}
    new_nodes = {key_node(n) for n in new_graph.get("entities", [])}

    old_edges = {key_edge(e) for e in old_graph.get("relationships", [])}
    new_edges = {key_edge(e) for e in new_graph.get("relationships", [])}

    return {
        "nodes_added": sorted(new_nodes - old_nodes),
        "nodes_removed": sorted(old_nodes - new_nodes),
        "relationships_added": sorted(new_edges - old_edges),
        "relationships_removed": sorted(old_edges - new_edges),
    }


def load(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
