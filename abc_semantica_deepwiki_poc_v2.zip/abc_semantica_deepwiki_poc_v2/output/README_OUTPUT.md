# Generated Output

This directory contains:

- `abc_graph.json`: Semantica application landscape graph
- `abc_facts.json`: extracted facts with source evidence
- `enterprise_queries.json`: cross-application query results
- `governance_report.json`: ABC governance + Semantica ontology results
- `change_report.json`: generated when snapshot comparison is run
- `provenance/`: provenance ledger and Semantica provenance output
- `ontology/`: ontology/SHACL artifacts when supported
- `graph.html`: interactive visualization when supported

The graph is derived from DeepWiki Markdown. The Markdown remains the
evidence source.
