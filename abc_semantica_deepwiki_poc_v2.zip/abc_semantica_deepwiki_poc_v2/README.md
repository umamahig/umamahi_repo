# ABC Application Landscape Graph
## DeepWiki Markdown -> Semantica -> Enterprise Architecture Intelligence

This is an end-to-end Python POC for an organization named **ABC**.

The intended architecture is:

    ABC source repositories
            |
          DeepWiki
            |
      DeepWiki Markdown
            |
            +--------------------+
            |                    |
            v                    v
       DeepWiki RAG          Semantica
                                  |
                         Application Landscape
                               Graph
                                  |
             +--------------------+--------------------+
             |                    |                    |
       Dependency Analysis   Impact Analysis     Governance
             |                    |                    |
             +--------------------+--------------------+
                                  |
                           Enterprise Queries
                                  |
                              AI Agent/LLM

## What Semantica is doing here

Semantica is NOT replacing DeepWiki.

DeepWiki remains the detailed documentation/evidence layer.

Semantica converts selected architecture facts from the DeepWiki Markdown
corpus into a cross-application graph.

Example:

    payment-service
       --depends_on--> customer-service
       --depends_on--> fraud-service
       --consumes_event--> customer.updated
       --publishes_event--> payment.created
       --uses_database--> PaymentDB
       --uses_technology--> Java 17
       --supports_capability--> Payments

Every fact also retains source information:

    source_file
    source_section
    extraction_method
    confidence

This enables enterprise questions that are relationship-oriented rather than
document-oriented.

Examples:

- Which applications depend on Customer Service?
- Who consumes customer.updated?
- What is the blast radius if Customer Service changes?
- Which applications use Java 11?
- Which applications support Payments?
- Which production applications have no owner?
- Which architecture facts conflict?
- What changed between two graph snapshots?
- What business capabilities depend on a given application?
- What APIs/events/databases are connected to an application?

## Capabilities included

### 1. DeepWiki Markdown ingestion
The project recursively reads `.md` files from `deepwiki_docs/`.

### 2. ABC architecture extraction
The default extractor is deterministic and understands common sections:

- Application
- Technology
- Dependencies
- APIs
- Events
- Database
- Business Capability
- Owner
- Environment

This avoids hallucinating relationships.

### 3. Semantica Knowledge Graph
Uses Semantica `GraphBuilder` to construct the graph.

### 4. Provenance
Uses Semantica `ProvenanceManager` when available and also stores explicit
ABC source metadata on every fact.

### 5. Ontology and governance
Creates an ABC ontology model and, when the installed Semantica version
supports the API, generates/validates ontology and SHACL constraints.

Governance rules include:

- production application should have an owner
- production application should have a business capability
- every Kafka consumer relationship must identify a topic
- every API relationship must identify an application

### 6. Dependency analysis
Direct and reverse dependencies.

### 7. Impact analysis
Multi-hop dependency blast radius.

### 8. Enterprise-wide queries
Applications by technology, capability, owner, environment, database,
Kafka topic, API, and business domain.

### 9. Architecture drift/change analysis
Compare two graph snapshots and report added/removed nodes and relationships.

### 10. Persistent graph option
Supports Semantica's GraphStore configuration for Neo4j/FalkorDB when the
corresponding extras/backend are installed.

### 11. Graph export
Attempts Semantica JSON/JSON-LD/Turtle/RDF export and HTML visualization.

### 12. LLM-assisted extraction option
An optional script shows how to use Semantica NERExtractor and
RelationExtractor for free-form DeepWiki text. The production recommendation
is to constrain extraction with the ABC ontology rather than allowing arbitrary
LLM-generated relationships.

## Installation

Recommended:

    python -m venv .venv

Windows:

    .venv\Scripts\activate

Linux/macOS:

    source .venv/bin/activate

Then:

    pip install -U pip
    pip install -r requirements.txt

For all optional Semantica integrations:

    pip install "semantica[all]"

Verify:

    python -c "import semantica; print(semantica.__version__)"

The current Semantica documentation lists 0.7.0 in the getting-started
documentation and documents `pip install semantica` / `semantica[all]`.
Check the official documentation for the version currently published when
you install.

## Run the complete POC

    python run_pipeline.py

Or explicitly:

    python run_pipeline.py --docs deepwiki_docs --output output

Then inspect:

    output/
      abc_graph.json
      abc_facts.json
      enterprise_queries.json
      governance_report.json
      change_report.json
      ontology/
      graph.html
      provenance/
      README_OUTPUT.md

## Run individual enterprise queries

    python query_cli.py deps "Payment Service"

    python query_cli.py reverse-deps "Customer Service"

    python query_cli.py event-consumers "customer.updated"

    python query_cli.py event-producers "payment.created"

    python query_cli.py technology "Java 11"

    python query_cli.py capability "Payments"

    python query_cli.py blast "Customer Service"

    python query_cli.py owner "Payments Engineering Team"

    python query_cli.py environment "Production"

    python query_cli.py database "CustomerDB"

## Run governance validation

    python governance.py

The report identifies missing/invalid architecture information.

## Run change analysis

First generate a baseline:

    python snapshot.py --output snapshots/baseline.json

After the DeepWiki corpus changes:

    python run_pipeline.py

Then:

    python compare_snapshots.py snapshots/baseline.json output/abc_graph.json

## Add your real DeepWiki files

Replace the sample files under:

    deepwiki_docs/

with the Markdown files generated by DeepWiki.

Recommended structure:

    deepwiki_docs/
      application-a/
        architecture.md
        api.md
        deployment.md
        database.md
      application-b/
        architecture.md
        ...

The extractor can be adapted in `abc_extractor.py` to your exact DeepWiki
headings.

## Semantica-native modules used

This project is intentionally aligned to the current Semantica architecture:

- `semantica.kg.GraphBuilder`
- `semantica.provenance.ProvenanceManager`
- `semantica.ontology.OntologyEngine` where available
- `semantica.graph_store.GraphStore` where a persistent backend is configured
- `semantica.export` where exporters are available
- `semantica.visualization` where visualization is available
- optional `semantica.semantic_extract.NERExtractor`
- optional `semantica.semantic_extract.RelationExtractor`
- optional `semantica.context.ContextGraph` / `AgentContext`

## Important production rule

Do NOT treat the graph as automatically authoritative merely because it was
generated from DeepWiki.

The authoritative evidence is the source Markdown plus the extraction
metadata.

For production:

1. Define the ABC ontology.
2. Constrain allowed relationship types.
3. Keep source file + section + checksum.
4. Preserve extraction confidence.
5. Validate with SHACL.
6. Detect conflicts.
7. Route uncertain/high-impact changes for human approval.
8. Keep graph snapshots for architecture change tracking.

That is what turns this POC into an enterprise architecture intelligence
platform rather than another chatbot.
