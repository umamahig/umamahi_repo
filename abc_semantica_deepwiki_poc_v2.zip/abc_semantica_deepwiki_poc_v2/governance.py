from __future__ import annotations

import json
from pathlib import Path
from enterprise_queries import normalize, edges


def local_governance_checks(graph):
    """
    Deterministic ABC architecture governance.

    This runs even if optional ontology/SHACL support is not installed.
    It is intentionally conservative: a missing relationship is a finding,
    not proof that the architecture itself is wrong.
    """
    nodes, _ = normalize(graph)

    apps = [
        n for n in nodes.values()
        if (n["type"] or "").lower() == "application"
    ]

    owner_edges = edges(graph, "owned_by")
    cap_edges = edges(graph, "supports_capability")
    env_edges = edges(graph, "deployed_in")

    owners = {e["source"].lower() for e in owner_edges}
    caps = {e["source"].lower() for e in cap_edges}
    production = {
        e["source"].lower()
        for e in env_edges
        if e["target"].lower() == "production"
    }

    findings = []

    for app in apps:
        key = app["name"].lower()

        if key in production and key not in owners:
            findings.append({
                "severity": "HIGH",
                "rule": "PROD_APP_OWNER",
                "application": app["name"],
                "message": "Production application has no documented owner.",
            })

        if key in production and key not in caps:
            findings.append({
                "severity": "MEDIUM",
                "rule": "PROD_APP_CAPABILITY",
                "application": app["name"],
                "message": "Production application has no documented business capability.",
            })

    # Relationship-level completeness checks.
    for e in edges(graph, "consumes_event"):
        if not e["target"]:
            findings.append({
                "severity": "HIGH",
                "rule": "EVENT_CONSUMER_TOPIC",
                "application": e["source"],
                "message": "Kafka consumer has no topic.",
            })

    return {
        "conforms_local_rules": not any(f["severity"] == "HIGH" for f in findings),
        "finding_count": len(findings),
        "findings": findings,
    }


def semantica_ontology_validation(graph, output_dir):
    """
    Best-effort Semantica OntologyEngine integration.

    Semantica's ontology module supports:
      - ontology generation
      - SHACL generation
      - graph validation
      - OWL/RDF export

    The POC keeps local governance checks as the deterministic baseline and
    attempts native Semantica ontology functionality when the installed
    release exposes it.
    """
    out = Path(output_dir)
    ont_dir = out / "ontology"
    ont_dir.mkdir(parents=True, exist_ok=True)

    try:
        from semantica.ontology import OntologyEngine

        engine = OntologyEngine(
            base_uri="https://abc.example.com/ontology/application/"
        )

        ontology = engine.from_data({
            "entities": graph.get("entities", []),
            "relationships": graph.get("relationships", []),
        })

        result = {
            "semantica_ontology": "generated",
        }

        try:
            engine.export_owl(
                ontology,
                str(ont_dir / "abc_application_ontology.ttl"),
                format="turtle",
            )
        except Exception as exc:
            result["owl_export_error"] = repr(exc)

        try:
            engine.export_shacl(
                ontology,
                str(ont_dir / "abc_application_shapes.ttl"),
            )
        except Exception as exc:
            result["shacl_export_error"] = repr(exc)

        try:
            report = engine.validate_graph(graph, ontology=ontology)
            result["validation_report"] = str(report)
            result["conforms"] = getattr(report, "conforms", None)
        except Exception as exc:
            result["validation_error"] = repr(exc)

        (ont_dir / "semantica_ontology_result.json").write_text(
            json.dumps(result, indent=2, default=str), encoding="utf-8"
        )

        return result

    except Exception as exc:
        result = {
            "semantica_ontology": "unavailable_or_incompatible",
            "error": repr(exc),
            "note": "Local deterministic ABC governance checks remain available.",
        }
        (ont_dir / "semantica_ontology_result.json").write_text(
            json.dumps(result, indent=2), encoding="utf-8"
        )
        return result


def run_governance(graph, output_dir):
    local = local_governance_checks(graph)
    native = semantica_ontology_validation(graph, output_dir)

    report = {
        "local_abc_governance": local,
        "semantica_native_ontology": native,
    }

    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)
    (out / "governance_report.json").write_text(
        json.dumps(report, indent=2, default=str),
        encoding="utf-8",
    )

    return report


if __name__ == "__main__":
    graph_path = Path("output/abc_graph.json")
    if not graph_path.exists():
        raise SystemExit("Run: python run_pipeline.py first")

    graph = json.loads(graph_path.read_text(encoding="utf-8"))
    print(json.dumps(run_governance(graph, "output"), indent=2, default=str))
