# Production Architecture

Recommended target:

```text
                    ABC SOURCE REPOSITORIES
                             |
                           DeepWiki
                             |
                     Markdown Knowledge
                             |
             +---------------+----------------+
             |                                |
             v                                v
        DeepWiki RAG                    Semantica Pipeline
             |                                |
        document Q&A                    Parse / Extract
                                              |
                                         ABC Ontology
                                              |
                                         GraphBuilder
                                              |
                                         Provenance
                                              |
                                      Persistent Graph
                                      Neo4j/FalkorDB
                                              |
                 +----------------------------+----------------------+
                 |                            |                      |
          Dependency API               Governance             Change Analysis
                 |                            |                      |
                 +----------------------------+----------------------+
                                              |
                                          GraphRAG
                                              |
                                           AI Agent
                                              |
                                            LLM
                                              |
                                  Answer + source evidence
```

## Separation of responsibilities

### DeepWiki

- code/document understanding
- generated Markdown
- detailed application documentation
- document-oriented retrieval

### Semantica

- entity/relationship model
- application landscape graph
- ontology
- provenance
- validation
- graph traversal
- GraphRAG/context
- decision/context layer
- change tracking

### LLM

- natural language interaction
- explanation
- synthesis
- agent reasoning

## Important

The graph should never be treated as more authoritative than its source evidence.

For every high-impact relationship:

```text
Graph relationship
      |
      v
source Markdown
      |
      v
source section
      |
      v
human/automated validation
```

That is the enterprise-grade pattern.
