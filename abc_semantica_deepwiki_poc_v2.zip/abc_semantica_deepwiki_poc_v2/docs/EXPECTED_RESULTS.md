# Expected Sample Results

After:

```bash
python run_pipeline.py
```

You should see approximately these logical results.

## Payment Service dependencies

```text
Customer Service
Fraud Service
```

## Who depends on Customer Service?

```text
Fraud Service
Notification Service
Payment Service
```

## customer.updated consumers

```text
Fraud Service
Notification Service
Payment Service
```

## payment.created producers

```text
Payment Service
```

## Java 11 applications

```text
Fraud Service
```

## Payments capability

```text
Payment Service
```

## Customer Service blast radius

Direct:

```text
Fraud Service
Payment Service
Notification Service
```

The exact ordering in JSON is not an architectural ranking.

## Why this is useful

These are graph questions.

The corresponding document question would be:

> "Find Markdown files containing Customer Service."

The graph question is:

> "What applications are connected to Customer Service through documented
> dependency relationships?"

That distinction is the reason for introducing Semantica.
