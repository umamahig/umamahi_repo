# ABC Application Ontology

This is the recommended first ontology for the ABC application landscape.

## Classes

```text
Application
Service
API
KafkaTopic
Database
DataEntity
Technology
Framework
BusinessCapability
BusinessDomain
Team
Owner
Environment
ExternalSystem
Document
```

## Core relationships

```text
Application --depends_on--> Application
Application --implements--> Service
Application --exposes_api--> API
Application --consumes_api--> API
Application --publishes_event--> KafkaTopic
Application --consumes_event--> KafkaTopic
Application --uses_database--> Database
Application --uses_technology--> Technology
Application --supports_capability--> BusinessCapability
Application --belongs_to_domain--> BusinessDomain
Application --owned_by--> Team
Application --deployed_in--> Environment
Application --integrates_with--> ExternalSystem
Application --documented_by--> Document
```

## Governance constraints

```text
Production Application -> owner [required]
Production Application -> business capability [required]
Application -> environment [required]
API -> owning application [required]
Kafka consumer -> topic [required]
Database -> owning/using application [required]
```

## Why this ontology matters

The graph should represent architecture facts, not arbitrary natural-language
concepts.

The ontology gives the extraction pipeline a controlled vocabulary and gives
governance a stable schema.

For a real ABC implementation, extend this with:

- data classification
- PII
- regulatory domain
- criticality
- RTO/RPO
- deployment platform
- cloud account
- Kubernetes cluster
- namespace
- API version
- Kafka cluster
- schema registry
- upstream/downstream system
- business owner
- technical owner
