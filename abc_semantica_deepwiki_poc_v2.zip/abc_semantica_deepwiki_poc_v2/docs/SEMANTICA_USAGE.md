# How to use Semantica in this ABC project

## 1. Install

Basic:

```bash
pip install -U semantica
```

All optional integrations:

```bash
pip install "semantica[all]"
```

Verify:

```bash
python -c "import semantica; print(semantica.__version__)"
```

The current official documentation describes `pip install semantica`, optional
`[all]`, and a full ingest -> parse -> extract -> build -> visualize -> export
pipeline.

## 2. Understand where Semantica sits

Do NOT feed your source repository directly into Semantica and discard DeepWiki.

Use:

    Source repositories
          |
        DeepWiki
          |
    Markdown documentation
          |
       Semantica
          |
    Application Landscape Graph

DeepWiki answers document/content questions.

Semantica answers structured relationship questions.

## 3. Run the sample

```bash
python run_pipeline.py
```

This creates:

```text
output/
  abc_graph.json
  abc_facts.json
  enterprise_queries.json
  governance_report.json
  ontology/
  provenance/
  graph.html
```

## 4. Understand the graph

Example:

```text
Payment Service
   |
   +-- depends_on --> Customer Service
   +-- depends_on --> Fraud Service
   +-- consumes_event --> customer.updated
   +-- publishes_event --> payment.created
   +-- uses_database --> PaymentDB
   +-- uses_technology --> Java 17
   +-- supports_capability --> Payments
```

These edges originate from DeepWiki Markdown and retain:

- source_file
- source_section
- confidence
- extraction_method

## 5. Enterprise queries

```bash
python query_cli.py summary

python query_cli.py deps "Payment Service"

python query_cli.py reverse-deps "Customer Service"

python query_cli.py event-consumers "customer.updated"

python query_cli.py event-producers "payment.created"

python query_cli.py technology "Java 11"

python query_cli.py capability "Payments"

python query_cli.py owner "Payments Engineering Team"

python query_cli.py environment "Production"

python query_cli.py database "CustomerDB"

python query_cli.py blast "Customer Service"

python query_cli.py business-impact "Customer Service"
```

## 6. Architecture governance

Run:

```bash
python governance.py
```

The deterministic ABC checks identify missing architecture facts.

The project also attempts Semantica's `OntologyEngine`.

Semantica's ontology module supports ontology generation, SHACL generation,
graph validation, and OWL/RDF export.

For production, define an explicit ABC ontology instead of relying only on
automatic ontology generation.

## 7. Provenance

The project records a provenance ledger for every extracted fact:

```text
subject
predicate
object
source_file
source_section
confidence
extraction_method
```

It also attempts Semantica's `ProvenanceManager`.

This is critical.

For example:

```text
Payment Service
   --depends_on-->
Customer Service

Source:
deepwiki_docs/payment-service/architecture.md

Section:
Dependencies
```

The graph is therefore traceable back to the DeepWiki evidence.

## 8. Persistent graph

For a small POC, in-memory graph storage is sufficient.

For an enterprise ABC landscape, use a persistent graph.

Semantica documents graph-store backends including Neo4j and FalkorDB.

Example:

```bash
python run_pipeline.py \
  --neo4j-uri bolt://localhost:7687 \
  --neo4j-user neo4j \
  --neo4j-password password
```

Install the appropriate Semantica/backend extras according to the current
Semantica installation documentation.

## 9. LLM extraction

Do not start with LLM extraction.

First make deterministic extraction work.

If DeepWiki documentation is highly inconsistent/free-form, use:

```bash
python optional_llm_extraction.py
```

The official Semantica semantic extraction module supports NER and relation
extraction. LLM-based extraction is useful when Markdown does not follow a
consistent architecture template.

In production, constrain the LLM to ABC entity and relationship types.

## 10. Change analysis

Create baseline:

```bash
python snapshot.py --output snapshots/baseline.json
```

Change your DeepWiki Markdown.

Regenerate:

```bash
python run_pipeline.py
```

Compare:

```bash
python compare_snapshots.py \
  snapshots/baseline.json \
  output/abc_graph.json
```

This reports:

- added applications/entities
- removed applications/entities
- added relationships
- removed relationships

This becomes the foundation for architecture drift/change intelligence.

## 11. What to build next for ABC

Once the sample works, replace `deepwiki_docs/` with your real DeepWiki
Markdown corpus.

Then define your actual ABC ontology, for example:

### Entities

- Application
- Service
- API
- KafkaTopic
- Database
- DataEntity
- Technology
- BusinessCapability
- BusinessDomain
- Team
- Owner
- Environment
- ExternalSystem

### Relationships

- depends_on
- exposes_api
- consumes_api
- publishes_event
- consumes_event
- uses_database
- uses_technology
- supports_capability
- belongs_to_domain
- owned_by
- deployed_in
- integrates_with
- documented_by

Then make these five use cases your acceptance test:

1. What applications depend on Application X?
2. What is the blast radius of changing API X?
3. Who produces/consumes Kafka Topic X?
4. Which applications support Business Capability X?
5. Which architecture facts are missing, conflicting, or stale?

If these work reliably with source evidence, Semantica is providing real
value beyond DeepWiki document search.
