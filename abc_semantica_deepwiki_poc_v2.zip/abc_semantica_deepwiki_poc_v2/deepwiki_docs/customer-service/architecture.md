# Application: Customer Service

## Overview
Customer Service is the system of record for customer profile information.

## Technology
- Java 17
- Spring Boot 3
- PostgreSQL

## Dependencies
- Identity Service

## APIs
- GET /customers/{customerId}
- GET /customers/{customerId}/profile

## Events
Consumes:
- identity.customer-verified

Publishes:
- customer.updated
- customer.created

## Database
- CustomerDB

## Business Capability
- Customer Management

## Owner
- Customer Platform Team

## Environment
- Production
