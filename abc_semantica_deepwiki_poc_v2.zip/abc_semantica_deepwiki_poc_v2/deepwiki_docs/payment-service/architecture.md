# Application: Payment Service

## Overview
Payment Service processes customer payments and integrates with fraud controls.

## Technology
- Java 17
- Spring Boot 3
- Kafka

## Dependencies
- Customer Service
- Fraud Service

## APIs
- POST /payments
- GET /payments/{paymentId}

## Events
Consumes:
- customer.updated
- fraud.payment-screened

Publishes:
- payment.created
- payment.completed

## Database
- PaymentDB

## Business Capability
- Payments

## Owner
- Payments Engineering Team

## Environment
- Production
