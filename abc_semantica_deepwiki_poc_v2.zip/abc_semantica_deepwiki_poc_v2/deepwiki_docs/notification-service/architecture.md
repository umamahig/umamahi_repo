# Application: Notification Service

## Overview
Notification Service sends customer notifications for business events.

## Technology
- Java 21
- Spring Boot 3
- Kafka

## Dependencies
- Customer Service
- Payment Service

## APIs
- POST /notifications

## Events
Consumes:
- customer.updated
- payment.completed

Publishes:
- notification.sent

## Database
- NotificationDB

## Business Capability
- Customer Communication

## Owner
- Digital Channels Team

## Environment
- Production
