# Application: Fraud Service

## Overview
Fraud Service evaluates payment transactions for fraud risk.

## Technology
- Java 11
- Spring Boot 2
- Kafka

## Dependencies
- Customer Service

## APIs
- POST /fraud/screen
- GET /fraud/cases/{caseId}

## Events
Consumes:
- payment.created
- customer.updated

Publishes:
- fraud.payment-screened
- fraud.case-created

## Database
- FraudDB

## Business Capability
- Fraud Detection

## Owner
- Fraud Engineering Team

## Environment
- Production
