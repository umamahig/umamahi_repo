from __future__ import annotations

from collections import defaultdict, deque
from typing import Dict, List


def _name(v):
    if isinstance(v, str):
        return v
    if isinstance(v, dict):
        return v.get("label") or v.get("name") or v.get("text") or v.get("id")
    return getattr(v, "label", None) or getattr(v, "name", None) or getattr(v, "text", None) or getattr(v, "id", None)


def _label(v):
    if isinstance(v, dict):
        return v.get("type") or v.get("label")
    return getattr(v, "type", None) or getattr(v, "label", None)


def normalize(graph):
    """
    Normalize the Semantica graph into a stable query representation.
    This lets the query layer survive small serialization/API differences.
    """
    nodes = {}
    names_by_id = {}
    for n in graph.get("entities", []):
        name = _name(n)
        if not name:
            continue
        nodes[name.lower()] = {
            "name": name,
            "type": _label(n),
            "raw": n,
        }
        if isinstance(n, dict) and n.get("id"):
            names_by_id[n["id"].lower()] = name

    edges = []
    for e in graph.get("relationships", []):
        if isinstance(e, dict):
            s = e.get("source") or e.get("subject")
            t = e.get("target") or e.get("object")
            p = e.get("type") or e.get("predicate") or e.get("relation")
        else:
            s = getattr(e, "source", None) or getattr(e, "subject", None)
            t = getattr(e, "target", None) or getattr(e, "object", None)
            p = getattr(e, "type", None) or getattr(e, "predicate", None)

        source = _name(s)
        target = _name(t)
        if not source or not target or not p:
            continue

        edges.append({
            "source": names_by_id.get(source.lower(), source),
            "target": names_by_id.get(target.lower(), target),
            "type": p,
            "metadata": e.get("metadata", {}) if isinstance(e, dict) else {},
        })

    return nodes, edges


def edges(graph, predicate=None):
    _, es = normalize(graph)
    if predicate:
        return [e for e in es if e["type"] == predicate]
    return es


def direct_dependencies(graph, application):
    a = application.lower()
    return sorted({
        e["target"]
        for e in edges(graph, "depends_on")
        if e["source"].lower() == a
    })


def reverse_dependencies(graph, application):
    a = application.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "depends_on")
        if e["target"].lower() == a
    })


def event_consumers(graph, topic):
    t = topic.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "consumes_event")
        if e["target"].lower() == t
    })


def event_producers(graph, topic):
    t = topic.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "publishes_event")
        if e["target"].lower() == t
    })


def technology_users(graph, technology):
    t = technology.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "uses_technology")
        if e["target"].lower() == t
    })


def capability_apps(graph, capability):
    c = capability.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "supports_capability")
        if e["target"].lower() == c
    })


def owner_apps(graph, owner):
    o = owner.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "owned_by")
        if e["target"].lower() == o
    })


def environment_apps(graph, environment):
    evalue = environment.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "deployed_in")
        if e["target"].lower() == evalue
    })


def database_users(graph, database):
    d = database.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "uses_database")
        if e["target"].lower() == d
    })


def api_exposers(graph, api):
    a = api.lower()
    return sorted({
        e["source"]
        for e in edges(graph, "exposes_api")
        if e["target"].lower() == a
    })


def blast_radius(graph, application, max_hops=10):
    start = application.lower()
    reverse = defaultdict(list)

    for e in edges(graph, "depends_on"):
        reverse[e["target"].lower()].append(e["source"])

    q = deque([(start, 0)])
    seen = {start}
    result = []

    while q:
        current, distance = q.popleft()
        if distance >= max_hops:
            continue

        for nxt in reverse.get(current, []):
            key = nxt.lower()
            if key in seen:
                continue
            seen.add(key)
            result.append({
                "application": nxt,
                "dependency_hops": distance + 1,
            })
            q.append((key, distance + 1))

    return sorted(result, key=lambda x: (x["dependency_hops"], x["application"].lower()))


def connected_business_impact(graph, application):
    """
    Find business capabilities reachable from an application through direct
    dependency chains. This is deliberately conservative: it only follows
    documented dependency relationships.
    """
    start = application.lower()
    deps = defaultdict(list)

    for e in edges(graph, "depends_on"):
        deps[e["source"].lower()].append(e["target"])

    capabilities = defaultdict(list)
    for e in edges(graph, "supports_capability"):
        capabilities[e["source"].lower()].append(e["target"])

    q = deque([start])
    seen = {start}
    impacted = []

    while q:
        current = q.popleft()
        for cap in capabilities.get(current, []):
            impacted.append({
                "application": current,
                "business_capability": cap,
            })
        for nxt in deps.get(current, []):
            key = nxt.lower()
            if key not in seen:
                seen.add(key)
                q.append(key)

    return impacted


def enterprise_summary(graph):
    nodes, es = normalize(graph)
    by_type = defaultdict(int)
    for n in nodes.values():
        by_type[n["type"]] += 1

    return {
        "node_count": len(nodes),
        "relationship_count": len(es),
        "nodes_by_type": dict(sorted(by_type.items())),
        "relationship_types": dict(sorted(
            {p: sum(1 for e in es if e["type"] == p) for p in {e["type"] for e in es}}.items()
        )),
    }
