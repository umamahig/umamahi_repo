import argparse
import json
from pathlib import Path

from change_analysis import compare


p = argparse.ArgumentParser()
p.add_argument("old_snapshot")
p.add_argument("new_graph")
args = p.parse_args()

old_payload = json.loads(
    Path(args.old_snapshot).read_text(encoding="utf-8")
)
old_graph = old_payload.get("graph", old_payload)

new_graph = json.loads(
    Path(args.new_graph).read_text(encoding="utf-8")
)

report = compare(old_graph, new_graph)

Path("output").mkdir(exist_ok=True)
Path("output/change_report.json").write_text(
    json.dumps(report, indent=2, default=str),
    encoding="utf-8",
)

print(json.dumps(report, indent=2, default=str))
