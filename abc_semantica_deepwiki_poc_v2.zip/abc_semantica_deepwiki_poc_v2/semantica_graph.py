from __future__ import annotations

import hashlib
import json
from pathlib import Path
from typing import Dict, List, Optional

from abc_extractor import Fact


REL_TARGET_TYPE = {
    "depends_on": "Application",
    "exposes_api": "API",
    "consumes_event": "KafkaTopic",
    "publishes_event": "KafkaTopic",
    "uses_database": "Database",
    "uses_technology": "Technology",
    "supports_capability": "BusinessCapability",
    "owned_by": "Team",
    "deployed_in": "Environment",
}


def stable_id(name: str, kind: str) -> str:
    normalized = " ".join(name.lower().split())
    digest = hashlib.sha256(normalized.encode()).hexdigest()[:12]
    return f"{kind.lower()}::{digest}"


def graph_input(facts: List[Fact]):
    entities = {}
    relationships = []

    for f in facts:
        sid = stable_id(f.subject, "Application")
        entities.setdefault(
            sid,
            {
                "id": sid,
                "type": "Application",
                "label": f.subject,
            },
        )

        target_type = REL_TARGET_TYPE[f.predicate]
        tid = stable_id(f.object, target_type)
        entities.setdefault(
            tid,
            {
                "id": tid,
                "type": target_type,
                "label": f.object,
            },
        )

        relationships.append(
            {
                "source": sid,
                "target": tid,
                "type": f.predicate,
                "metadata": {
                    "source_file": f.source_file,
                    "source_section": f.source_section,
                    "confidence": f.confidence,
                    "extraction_method": f.extraction_method,
                },
            }
        )

    return {
        "entities": list(entities.values()),
        "relationships": relationships,
    }


def build_with_semantica(facts: List[Fact]):
    from semantica.kg import GraphBuilder

    data = graph_input(facts)
    graph = GraphBuilder(merge_entities=True).build(data)

    return graph, data


def attach_provenance(facts: List[Fact], output_dir: str):
    """
    Use Semantica's provenance API when available.

    We also save a deterministic local provenance ledger because it gives the
    POC a stable audit artifact regardless of minor Semantica API changes.
    """
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    ledger = [f.to_dict() for f in facts]
    (out / "provenance_ledger.json").write_text(
        json.dumps(ledger, indent=2), encoding="utf-8"
    )

    try:
        from semantica.provenance import ProvenanceManager

        manager = ProvenanceManager()
        for f in facts:
            entity_key = f"{f.subject}|{f.predicate}|{f.object}"
            manager.track_entity(
                entity_key,
                source=f.source_file,
                metadata={
                    "source_section": f.source_section,
                    "confidence": f.confidence,
                    "extraction_method": f.extraction_method,
                },
            )

        # API names differ slightly across releases; get_all_sources is used
        # by the current quickstart, while get_lineage is used in the module
        # reference. Try both and persist whichever works.
        result = {}
        for f in facts:
            key = f"{f.subject}|{f.predicate}|{f.object}"
            try:
                result[key] = manager.get_all_sources(key)
            except Exception:
                try:
                    result[key] = manager.get_lineage(key)
                except Exception as exc:
                    result[key] = {"error": repr(exc)}

        (out / "semantica_provenance.json").write_text(
            json.dumps(result, indent=2, default=str), encoding="utf-8"
        )
        return {"enabled": True, "manager": manager}
    except Exception as exc:
        (out / "semantica_provenance_note.txt").write_text(
            "Semantica ProvenanceManager unavailable: " + repr(exc),
            encoding="utf-8",
        )
        return {"enabled": False, "error": repr(exc)}


def export_graph(graph, output_dir: str):
    out = Path(output_dir)
    out.mkdir(parents=True, exist_ok=True)

    (out / "abc_graph.json").write_text(
        json.dumps(graph, indent=2, default=str), encoding="utf-8"
    )

    try:
        from semantica.export import RDFExporter
        exporter = RDFExporter()
        exporter.export(
            graph,
            file_path=str(out / "abc_graph.ttl"),
            format="turtle",
        )
        exporter.export(
            graph,
            file_path=str(out / "abc_graph.jsonld"),
            format="json-ld",
        )
    except Exception as exc:
        (out / "rdf_export_note.txt").write_text(
            repr(exc), encoding="utf-8"
        )

    try:
        from semantica.visualization import KGVisualizer
        KGVisualizer(layout="force").visualize_network(
            graph,
            output="html",
            file_path=str(out / "graph.html"),
            node_color_by="type",
        )
    except Exception as exc:
        (out / "visualization_note.txt").write_text(
            repr(exc), encoding="utf-8"
        )


def persistent_store_demo(graph_data, uri=None, user=None, password=None):
    """
    Optional Neo4j persistence.

    If URI is not supplied, returns None and the POC remains in-memory.
    """
    if not uri:
        return None

    from semantica.graph_store import GraphStore
    from semantica.kg import GraphBuilder

    store = GraphStore(
        backend="neo4j",
        uri=uri,
        user=user,
        password=password,
    )

    return GraphBuilder(
        merge_entities=True,
        graph_store=store,
    ).build(graph_data)
