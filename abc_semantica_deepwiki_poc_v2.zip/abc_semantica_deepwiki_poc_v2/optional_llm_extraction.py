"""
Optional Semantica-native LLM extraction.

The main POC intentionally uses deterministic ABC Markdown extraction.
Use this script when DeepWiki sections are free-form and you need
Semantica's NERExtractor/RelationExtractor.

Configure the provider according to the installed Semantica version.

The official Semantica docs show:
    NERExtractor(method="pattern")
    RelationExtractor(method="pattern")
and LLM modes using configured providers.
"""

from pathlib import Path
from semantica.semantic_extract import NERExtractor, RelationExtractor

text = Path(
    "deepwiki_docs/payment-service/architecture.md"
).read_text(encoding="utf-8")

entities = NERExtractor(method="pattern").extract(text)
relations = RelationExtractor(method="pattern").extract(
    text,
    entities=entities,
)

print("Entities:")
for x in entities:
    print(x)

print("\nRelationships:")
for x in relations:
    print(x)
