import json
import sys
from pathlib import Path

from enterprise_queries import (
    direct_dependencies,
    reverse_dependencies,
    event_consumers,
    event_producers,
    technology_users,
    capability_apps,
    owner_apps,
    environment_apps,
    database_users,
    api_exposers,
    blast_radius,
    connected_business_impact,
    enterprise_summary,
)

if len(sys.argv) < 2:
    raise SystemExit(
        "Usage: python query_cli.py "
        "{summary|deps|reverse-deps|event-consumers|event-producers|technology|"
        "capability|owner|environment|database|api|blast|business-impact} [value]"
    )

graph = json.loads(
    Path("output/abc_graph.json").read_text(encoding="utf-8")
)

cmd = sys.argv[1]
value = sys.argv[2] if len(sys.argv) > 2 else None

functions = {
    "deps": direct_dependencies,
    "reverse-deps": reverse_dependencies,
    "event-consumers": event_consumers,
    "event-producers": event_producers,
    "technology": technology_users,
    "capability": capability_apps,
    "owner": owner_apps,
    "environment": environment_apps,
    "database": database_users,
    "api": api_exposers,
    "blast": blast_radius,
    "business-impact": connected_business_impact,
}

if cmd == "summary":
    result = enterprise_summary(graph)
else:
    if not value:
        raise SystemExit("A query value is required.")
    result = functions[cmd](graph, value)

print(json.dumps(result, indent=2, default=str))
